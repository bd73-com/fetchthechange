"use strict";
(() => {
  // src/shared/constants.ts
  var BASE_URL = "https://ftc.bd73.com";

  // src/content/auth-relay.ts
  var EXPECTED_ORIGIN = new URL(BASE_URL).origin;
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.origin !== EXPECTED_ORIGIN) return;
    if (event.data?.type !== "FTC_EXTENSION_TOKEN") return;
    const { token, expiresAt } = event.data;
    if (typeof token !== "string" || typeof expiresAt !== "string") return;
    chrome.runtime.sendMessage({
      type: "FTC_EXTENSION_TOKEN",
      token,
      expiresAt
    });
  });
})();
