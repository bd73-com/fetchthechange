"use strict";
(() => {
  // src/shared/constants.ts
  var BASE_URL = "https://ftc.bd73.com";
  var TOKEN_STORAGE_KEY = "ftc_extension_token";
  var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
  var AUTH_STARTED_KEY = "ftc_auth_started_at";

  // src/content/auth-relay.ts
  var TAG = "[FTC:auth-relay]";
  var EXPECTED_ORIGIN = new URL(BASE_URL).origin;
  console.log(TAG, "loaded on", window.location.href.split("#")[0]);
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.origin !== EXPECTED_ORIGIN) return;
    if (event.data?.type !== "FTC_EXTENSION_TOKEN") return;
    const { token, expiresAt } = event.data;
    if (typeof token !== "string" || typeof expiresAt !== "string") {
      console.warn(TAG, "received FTC_EXTENSION_TOKEN but payload is invalid");
      return;
    }
    if (token.split(".").length !== 3) {
      console.warn(TAG, "token doesn't look like a JWT, ignoring");
      return;
    }
    console.log(TAG, "token received, storing directly + relaying to SW...");
    chrome.storage.local.set({
      [TOKEN_STORAGE_KEY]: token,
      [TOKEN_EXPIRY_KEY]: expiresAt
    }, () => {
      if (chrome.runtime.lastError) {
        console.error(TAG, "direct storage write failed:", chrome.runtime.lastError.message);
      } else {
        console.log(TAG, "token stored directly in chrome.storage.local");
        chrome.storage.local.remove(AUTH_STARTED_KEY);
      }
    });
    chrome.runtime.sendMessage(
      { type: "FTC_EXTENSION_TOKEN", token, expiresAt },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error(TAG, "sendMessage failed:", chrome.runtime.lastError.message);
          return;
        }
        if (response?.ok) {
          console.log(TAG, "service worker acknowledged token");
        } else {
          console.warn(TAG, "service worker rejected token:", response?.error);
        }
      }
    );
  });
})();
