"use strict";
(() => {
  // src/shared/constants.ts
  var BASE_URL = "https://ftc.bd73.com";
  var TOKEN_STORAGE_KEY = "ftc_extension_token";
  var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
  var AUTH_STARTED_KEY = "ftc_auth_started_at";
  var PENDING_SELECTION_KEY = "ftc_pending_selection";
  var MSG = {
    START_PICKER: "FTC_START_PICKER",
    CANCEL_PICKER: "FTC_CANCEL_PICKER",
    ELEMENT_SELECTED: "FTC_ELEMENT_SELECTED",
    GET_CANDIDATES: "FTC_GET_CANDIDATES",
    CANDIDATES_RESULT: "FTC_CANDIDATES_RESULT",
    FTC_EXTENSION_TOKEN: "FTC_EXTENSION_TOKEN",
    AUTH_TAB_OPENED: "FTC_AUTH_TAB_OPENED"
  };

  // src/auth/token.ts
  async function getToken() {
    const result = await chrome.storage.local.get([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
    const token = result[TOKEN_STORAGE_KEY];
    const expiry = result[TOKEN_EXPIRY_KEY];
    if (!token || !expiry) return null;
    const expiryMs = new Date(expiry).getTime();
    if (!Number.isFinite(expiryMs) || expiryMs < Date.now()) {
      await clearToken();
      return null;
    }
    return token;
  }
  async function clearToken() {
    await chrome.storage.local.remove([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
  }
  async function isTokenValid() {
    const token = await getToken();
    return token !== null;
  }

  // src/popup/utils.ts
  function escapeAttr(str) {
    return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  var KNOWN_TIERS = ["free", "pro", "power"];
  function sanitizeTier(tier) {
    return KNOWN_TIERS.includes(tier) ? tier : "free";
  }

  // src/popup/popup.ts
  var TAG = "[FTC:popup]";
  var state = "unauthenticated";
  var userInfo = null;
  var selection = null;
  var candidates = [];
  var currentTabUrl = "";
  var currentTabTitle = "";
  var currentTabId = 0;
  var dropdownOpen = false;
  var content = document.getElementById("content");
  var accountArea = document.getElementById("account-area");
  var AUTH_TIMEOUT_MS = 12e4;
  var initRunning = false;
  var initPending = false;
  async function init() {
    if (initRunning) {
      initPending = true;
      console.log(TAG, "init already running, queueing rerun");
      return;
    }
    initRunning = true;
    console.log(TAG, "init start");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        currentTabUrl = tab.url || "";
        currentTabTitle = tab.title || "";
        currentTabId = tab.id || 0;
      }
      const valid = await isTokenValid();
      if (!valid) {
        console.log(TAG, "no valid token in storage");
        const stored = await chrome.storage.local.get(AUTH_STARTED_KEY);
        const startedAt = Number(stored[AUTH_STARTED_KEY]);
        const elapsed = Date.now() - startedAt;
        if (Number.isFinite(startedAt) && elapsed < AUTH_TIMEOUT_MS) {
          if (elapsed < 3e4) {
            console.log(TAG, "auth attempt in progress (", Math.round(elapsed / 1e3), "s ago)");
            state = "connecting";
          } else {
            console.warn(TAG, "recent auth attempt found but no token \u2014 showing failure state");
            state = "auth_failed";
          }
        } else {
          state = "unauthenticated";
        }
        render();
        return;
      }
      const token = await getToken();
      if (!token) {
        console.log(TAG, "getToken returned null despite isTokenValid");
        state = "unauthenticated";
        render();
        return;
      }
      console.log(TAG, "verifying token with backend...");
      try {
        const res = await fetch(`${BASE_URL}/api/extension/verify`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) {
          console.warn(TAG, "verify returned", res.status);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        userInfo = await res.json().catch(() => null);
        if (!userInfo || typeof userInfo.userId !== "string" || typeof userInfo.tier !== "string") {
          console.warn(TAG, "verify response malformed:", userInfo);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        await chrome.storage.local.set({ cachedUserInfo: userInfo });
        await chrome.storage.local.remove(AUTH_STARTED_KEY);
        state = "authenticated";
        console.log(TAG, "authenticated as", userInfo.email);
      } catch (err) {
        console.warn(TAG, "verify network error:", err);
        const cached = await chrome.storage.local.get("cachedUserInfo");
        const c = cached.cachedUserInfo;
        if (c && typeof c.userId === "string" && typeof c.tier === "string" && typeof c.email === "string") {
          userInfo = c;
          state = "authenticated";
        } else {
          state = "unauthenticated";
        }
      }
      if (state === "authenticated") {
        const pending = await chrome.storage.local.get(PENDING_SELECTION_KEY);
        const stored = pending[PENDING_SELECTION_KEY];
        if (stored && typeof stored.selector === "string") {
          const age = stored.timestamp ? Date.now() - stored.timestamp : Infinity;
          await chrome.storage.local.remove(PENDING_SELECTION_KEY);
          if (age < 6e5) {
            console.log(TAG, "pending selection found in storage, jumping to confirm");
            selection = {
              selector: stored.selector,
              currentValue: typeof stored.currentValue === "string" ? stored.currentValue : "",
              url: typeof stored.url === "string" ? stored.url : currentTabUrl,
              pageTitle: typeof stored.pageTitle === "string" ? stored.pageTitle : currentTabTitle
            };
            state = "confirm";
            render();
            return;
          } else {
            console.log(TAG, "pending selection too old (", Math.round(age / 1e3), "s), discarding");
          }
        }
      }
      render();
    } finally {
      initRunning = false;
      if (initPending) {
        initPending = false;
        if (state !== "confirm") {
          void init();
        }
      }
    }
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === MSG.ELEMENT_SELECTED) {
      const sel = typeof message.selector === "string" ? message.selector.trim().slice(0, 500) : "";
      if (!sel) return;
      selection = {
        selector: sel,
        currentValue: typeof message.currentValue === "string" ? message.currentValue.slice(0, 500) : "",
        url: typeof message.url === "string" ? message.url.slice(0, 2e3) : currentTabUrl,
        pageTitle: typeof message.pageTitle === "string" ? message.pageTitle.slice(0, 200) : currentTabTitle
      };
      state = "confirm";
      render();
    }
    if (message.type === MSG.CANDIDATES_RESULT) {
      candidates = message.candidates || [];
      if (state === "authenticated" || state === "picking") {
        render();
      }
    }
    if (message.type === MSG.CANCEL_PICKER) {
      if (state === "picking") {
        state = "authenticated";
        render();
      }
    }
    if (message.type === "FTC_AUTH_COMPLETE") {
      init();
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[TOKEN_STORAGE_KEY]?.newValue) {
      console.log(TAG, "token appeared in storage (direct write), re-initialising...");
      void init();
    }
    if (changes[PENDING_SELECTION_KEY]?.newValue && state !== "confirm") {
      console.log(TAG, "pending selection appeared in storage, re-initialising...");
      void init();
    }
  });
  function render() {
    renderAccount();
    switch (state) {
      case "unauthenticated":
        renderUnauth();
        break;
      case "connecting":
        renderConnecting();
        break;
      case "auth_failed":
        renderAuthFailed();
        break;
      case "authenticated":
        renderAuthenticated();
        break;
      case "picking":
        renderPicking();
        break;
      case "confirm":
        renderConfirm();
        break;
    }
  }
  function renderAccount() {
    if (!userInfo) {
      accountArea.innerHTML = "";
      return;
    }
    accountArea.innerHTML = `
    <button class="account-btn" id="account-toggle">
      ${escapeHtml(userInfo.email || "Connected")} &#9662;
    </button>
    <div class="account-dropdown ${dropdownOpen ? "" : "hidden"}" id="account-dropdown">
      <div class="dropdown-email">
        ${escapeHtml(userInfo.email || userInfo.userId)}
        <span class="tier-badge tier-${sanitizeTier(userInfo.tier)}">${escapeHtml(userInfo.tier)}</span>
      </div>
      <a class="dropdown-item" href="${BASE_URL}/dashboard" target="_blank">Open dashboard</a>
      <div class="dropdown-divider"></div>
      <button class="dropdown-item" id="disconnect-btn">Disconnect</button>
    </div>
  `;
    document.getElementById("account-toggle")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdownOpen = !dropdownOpen;
      renderAccount();
    });
    document.getElementById("disconnect-btn")?.addEventListener("click", async () => {
      await clearToken();
      await chrome.storage.local.remove("cachedUserInfo");
      userInfo = null;
      dropdownOpen = false;
      state = "unauthenticated";
      render();
    });
    document.addEventListener("click", () => {
      if (dropdownOpen) {
        dropdownOpen = false;
        renderAccount();
      }
    }, { once: true });
  }
  function renderUnauth() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Track what matters on any webpage.</h2>
      <button class="btn btn-primary btn-full" id="connect-btn">Connect your account</button>
      <p>Already have an account? Sign in above.</p>
    </div>
  `;
    document.getElementById("connect-btn")?.addEventListener("click", startAuthFlow);
  }
  function renderAuthFailed() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Connection failed</h2>
      <p>We couldn't connect the extension to your account. This can happen if your browser blocked the connection.</p>
      <button class="btn btn-primary btn-full" id="retry-connect-btn">Try again</button>
      <p style="margin-top: 12px; font-size: 12px; opacity: 0.7;">
        Tip: when Chrome asks to allow access to ftc.bd73.com, click <strong>Allow</strong>.
      </p>
    </div>
  `;
    document.getElementById("retry-connect-btn")?.addEventListener("click", startAuthFlow);
  }
  async function startAuthFlow() {
    console.log(TAG, "starting auth flow");
    let permissionGranted = false;
    try {
      const origin = new URL(BASE_URL).origin;
      permissionGranted = await chrome.permissions.contains({ origins: [`${origin}/*`] });
      console.log(TAG, "host permission already granted:", permissionGranted);
      if (!permissionGranted) {
        permissionGranted = await chrome.permissions.request({ origins: [`${origin}/*`] });
        console.log(TAG, "host permission request result:", permissionGranted);
      }
    } catch (err) {
      console.warn(TAG, "permission request error:", err);
    }
    await chrome.storage.local.set({ [AUTH_STARTED_KEY]: Date.now() });
    let tab;
    try {
      tab = await chrome.tabs.create({ url: `${BASE_URL}/extension-auth` });
    } catch (err) {
      console.error(TAG, "failed to open auth tab:", err);
      state = "auth_failed";
      render();
      return;
    }
    console.log(TAG, "auth tab created:", tab.id);
    if (tab.id) {
      chrome.runtime.sendMessage({ type: MSG.AUTH_TAB_OPENED, tabId: tab.id }).catch(
        (err) => console.warn(TAG, "failed to notify service worker of auth tab:", err)
      );
    }
    state = "connecting";
    render();
  }
  function renderConnecting() {
    content.innerHTML = `
    <div class="connecting">
      <div class="spinner"></div>
      <p>Connecting...</p>
      <p>Waiting for you to sign in at FetchTheChange.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-connect" style="margin-top: 16px;">Cancel</button>
    </div>
  `;
    document.getElementById("cancel-connect")?.addEventListener("click", async () => {
      await chrome.storage.local.remove(AUTH_STARTED_KEY);
      state = "unauthenticated";
      render();
    });
  }
  function renderAuthenticated() {
    const truncatedUrl = currentTabUrl.length > 45 ? currentTabUrl.slice(0, 45) + "..." : currentTabUrl;
    let candidatesHtml = "";
    if (candidates.length > 0) {
      candidatesHtml = `
      <div class="section-header">Suggested elements</div>
      ${candidates.map(
        (c, i) => `
        <div class="candidate" data-idx="${i}">
          <span class="candidate-text">${escapeHtml(c.text)}</span>
          <span class="candidate-selector">${escapeHtml(c.selector)}</span>
          <button class="btn btn-primary btn-sm candidate-track" data-idx="${i}">Track this</button>
        </div>
      `
      ).join("")}
    `;
    }
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(truncatedUrl)}</div>
    ${candidatesHtml}
    <div class="section-header">Or pick manually</div>
    <button class="btn btn-primary btn-full" id="pick-btn">Pick an element on this page</button>
    <button class="advanced-toggle" id="advanced-toggle">&#9662; Advanced (CSS selector)</button>
    <div class="advanced-content" id="advanced-content">
      <div class="form-group">
        <input type="text" class="form-input" id="manual-selector" placeholder="e.g. .product-price">
      </div>
      <button class="btn btn-secondary btn-sm" id="manual-track-btn">Use this selector</button>
    </div>
  `;
    document.getElementById("pick-btn")?.addEventListener("click", () => {
      if (!currentTabUrl.startsWith("http://") && !currentTabUrl.startsWith("https://")) {
        const pickBtn = document.getElementById("pick-btn");
        const existing = document.querySelector(".ftc-picker-warning");
        if (existing) existing.remove();
        const warning = document.createElement("div");
        warning.className = "ftc-picker-warning";
        warning.style.cssText = "color: #f59e0b; font-size: 13px; margin-top: 8px; padding: 8px; border-radius: 6px; background: rgba(245,158,11,0.1);";
        warning.textContent = "The picker only works on web pages (http/https). Navigate to a website first.";
        pickBtn?.after(warning);
        return;
      }
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.querySelectorAll(".candidate-track").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const idx = parseInt(e.target.dataset.idx || "0");
        const c = candidates[idx];
        if (c) {
          selection = {
            selector: c.selector,
            currentValue: c.text,
            url: currentTabUrl,
            pageTitle: currentTabTitle
          };
          state = "confirm";
          render();
        }
      });
    });
    document.getElementById("advanced-toggle")?.addEventListener("click", () => {
      const el = document.getElementById("advanced-content");
      el?.classList.toggle("open");
    });
    document.getElementById("manual-track-btn")?.addEventListener("click", () => {
      const input = document.getElementById("manual-selector");
      const selector = input?.value.trim();
      if (selector) {
        selection = {
          selector,
          currentValue: "",
          url: currentTabUrl,
          pageTitle: ""
        };
        state = "confirm";
        render();
      }
    });
  }
  function renderPicking() {
    content.innerHTML = `
    <div class="picker-info">
      <div class="icon">&#127919;</div>
      <p><strong>Click any element on the page to track it.</strong></p>
      <p>Press Esc to cancel.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-pick" style="margin-top: 16px;">Cancel picking</button>
    </div>
  `;
    document.getElementById("cancel-pick")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.CANCEL_PICKER, tabId: currentTabId });
      state = "authenticated";
      render();
    });
  }
  function renderConfirm() {
    if (!selection) return;
    const tier = userInfo?.tier || "free";
    const hourlyDisabled = tier === "free";
    const defaultName = (selection.pageTitle || "").slice(0, 100);
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(
      selection.url.length > 45 ? selection.url.slice(0, 45) + "..." : selection.url
    )}</div>
    <div class="confirm-card">
      <div class="label">Element selected</div>
      ${selection.currentValue ? `<div class="value">Currently: ${escapeHtml(selection.currentValue.slice(0, 100))}</div>` : ""}
      <div class="selector">${escapeHtml(selection.selector)}</div>
    </div>
    <div class="form-group">
      <label class="form-label">Monitor name</label>
      <input type="text" class="form-input" id="monitor-name" value="${escapeAttr(defaultName)}" maxlength="100">
    </div>
    <div class="form-group">
      <label class="form-label">Check frequency</label>
      <div class="radio-group">
        <label class="radio-label">
          <input type="radio" name="frequency" value="daily" checked> Daily
        </label>
        <label class="radio-label ${hourlyDisabled ? "disabled" : ""}">
          <input type="radio" name="frequency" value="hourly" ${hourlyDisabled ? "disabled" : ""}>
          Hourly
          ${hourlyDisabled ? '<span class="tooltip-text">(Pro+)</span>' : ""}
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="pick-again-btn"
        ${selection.url && selection.url !== currentTabUrl ? 'disabled title="Switch to the original tab to pick again"' : ""}>Pick again</button>
      <button class="btn btn-primary" id="create-btn">Create monitor</button>
    </div>
  `;
    document.getElementById("pick-again-btn")?.addEventListener("click", () => {
      selection = null;
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.getElementById("create-btn")?.addEventListener("click", createMonitor);
  }
  var creating = false;
  async function createMonitor() {
    if (!selection || creating) return;
    creating = true;
    const nameInput = document.getElementById("monitor-name");
    const name = nameInput?.value.trim() || "Untitled monitor";
    const params = new URLSearchParams();
    params.set("url", selection.url);
    params.set("selector", selection.selector);
    if (name && name !== "Untitled monitor") params.set("name", name);
    try {
      await chrome.tabs.create({ url: `${BASE_URL}/dashboard?${params.toString()}` });
      window.close();
    } catch (err) {
      console.error(TAG, "failed to open dashboard tab:", err);
      creating = false;
    }
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
  init();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL3NoYXJlZC9jb25zdGFudHMudHMiLCAiLi4vLi4vc3JjL2F1dGgvdG9rZW4udHMiLCAiLi4vLi4vc3JjL3BvcHVwL3V0aWxzLnRzIiwgIi4uLy4uL3NyYy9wb3B1cC9wb3B1cC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLy8gQkFTRV9VUkwgaXMgaW5qZWN0ZWQgYXQgYnVpbGQgdGltZSB2aWEgZXNidWlsZCBkZWZpbmUuXG4vLyBTZXQgQkFTRV9VUkwgZW52IHZhciB0byBvdmVycmlkZSAoZGVmYXVsdDogaHR0cHM6Ly9mdGMuYmQ3My5jb20pXG5kZWNsYXJlIGNvbnN0IEJBU0VfVVJMX0lOSkVDVEVEOiBzdHJpbmc7XG5leHBvcnQgY29uc3QgQkFTRV9VUkwgPSBCQVNFX1VSTF9JTkpFQ1RFRDtcbmV4cG9ydCBjb25zdCBUT0tFTl9TVE9SQUdFX0tFWSA9IFwiZnRjX2V4dGVuc2lvbl90b2tlblwiO1xuZXhwb3J0IGNvbnN0IFRPS0VOX0VYUElSWV9LRVkgPSBcImZ0Y19leHRlbnNpb25fdG9rZW5fZXhwaXJ5XCI7XG5leHBvcnQgY29uc3QgQVVUSF9TVEFSVEVEX0tFWSA9IFwiZnRjX2F1dGhfc3RhcnRlZF9hdFwiO1xuZXhwb3J0IGNvbnN0IEFVVEhfVEFCX0lEX0tFWSA9IFwiZnRjX2F1dGhfdGFiX2lkXCI7XG5leHBvcnQgY29uc3QgUEVORElOR19TRUxFQ1RJT05fS0VZID0gXCJmdGNfcGVuZGluZ19zZWxlY3Rpb25cIjtcblxuZXhwb3J0IGNvbnN0IE1TRyA9IHtcbiAgU1RBUlRfUElDS0VSOiBcIkZUQ19TVEFSVF9QSUNLRVJcIixcbiAgQ0FOQ0VMX1BJQ0tFUjogXCJGVENfQ0FOQ0VMX1BJQ0tFUlwiLFxuICBFTEVNRU5UX1NFTEVDVEVEOiBcIkZUQ19FTEVNRU5UX1NFTEVDVEVEXCIsXG4gIEdFVF9DQU5ESURBVEVTOiBcIkZUQ19HRVRfQ0FORElEQVRFU1wiLFxuICBDQU5ESURBVEVTX1JFU1VMVDogXCJGVENfQ0FORElEQVRFU19SRVNVTFRcIixcbiAgRlRDX0VYVEVOU0lPTl9UT0tFTjogXCJGVENfRVhURU5TSU9OX1RPS0VOXCIsXG4gIEFVVEhfVEFCX09QRU5FRDogXCJGVENfQVVUSF9UQUJfT1BFTkVEXCIsXG59IGFzIGNvbnN0O1xuIiwgImltcG9ydCB7IFRPS0VOX1NUT1JBR0VfS0VZLCBUT0tFTl9FWFBJUllfS0VZIH0gZnJvbSBcIi4uL3NoYXJlZC9jb25zdGFudHNcIjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRva2VuKCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1RPS0VOX1NUT1JBR0VfS0VZLCBUT0tFTl9FWFBJUllfS0VZXSk7XG4gIGNvbnN0IHRva2VuID0gcmVzdWx0W1RPS0VOX1NUT1JBR0VfS0VZXTtcbiAgY29uc3QgZXhwaXJ5ID0gcmVzdWx0W1RPS0VOX0VYUElSWV9LRVldO1xuXG4gIGlmICghdG9rZW4gfHwgIWV4cGlyeSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgZXhwaXJ5TXMgPSBuZXcgRGF0ZShleHBpcnkpLmdldFRpbWUoKTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoZXhwaXJ5TXMpIHx8IGV4cGlyeU1zIDwgRGF0ZS5ub3coKSkge1xuICAgIGF3YWl0IGNsZWFyVG9rZW4oKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiB0b2tlbjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFRva2VuKHRva2VuOiBzdHJpbmcsIGV4cGlyZXNBdDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgW1RPS0VOX1NUT1JBR0VfS0VZXTogdG9rZW4sXG4gICAgW1RPS0VOX0VYUElSWV9LRVldOiBleHBpcmVzQXQsXG4gIH0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJUb2tlbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFtUT0tFTl9TVE9SQUdFX0tFWSwgVE9LRU5fRVhQSVJZX0tFWV0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNUb2tlblZhbGlkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIHJldHVybiB0b2tlbiAhPT0gbnVsbDtcbn1cbiIsICJleHBvcnQgZnVuY3Rpb24gZXNjYXBlQXR0cihzdHI6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzdHIucmVwbGFjZSgvJi9nLCBcIiZhbXA7XCIpLnJlcGxhY2UoL1wiL2csIFwiJnF1b3Q7XCIpLnJlcGxhY2UoLycvZywgXCImIzM5O1wiKS5yZXBsYWNlKC88L2csIFwiJmx0O1wiKS5yZXBsYWNlKC8+L2csIFwiJmd0O1wiKTtcbn1cblxuLy8gS2VlcCBpbiBzeW5jIHdpdGggc2hhcmVkL21vZGVscy9hdXRoLnRzIFRJRVJfTElNSVRTXG5jb25zdCBLTk9XTl9USUVSUyA9IFtcImZyZWVcIiwgXCJwcm9cIiwgXCJwb3dlclwiXTtcbmV4cG9ydCBmdW5jdGlvbiBzYW5pdGl6ZVRpZXIodGllcjogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIEtOT1dOX1RJRVJTLmluY2x1ZGVzKHRpZXIpID8gdGllciA6IFwiZnJlZVwiO1xufVxuIiwgImltcG9ydCB7IEJBU0VfVVJMLCBNU0csIEFVVEhfU1RBUlRFRF9LRVksIFRPS0VOX1NUT1JBR0VfS0VZLCBQRU5ESU5HX1NFTEVDVElPTl9LRVkgfSBmcm9tIFwiLi4vc2hhcmVkL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgZ2V0VG9rZW4sIGNsZWFyVG9rZW4sIGlzVG9rZW5WYWxpZCB9IGZyb20gXCIuLi9hdXRoL3Rva2VuXCI7XG5pbXBvcnQgeyBlc2NhcGVBdHRyLCBzYW5pdGl6ZVRpZXIgfSBmcm9tIFwiLi91dGlsc1wiO1xuXG5jb25zdCBUQUcgPSBcIltGVEM6cG9wdXBdXCI7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gU3RhdGVcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5pbnRlcmZhY2UgVXNlckluZm8ge1xuICB1c2VySWQ6IHN0cmluZztcbiAgdGllcjogc3RyaW5nO1xuICBlbWFpbDogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgU2VsZWN0aW9uIHtcbiAgc2VsZWN0b3I6IHN0cmluZztcbiAgY3VycmVudFZhbHVlOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xuICBwYWdlVGl0bGU6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIENhbmRpZGF0ZSB7XG4gIHNlbGVjdG9yOiBzdHJpbmc7XG4gIHRleHQ6IHN0cmluZztcbiAgc2NvcmU6IG51bWJlcjtcbn1cblxudHlwZSBQb3B1cFN0YXRlID1cbiAgfCBcInVuYXV0aGVudGljYXRlZFwiXG4gIHwgXCJjb25uZWN0aW5nXCJcbiAgfCBcImF1dGhfZmFpbGVkXCJcbiAgfCBcImF1dGhlbnRpY2F0ZWRcIlxuICB8IFwicGlja2luZ1wiXG4gIHwgXCJjb25maXJtXCI7XG5cbmxldCBzdGF0ZTogUG9wdXBTdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG5sZXQgdXNlckluZm86IFVzZXJJbmZvIHwgbnVsbCA9IG51bGw7XG5sZXQgc2VsZWN0aW9uOiBTZWxlY3Rpb24gfCBudWxsID0gbnVsbDtcbmxldCBjYW5kaWRhdGVzOiBDYW5kaWRhdGVbXSA9IFtdO1xubGV0IGN1cnJlbnRUYWJVcmwgPSBcIlwiO1xubGV0IGN1cnJlbnRUYWJUaXRsZSA9IFwiXCI7XG5sZXQgY3VycmVudFRhYklkID0gMDtcbmxldCBkcm9wZG93bk9wZW4gPSBmYWxzZTtcblxuY29uc3QgY29udGVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29udGVudFwiKSE7XG5jb25zdCBhY2NvdW50QXJlYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWNjb3VudC1hcmVhXCIpITtcblxuLy8gSG93IGxvbmcgd2UgY29uc2lkZXIgYW4gYXV0aCBhdHRlbXB0IFwicmVjZW50XCIgXHUyMDE0IGlmIG5vIHRva2VuIHdhcyBzdG9yZWRcbi8vIHdpdGhpbiB0aGlzIHdpbmRvdywgd2Ugc2hvdyBhbiBlcnJvciBpbnN0ZWFkIG9mIHRoZSBkZWZhdWx0IGNvbm5lY3Qgc2NyZWVuLlxuLy8gTXVzdCBtYXRjaCB0aGUgU1cncyBmYWxsYmFjayB3aW5kb3cgKDEyMCBzIGluIHNlcnZpY2Utd29ya2VyLnRzIG9uVXBkYXRlZCkuXG5jb25zdCBBVVRIX1RJTUVPVVRfTVMgPSAxMjBfMDAwO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIEluaXRpYWxpc2Vcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5sZXQgaW5pdFJ1bm5pbmcgPSBmYWxzZTtcbmxldCBpbml0UGVuZGluZyA9IGZhbHNlO1xuXG5hc3luYyBmdW5jdGlvbiBpbml0KCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaW5pdFJ1bm5pbmcpIHtcbiAgICBpbml0UGVuZGluZyA9IHRydWU7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImluaXQgYWxyZWFkeSBydW5uaW5nLCBxdWV1ZWluZyByZXJ1blwiKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaW5pdFJ1bm5pbmcgPSB0cnVlO1xuICBjb25zb2xlLmxvZyhUQUcsIFwiaW5pdCBzdGFydFwiKTtcbiAgdHJ5IHtcblxuICAvLyBHZXQgY3VycmVudCB0YWIgaW5mb1xuICBjb25zdCBbdGFiXSA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICBpZiAodGFiKSB7XG4gICAgY3VycmVudFRhYlVybCA9IHRhYi51cmwgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiVGl0bGUgPSB0YWIudGl0bGUgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiSWQgPSB0YWIuaWQgfHwgMDtcbiAgfVxuXG4gIGNvbnN0IHZhbGlkID0gYXdhaXQgaXNUb2tlblZhbGlkKCk7XG4gIGlmICghdmFsaWQpIHtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwibm8gdmFsaWQgdG9rZW4gaW4gc3RvcmFnZVwiKTtcblxuICAgIC8vIENoZWNrIGlmIGFuIGF1dGggYXR0ZW1wdCB3YXMgcmVjZW50bHkgc3RhcnRlZC5cbiAgICAvLyBTaG93IFwiY29ubmVjdGluZ1wiIGZvciB0aGUgZmlyc3QgMzAgcyAoYXV0aCBtYXkgc3RpbGwgYmUgaW4gcHJvZ3Jlc3MpLFxuICAgIC8vIHRoZW4gXCJhdXRoX2ZhaWxlZFwiIHVwIHRvIEFVVEhfVElNRU9VVF9NUy5cbiAgICBjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoQVVUSF9TVEFSVEVEX0tFWSk7XG4gICAgY29uc3Qgc3RhcnRlZEF0ID0gTnVtYmVyKHN0b3JlZFtBVVRIX1NUQVJURURfS0VZXSk7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBzdGFydGVkQXQ7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShzdGFydGVkQXQpICYmIGVsYXBzZWQgPCBBVVRIX1RJTUVPVVRfTVMpIHtcbiAgICAgIGlmIChlbGFwc2VkIDwgMzBfMDAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFRBRywgXCJhdXRoIGF0dGVtcHQgaW4gcHJvZ3Jlc3MgKFwiLCBNYXRoLnJvdW5kKGVsYXBzZWQgLyAxMDAwKSwgXCJzIGFnbylcIik7XG4gICAgICAgIHN0YXRlID0gXCJjb25uZWN0aW5nXCI7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLndhcm4oVEFHLCBcInJlY2VudCBhdXRoIGF0dGVtcHQgZm91bmQgYnV0IG5vIHRva2VuIFx1MjAxNCBzaG93aW5nIGZhaWx1cmUgc3RhdGVcIik7XG4gICAgICAgIHN0YXRlID0gXCJhdXRoX2ZhaWxlZFwiO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuXG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gVmVyaWZ5IHRva2VuIHdpdGggYmFja2VuZFxuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIGlmICghdG9rZW4pIHtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwiZ2V0VG9rZW4gcmV0dXJuZWQgbnVsbCBkZXNwaXRlIGlzVG9rZW5WYWxpZFwiKTtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc29sZS5sb2coVEFHLCBcInZlcmlmeWluZyB0b2tlbiB3aXRoIGJhY2tlbmQuLi5cIik7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L2FwaS9leHRlbnNpb24vdmVyaWZ5YCwge1xuICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICAgIH0pO1xuXG4gICAgaWYgKCFyZXMub2spIHtcbiAgICAgIGNvbnNvbGUud2FybihUQUcsIFwidmVyaWZ5IHJldHVybmVkXCIsIHJlcy5zdGF0dXMpO1xuICAgICAgYXdhaXQgY2xlYXJUb2tlbigpO1xuICAgICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdXNlckluZm8gPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgIGlmICghdXNlckluZm8gfHwgdHlwZW9mIHVzZXJJbmZvLnVzZXJJZCAhPT0gXCJzdHJpbmdcIiB8fCB0eXBlb2YgdXNlckluZm8udGllciAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgY29uc29sZS53YXJuKFRBRywgXCJ2ZXJpZnkgcmVzcG9uc2UgbWFsZm9ybWVkOlwiLCB1c2VySW5mbyk7XG4gICAgICBhd2FpdCBjbGVhclRva2VuKCk7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gQ2FjaGUgdXNlckluZm8gZm9yIG9mZmxpbmUgZmFsbGJhY2tcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBjYWNoZWRVc2VySW5mbzogdXNlckluZm8gfSk7XG4gICAgLy8gQ2xlYXIgYW55IHN0YWxlIGF1dGgtc3RhcnRlZCBmbGFnXG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKEFVVEhfU1RBUlRFRF9LRVkpO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImF1dGhlbnRpY2F0ZWQgYXNcIiwgdXNlckluZm8uZW1haWwpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oVEFHLCBcInZlcmlmeSBuZXR3b3JrIGVycm9yOlwiLCBlcnIpO1xuICAgIC8vIE5ldHdvcmsgZXJyb3IgXHUyMDE0IHRyeSB0byByZXN0b3JlIGNhY2hlZCB1c2VySW5mbyBzbyB0aWVyL2FjY291bnQgZGlzcGxheSBjb3JyZWN0bHlcbiAgICBjb25zdCBjYWNoZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICBjb25zdCBjID0gY2FjaGVkLmNhY2hlZFVzZXJJbmZvO1xuICAgIGlmIChjICYmIHR5cGVvZiBjLnVzZXJJZCA9PT0gXCJzdHJpbmdcIiAmJiB0eXBlb2YgYy50aWVyID09PSBcInN0cmluZ1wiICYmIHR5cGVvZiBjLmVtYWlsID09PSBcInN0cmluZ1wiKSB7XG4gICAgICB1c2VySW5mbyA9IGM7XG4gICAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuICB9XG5cbiAgLy8gQ2hlY2sgZm9yIGEgcGVuZGluZyBlbGVtZW50IHNlbGVjdGlvbiBsZWZ0IGJ5IHRoZSBzZXJ2aWNlIHdvcmtlclxuICAvLyAodGhlIHBvcHVwIHdhcyBjbG9zZWQgd2hlbiB0aGUgdXNlciBjbGlja2VkIGFuIGVsZW1lbnQgb24gdGhlIHBhZ2UpLlxuICAvLyBEaXNjYXJkIHNlbGVjdGlvbnMgb2xkZXIgdGhhbiAxMCBtaW51dGVzIHRvIGF2b2lkIGNvbmZ1c2luZyBzdGFsZSBzdGF0ZS5cbiAgaWYgKHN0YXRlID09PSBcImF1dGhlbnRpY2F0ZWRcIikge1xuICAgIGNvbnN0IHBlbmRpbmcgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoUEVORElOR19TRUxFQ1RJT05fS0VZKTtcbiAgICBjb25zdCBzdG9yZWQgPSBwZW5kaW5nW1BFTkRJTkdfU0VMRUNUSU9OX0tFWV07XG4gICAgaWYgKHN0b3JlZCAmJiB0eXBlb2Ygc3RvcmVkLnNlbGVjdG9yID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zdCBhZ2UgPSBzdG9yZWQudGltZXN0YW1wID8gRGF0ZS5ub3coKSAtIHN0b3JlZC50aW1lc3RhbXAgOiBJbmZpbml0eTtcbiAgICAgIC8vIENsZWFyIGltbWVkaWF0ZWx5IHNvIHN0YWxlIHNlbGVjdGlvbnMgZG9uJ3QgcGVyc2lzdFxuICAgICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFBFTkRJTkdfU0VMRUNUSU9OX0tFWSk7XG4gICAgICBpZiAoYWdlIDwgNjAwXzAwMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhUQUcsIFwicGVuZGluZyBzZWxlY3Rpb24gZm91bmQgaW4gc3RvcmFnZSwganVtcGluZyB0byBjb25maXJtXCIpO1xuICAgICAgICBzZWxlY3Rpb24gPSB7XG4gICAgICAgICAgc2VsZWN0b3I6IHN0b3JlZC5zZWxlY3RvcixcbiAgICAgICAgICBjdXJyZW50VmFsdWU6IHR5cGVvZiBzdG9yZWQuY3VycmVudFZhbHVlID09PSBcInN0cmluZ1wiID8gc3RvcmVkLmN1cnJlbnRWYWx1ZSA6IFwiXCIsXG4gICAgICAgICAgdXJsOiB0eXBlb2Ygc3RvcmVkLnVybCA9PT0gXCJzdHJpbmdcIiA/IHN0b3JlZC51cmwgOiBjdXJyZW50VGFiVXJsLFxuICAgICAgICAgIHBhZ2VUaXRsZTogdHlwZW9mIHN0b3JlZC5wYWdlVGl0bGUgPT09IFwic3RyaW5nXCIgPyBzdG9yZWQucGFnZVRpdGxlIDogY3VycmVudFRhYlRpdGxlLFxuICAgICAgICB9O1xuICAgICAgICBzdGF0ZSA9IFwiY29uZmlybVwiO1xuICAgICAgICByZW5kZXIoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coVEFHLCBcInBlbmRpbmcgc2VsZWN0aW9uIHRvbyBvbGQgKFwiLCBNYXRoLnJvdW5kKGFnZSAvIDEwMDApLCBcInMpLCBkaXNjYXJkaW5nXCIpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJlbmRlcigpO1xuICB9IGZpbmFsbHkge1xuICAgIGluaXRSdW5uaW5nID0gZmFsc2U7XG4gICAgaWYgKGluaXRQZW5kaW5nKSB7XG4gICAgICBpbml0UGVuZGluZyA9IGZhbHNlO1xuICAgICAgLy8gRG9uJ3QgcmUtcnVuIGluaXQgaWYgd2UgYWxyZWFkeSByZWFjaGVkIGNvbmZpcm0gXHUyMDE0IHRoZSB1c2VyIGlzXG4gICAgICAvLyBsb29raW5nIGF0IHRoZSBjb25maXJtIHNjcmVlbiBhbmQgYSByZS1pbml0IHdvdWxkIGNsb2JiZXIgaXQuXG4gICAgICBpZiAoc3RhdGUgIT09IFwiY29uZmlybVwiKSB7XG4gICAgICAgIHZvaWQgaW5pdCgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIExpc3RlbiBmb3IgbWVzc2FnZXMgZnJvbSBiYWNrZ3JvdW5kL2NvbnRlbnRcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UpID0+IHtcbiAgaWYgKG1lc3NhZ2UudHlwZSA9PT0gTVNHLkVMRU1FTlRfU0VMRUNURUQpIHtcbiAgICBjb25zdCBzZWwgPSB0eXBlb2YgbWVzc2FnZS5zZWxlY3RvciA9PT0gXCJzdHJpbmdcIiA/IG1lc3NhZ2Uuc2VsZWN0b3IudHJpbSgpLnNsaWNlKDAsIDUwMCkgOiBcIlwiO1xuICAgIGlmICghc2VsKSByZXR1cm47XG4gICAgc2VsZWN0aW9uID0ge1xuICAgICAgc2VsZWN0b3I6IHNlbCxcbiAgICAgIGN1cnJlbnRWYWx1ZTogdHlwZW9mIG1lc3NhZ2UuY3VycmVudFZhbHVlID09PSBcInN0cmluZ1wiID8gbWVzc2FnZS5jdXJyZW50VmFsdWUuc2xpY2UoMCwgNTAwKSA6IFwiXCIsXG4gICAgICB1cmw6IHR5cGVvZiBtZXNzYWdlLnVybCA9PT0gXCJzdHJpbmdcIiA/IG1lc3NhZ2UudXJsLnNsaWNlKDAsIDIwMDApIDogY3VycmVudFRhYlVybCxcbiAgICAgIHBhZ2VUaXRsZTogdHlwZW9mIG1lc3NhZ2UucGFnZVRpdGxlID09PSBcInN0cmluZ1wiID8gbWVzc2FnZS5wYWdlVGl0bGUuc2xpY2UoMCwgMjAwKSA6IGN1cnJlbnRUYWJUaXRsZSxcbiAgICB9O1xuICAgIHN0YXRlID0gXCJjb25maXJtXCI7XG4gICAgcmVuZGVyKCk7XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuQ0FORElEQVRFU19SRVNVTFQpIHtcbiAgICBjYW5kaWRhdGVzID0gbWVzc2FnZS5jYW5kaWRhdGVzIHx8IFtdO1xuICAgIGlmIChzdGF0ZSA9PT0gXCJhdXRoZW50aWNhdGVkXCIgfHwgc3RhdGUgPT09IFwicGlja2luZ1wiKSB7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuQ0FOQ0VMX1BJQ0tFUikge1xuICAgIGlmIChzdGF0ZSA9PT0gXCJwaWNraW5nXCIpIHtcbiAgICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBcIkZUQ19BVVRIX0NPTVBMRVRFXCIpIHtcbiAgICAvLyBSZS1pbml0aWFsaXNlIGFmdGVyIGF1dGhcbiAgICBpbml0KCk7XG4gIH1cbn0pO1xuXG4vLyBBbHNvIGxpc3RlbiBmb3IgZGlyZWN0IHN0b3JhZ2Ugd3JpdGVzIChlLmcuIGZyb20gYXV0aC1yZWxheSBjb250ZW50IHNjcmlwdFxuLy8gd3JpdGluZyB0aGUgdG9rZW4gZGlyZWN0bHksIGJ5cGFzc2luZyB0aGUgc2VydmljZSB3b3JrZXIpLlxuY2hyb21lLnN0b3JhZ2Uub25DaGFuZ2VkLmFkZExpc3RlbmVyKChjaGFuZ2VzLCBhcmVhKSA9PiB7XG4gIGlmIChhcmVhICE9PSBcImxvY2FsXCIpIHJldHVybjtcbiAgaWYgKGNoYW5nZXNbVE9LRU5fU1RPUkFHRV9LRVldPy5uZXdWYWx1ZSkge1xuICAgIGNvbnNvbGUubG9nKFRBRywgXCJ0b2tlbiBhcHBlYXJlZCBpbiBzdG9yYWdlIChkaXJlY3Qgd3JpdGUpLCByZS1pbml0aWFsaXNpbmcuLi5cIik7XG4gICAgdm9pZCBpbml0KCk7XG4gIH1cbiAgaWYgKGNoYW5nZXNbUEVORElOR19TRUxFQ1RJT05fS0VZXT8ubmV3VmFsdWUgJiYgc3RhdGUgIT09IFwiY29uZmlybVwiKSB7XG4gICAgY29uc29sZS5sb2coVEFHLCBcInBlbmRpbmcgc2VsZWN0aW9uIGFwcGVhcmVkIGluIHN0b3JhZ2UsIHJlLWluaXRpYWxpc2luZy4uLlwiKTtcbiAgICB2b2lkIGluaXQoKTtcbiAgfVxufSk7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gUmVuZGVyXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZnVuY3Rpb24gcmVuZGVyKCk6IHZvaWQge1xuICByZW5kZXJBY2NvdW50KCk7XG5cbiAgc3dpdGNoIChzdGF0ZSkge1xuICAgIGNhc2UgXCJ1bmF1dGhlbnRpY2F0ZWRcIjpcbiAgICAgIHJlbmRlclVuYXV0aCgpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImNvbm5lY3RpbmdcIjpcbiAgICAgIHJlbmRlckNvbm5lY3RpbmcoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJhdXRoX2ZhaWxlZFwiOlxuICAgICAgcmVuZGVyQXV0aEZhaWxlZCgpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImF1dGhlbnRpY2F0ZWRcIjpcbiAgICAgIHJlbmRlckF1dGhlbnRpY2F0ZWQoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJwaWNraW5nXCI6XG4gICAgICByZW5kZXJQaWNraW5nKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiY29uZmlybVwiOlxuICAgICAgcmVuZGVyQ29uZmlybSgpO1xuICAgICAgYnJlYWs7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyQWNjb3VudCgpOiB2b2lkIHtcbiAgaWYgKCF1c2VySW5mbykge1xuICAgIGFjY291bnRBcmVhLmlubmVySFRNTCA9IFwiXCI7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgYWNjb3VudEFyZWEuaW5uZXJIVE1MID0gYFxuICAgIDxidXR0b24gY2xhc3M9XCJhY2NvdW50LWJ0blwiIGlkPVwiYWNjb3VudC10b2dnbGVcIj5cbiAgICAgICR7ZXNjYXBlSHRtbCh1c2VySW5mby5lbWFpbCB8fCBcIkNvbm5lY3RlZFwiKX0gJiM5NjYyO1xuICAgIDwvYnV0dG9uPlxuICAgIDxkaXYgY2xhc3M9XCJhY2NvdW50LWRyb3Bkb3duICR7ZHJvcGRvd25PcGVuID8gXCJcIiA6IFwiaGlkZGVuXCJ9XCIgaWQ9XCJhY2NvdW50LWRyb3Bkb3duXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiZHJvcGRvd24tZW1haWxcIj5cbiAgICAgICAgJHtlc2NhcGVIdG1sKHVzZXJJbmZvLmVtYWlsIHx8IHVzZXJJbmZvLnVzZXJJZCl9XG4gICAgICAgIDxzcGFuIGNsYXNzPVwidGllci1iYWRnZSB0aWVyLSR7c2FuaXRpemVUaWVyKHVzZXJJbmZvLnRpZXIpfVwiPiR7ZXNjYXBlSHRtbCh1c2VySW5mby50aWVyKX08L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIGhyZWY9XCIke0JBU0VfVVJMfS9kYXNoYm9hcmRcIiB0YXJnZXQ9XCJfYmxhbmtcIj5PcGVuIGRhc2hib2FyZDwvYT5cbiAgICAgIDxkaXYgY2xhc3M9XCJkcm9wZG93bi1kaXZpZGVyXCI+PC9kaXY+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIGlkPVwiZGlzY29ubmVjdC1idG5cIj5EaXNjb25uZWN0PC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhY2NvdW50LXRvZ2dsZVwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIChlKSA9PiB7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBkcm9wZG93bk9wZW4gPSAhZHJvcGRvd25PcGVuO1xuICAgIHJlbmRlckFjY291bnQoKTtcbiAgfSk7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkaXNjb25uZWN0LWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBjbGVhclRva2VuKCk7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFwiY2FjaGVkVXNlckluZm9cIik7XG4gICAgdXNlckluZm8gPSBudWxsO1xuICAgIGRyb3Bkb3duT3BlbiA9IGZhbHNlO1xuICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG5cbiAgLy8gQ2xvc2UgZHJvcGRvd24gb24gY2xpY2sgb3V0c2lkZVxuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGlmIChkcm9wZG93bk9wZW4pIHtcbiAgICAgIGRyb3Bkb3duT3BlbiA9IGZhbHNlO1xuICAgICAgcmVuZGVyQWNjb3VudCgpO1xuICAgIH1cbiAgfSwgeyBvbmNlOiB0cnVlIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJVbmF1dGgoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJ1bmF1dGhcIj5cbiAgICAgIDxoMj5UcmFjayB3aGF0IG1hdHRlcnMgb24gYW55IHdlYnBhZ2UuPC9oMj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLWZ1bGxcIiBpZD1cImNvbm5lY3QtYnRuXCI+Q29ubmVjdCB5b3VyIGFjY291bnQ8L2J1dHRvbj5cbiAgICAgIDxwPkFscmVhZHkgaGF2ZSBhbiBhY2NvdW50PyBTaWduIGluIGFib3ZlLjwvcD5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNvbm5lY3QtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgc3RhcnRBdXRoRmxvdyk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckF1dGhGYWlsZWQoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJ1bmF1dGhcIj5cbiAgICAgIDxoMj5Db25uZWN0aW9uIGZhaWxlZDwvaDI+XG4gICAgICA8cD5XZSBjb3VsZG4ndCBjb25uZWN0IHRoZSBleHRlbnNpb24gdG8geW91ciBhY2NvdW50LiBUaGlzIGNhbiBoYXBwZW4gaWYgeW91ciBicm93c2VyIGJsb2NrZWQgdGhlIGNvbm5lY3Rpb24uPC9wPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbFwiIGlkPVwicmV0cnktY29ubmVjdC1idG5cIj5UcnkgYWdhaW48L2J1dHRvbj5cbiAgICAgIDxwIHN0eWxlPVwibWFyZ2luLXRvcDogMTJweDsgZm9udC1zaXplOiAxMnB4OyBvcGFjaXR5OiAwLjc7XCI+XG4gICAgICAgIFRpcDogd2hlbiBDaHJvbWUgYXNrcyB0byBhbGxvdyBhY2Nlc3MgdG8gZnRjLmJkNzMuY29tLCBjbGljayA8c3Ryb25nPkFsbG93PC9zdHJvbmc+LlxuICAgICAgPC9wPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicmV0cnktY29ubmVjdC1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBzdGFydEF1dGhGbG93KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRBdXRoRmxvdygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc29sZS5sb2coVEFHLCBcInN0YXJ0aW5nIGF1dGggZmxvd1wiKTtcblxuICAvLyBDaHJvbWUgMTI3KyB0cmVhdHMgaG9zdF9wZXJtaXNzaW9ucyBhcyBvcHRpb25hbC5cbiAgLy8gUmVxdWVzdCB0aGUgcGVybWlzc2lvbiBzbyB0aGUgYXV0aC1yZWxheSBjb250ZW50IHNjcmlwdCBnZXRzIGluamVjdGVkLlxuICBsZXQgcGVybWlzc2lvbkdyYW50ZWQgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICBjb25zdCBvcmlnaW4gPSBuZXcgVVJMKEJBU0VfVVJMKS5vcmlnaW47XG4gICAgcGVybWlzc2lvbkdyYW50ZWQgPSBhd2FpdCBjaHJvbWUucGVybWlzc2lvbnMuY29udGFpbnMoeyBvcmlnaW5zOiBbYCR7b3JpZ2lufS8qYF0gfSk7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImhvc3QgcGVybWlzc2lvbiBhbHJlYWR5IGdyYW50ZWQ6XCIsIHBlcm1pc3Npb25HcmFudGVkKTtcbiAgICBpZiAoIXBlcm1pc3Npb25HcmFudGVkKSB7XG4gICAgICBwZXJtaXNzaW9uR3JhbnRlZCA9IGF3YWl0IGNocm9tZS5wZXJtaXNzaW9ucy5yZXF1ZXN0KHsgb3JpZ2luczogW2Ake29yaWdpbn0vKmBdIH0pO1xuICAgICAgY29uc29sZS5sb2coVEFHLCBcImhvc3QgcGVybWlzc2lvbiByZXF1ZXN0IHJlc3VsdDpcIiwgcGVybWlzc2lvbkdyYW50ZWQpO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKFRBRywgXCJwZXJtaXNzaW9uIHJlcXVlc3QgZXJyb3I6XCIsIGVycik7XG4gICAgLy8gRmFsbGJhY2sgYXV0aCBzdGlsbCB3b3JrcyB3aXRob3V0IHRoZSBwZXJtaXNzaW9uXG4gIH1cblxuICAvLyBSZWNvcmQgdGhhdCB3ZSBzdGFydGVkIGFuIGF1dGggYXR0ZW1wdCBzbyBpZiB0aGUgcG9wdXBcbiAgLy8gcmUtb3BlbnMgd2l0aG91dCBhIHRva2VuLCB3ZSBjYW4gc2hvdyBhbiBlcnJvciBpbnN0ZWFkIG9mXG4gIC8vIHRoZSBnZW5lcmljIFwiQ29ubmVjdCB5b3VyIGFjY291bnRcIiBzY3JlZW4uXG4gIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtBVVRIX1NUQVJURURfS0VZXTogRGF0ZS5ub3coKSB9KTtcblxuICBsZXQgdGFiOiBjaHJvbWUudGFicy5UYWI7XG4gIHRyeSB7XG4gICAgdGFiID0gYXdhaXQgY2hyb21lLnRhYnMuY3JlYXRlKHsgdXJsOiBgJHtCQVNFX1VSTH0vZXh0ZW5zaW9uLWF1dGhgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKFRBRywgXCJmYWlsZWQgdG8gb3BlbiBhdXRoIHRhYjpcIiwgZXJyKTtcbiAgICBzdGF0ZSA9IFwiYXV0aF9mYWlsZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc29sZS5sb2coVEFHLCBcImF1dGggdGFiIGNyZWF0ZWQ6XCIsIHRhYi5pZCk7XG5cbiAgLy8gVGVsbCB0aGUgc2VydmljZSB3b3JrZXIgd2hpY2ggdGFiIHRvIHdhdGNoXG4gIGlmICh0YWIuaWQpIHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5BVVRIX1RBQl9PUEVORUQsIHRhYklkOiB0YWIuaWQgfSkuY2F0Y2goKGVycikgPT5cbiAgICAgIGNvbnNvbGUud2FybihUQUcsIFwiZmFpbGVkIHRvIG5vdGlmeSBzZXJ2aWNlIHdvcmtlciBvZiBhdXRoIHRhYjpcIiwgZXJyKSxcbiAgICApO1xuICB9XG5cbiAgc3RhdGUgPSBcImNvbm5lY3RpbmdcIjtcbiAgcmVuZGVyKCk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckNvbm5lY3RpbmcoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjb25uZWN0aW5nXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lclwiPjwvZGl2PlxuICAgICAgPHA+Q29ubmVjdGluZy4uLjwvcD5cbiAgICAgIDxwPldhaXRpbmcgZm9yIHlvdSB0byBzaWduIGluIGF0IEZldGNoVGhlQ2hhbmdlLjwvcD5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cImNhbmNlbC1jb25uZWN0XCIgc3R5bGU9XCJtYXJnaW4tdG9wOiAxNnB4O1wiPkNhbmNlbDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY2FuY2VsLWNvbm5lY3RcIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKEFVVEhfU1RBUlRFRF9LRVkpO1xuICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckF1dGhlbnRpY2F0ZWQoKTogdm9pZCB7XG4gIGNvbnN0IHRydW5jYXRlZFVybCA9IGN1cnJlbnRUYWJVcmwubGVuZ3RoID4gNDVcbiAgICA/IGN1cnJlbnRUYWJVcmwuc2xpY2UoMCwgNDUpICsgXCIuLi5cIlxuICAgIDogY3VycmVudFRhYlVybDtcblxuICBsZXQgY2FuZGlkYXRlc0h0bWwgPSBcIlwiO1xuICBpZiAoY2FuZGlkYXRlcy5sZW5ndGggPiAwKSB7XG4gICAgY2FuZGlkYXRlc0h0bWwgPSBgXG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvbi1oZWFkZXJcIj5TdWdnZXN0ZWQgZWxlbWVudHM8L2Rpdj5cbiAgICAgICR7Y2FuZGlkYXRlc1xuICAgICAgICAubWFwKFxuICAgICAgICAgIChjLCBpKSA9PiBgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYW5kaWRhdGVcIiBkYXRhLWlkeD1cIiR7aX1cIj5cbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImNhbmRpZGF0ZS10ZXh0XCI+JHtlc2NhcGVIdG1sKGMudGV4dCl9PC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY2FuZGlkYXRlLXNlbGVjdG9yXCI+JHtlc2NhcGVIdG1sKGMuc2VsZWN0b3IpfTwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbSBjYW5kaWRhdGUtdHJhY2tcIiBkYXRhLWlkeD1cIiR7aX1cIj5UcmFjayB0aGlzPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgYFxuICAgICAgICApXG4gICAgICAgIC5qb2luKFwiXCIpfVxuICAgIGA7XG4gIH1cblxuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY3VycmVudC11cmxcIj48c3Ryb25nPlRyYWNraW5nOjwvc3Ryb25nPiAke2VzY2FwZUh0bWwodHJ1bmNhdGVkVXJsKX08L2Rpdj5cbiAgICAke2NhbmRpZGF0ZXNIdG1sfVxuICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLWhlYWRlclwiPk9yIHBpY2sgbWFudWFsbHk8L2Rpdj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1mdWxsXCIgaWQ9XCJwaWNrLWJ0blwiPlBpY2sgYW4gZWxlbWVudCBvbiB0aGlzIHBhZ2U8L2J1dHRvbj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiYWR2YW5jZWQtdG9nZ2xlXCIgaWQ9XCJhZHZhbmNlZC10b2dnbGVcIj4mIzk2NjI7IEFkdmFuY2VkIChDU1Mgc2VsZWN0b3IpPC9idXR0b24+XG4gICAgPGRpdiBjbGFzcz1cImFkdmFuY2VkLWNvbnRlbnRcIiBpZD1cImFkdmFuY2VkLWNvbnRlbnRcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzPVwiZm9ybS1pbnB1dFwiIGlkPVwibWFudWFsLXNlbGVjdG9yXCIgcGxhY2Vob2xkZXI9XCJlLmcuIC5wcm9kdWN0LXByaWNlXCI+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cIm1hbnVhbC10cmFjay1idG5cIj5Vc2UgdGhpcyBzZWxlY3RvcjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIC8vIFBpY2sgZWxlbWVudCBidXR0b25cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwaWNrLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBpZiAoIWN1cnJlbnRUYWJVcmwuc3RhcnRzV2l0aChcImh0dHA6Ly9cIikgJiYgIWN1cnJlbnRUYWJVcmwuc3RhcnRzV2l0aChcImh0dHBzOi8vXCIpKSB7XG4gICAgICAvLyBTaG93IGlubGluZSB3YXJuaW5nIHdpdGhvdXQgbGVhdmluZyBhdXRoZW50aWNhdGVkIHN0YXRlIFx1MjAxNCB0aGUgZ2xvYmFsXG4gICAgICAvLyBcImVycm9yXCIgc3RhdGUgcmVuZGVycyBcIkNvdWxkbid0IGNyZWF0ZSBtb25pdG9yXCIgd2hpY2ggaXMgbWlzbGVhZGluZyBoZXJlLlxuICAgICAgY29uc3QgcGlja0J0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGljay1idG5cIik7XG4gICAgICBjb25zdCBleGlzdGluZyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIuZnRjLXBpY2tlci13YXJuaW5nXCIpO1xuICAgICAgaWYgKGV4aXN0aW5nKSBleGlzdGluZy5yZW1vdmUoKTtcbiAgICAgIGNvbnN0IHdhcm5pbmcgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgd2FybmluZy5jbGFzc05hbWUgPSBcImZ0Yy1waWNrZXItd2FybmluZ1wiO1xuICAgICAgd2FybmluZy5zdHlsZS5jc3NUZXh0ID0gXCJjb2xvcjogI2Y1OWUwYjsgZm9udC1zaXplOiAxM3B4OyBtYXJnaW4tdG9wOiA4cHg7IHBhZGRpbmc6IDhweDsgYm9yZGVyLXJhZGl1czogNnB4OyBiYWNrZ3JvdW5kOiByZ2JhKDI0NSwxNTgsMTEsMC4xKTtcIjtcbiAgICAgIHdhcm5pbmcudGV4dENvbnRlbnQgPSBcIlRoZSBwaWNrZXIgb25seSB3b3JrcyBvbiB3ZWIgcGFnZXMgKGh0dHAvaHR0cHMpLiBOYXZpZ2F0ZSB0byBhIHdlYnNpdGUgZmlyc3QuXCI7XG4gICAgICBwaWNrQnRuPy5hZnRlcih3YXJuaW5nKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiBNU0cuU1RBUlRfUElDS0VSLCB0YWJJZDogY3VycmVudFRhYklkIH0pO1xuICAgIHN0YXRlID0gXCJwaWNraW5nXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xuXG4gIC8vIENhbmRpZGF0ZSB0cmFjayBidXR0b25zXG4gIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuY2FuZGlkYXRlLXRyYWNrXCIpLmZvckVhY2goKGJ0bikgPT4ge1xuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgICAgIGNvbnN0IGlkeCA9IHBhcnNlSW50KChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkuZGF0YXNldC5pZHggfHwgXCIwXCIpO1xuICAgICAgY29uc3QgYyA9IGNhbmRpZGF0ZXNbaWR4XTtcbiAgICAgIGlmIChjKSB7XG4gICAgICAgIHNlbGVjdGlvbiA9IHtcbiAgICAgICAgICBzZWxlY3RvcjogYy5zZWxlY3RvcixcbiAgICAgICAgICBjdXJyZW50VmFsdWU6IGMudGV4dCxcbiAgICAgICAgICB1cmw6IGN1cnJlbnRUYWJVcmwsXG4gICAgICAgICAgcGFnZVRpdGxlOiBjdXJyZW50VGFiVGl0bGUsXG4gICAgICAgIH07XG4gICAgICAgIHN0YXRlID0gXCJjb25maXJtXCI7XG4gICAgICAgIHJlbmRlcigpO1xuICAgICAgfVxuICAgIH0pO1xuICB9KTtcblxuICAvLyBBZHZhbmNlZCB0b2dnbGVcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhZHZhbmNlZC10b2dnbGVcIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImFkdmFuY2VkLWNvbnRlbnRcIik7XG4gICAgZWw/LmNsYXNzTGlzdC50b2dnbGUoXCJvcGVuXCIpO1xuICB9KTtcblxuICAvLyBNYW51YWwgc2VsZWN0b3JcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtYW51YWwtdHJhY2stYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGNvbnN0IGlucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtYW51YWwtc2VsZWN0b3JcIikgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICBjb25zdCBzZWxlY3RvciA9IGlucHV0Py52YWx1ZS50cmltKCk7XG4gICAgaWYgKHNlbGVjdG9yKSB7XG4gICAgICBzZWxlY3Rpb24gPSB7XG4gICAgICAgIHNlbGVjdG9yLFxuICAgICAgICBjdXJyZW50VmFsdWU6IFwiXCIsXG4gICAgICAgIHVybDogY3VycmVudFRhYlVybCxcbiAgICAgICAgcGFnZVRpdGxlOiBcIlwiLFxuICAgICAgfTtcbiAgICAgIHN0YXRlID0gXCJjb25maXJtXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJQaWNraW5nKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwicGlja2VyLWluZm9cIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJpY29uXCI+JiMxMjc5MTk7PC9kaXY+XG4gICAgICA8cD48c3Ryb25nPkNsaWNrIGFueSBlbGVtZW50IG9uIHRoZSBwYWdlIHRvIHRyYWNrIGl0Ljwvc3Ryb25nPjwvcD5cbiAgICAgIDxwPlByZXNzIEVzYyB0byBjYW5jZWwuPC9wPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGlkPVwiY2FuY2VsLXBpY2tcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDE2cHg7XCI+Q2FuY2VsIHBpY2tpbmc8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNhbmNlbC1waWNrXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogTVNHLkNBTkNFTF9QSUNLRVIsIHRhYklkOiBjdXJyZW50VGFiSWQgfSk7XG4gICAgc3RhdGUgPSBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckNvbmZpcm0oKTogdm9pZCB7XG4gIGlmICghc2VsZWN0aW9uKSByZXR1cm47XG5cbiAgY29uc3QgdGllciA9IHVzZXJJbmZvPy50aWVyIHx8IFwiZnJlZVwiO1xuICBjb25zdCBob3VybHlEaXNhYmxlZCA9IHRpZXIgPT09IFwiZnJlZVwiO1xuICBjb25zdCBkZWZhdWx0TmFtZSA9IChzZWxlY3Rpb24ucGFnZVRpdGxlIHx8IFwiXCIpLnNsaWNlKDAsIDEwMCk7XG5cbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImN1cnJlbnQtdXJsXCI+PHN0cm9uZz5UcmFja2luZzo8L3N0cm9uZz4gJHtlc2NhcGVIdG1sKFxuICAgICAgc2VsZWN0aW9uLnVybC5sZW5ndGggPiA0NSA/IHNlbGVjdGlvbi51cmwuc2xpY2UoMCwgNDUpICsgXCIuLi5cIiA6IHNlbGVjdGlvbi51cmxcbiAgICApfTwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJjb25maXJtLWNhcmRcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPkVsZW1lbnQgc2VsZWN0ZWQ8L2Rpdj5cbiAgICAgICR7XG4gICAgICAgIHNlbGVjdGlvbi5jdXJyZW50VmFsdWVcbiAgICAgICAgICA/IGA8ZGl2IGNsYXNzPVwidmFsdWVcIj5DdXJyZW50bHk6ICR7ZXNjYXBlSHRtbChzZWxlY3Rpb24uY3VycmVudFZhbHVlLnNsaWNlKDAsIDEwMCkpfTwvZGl2PmBcbiAgICAgICAgICA6IFwiXCJcbiAgICAgIH1cbiAgICAgIDxkaXYgY2xhc3M9XCJzZWxlY3RvclwiPiR7ZXNjYXBlSHRtbChzZWxlY3Rpb24uc2VsZWN0b3IpfTwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWxhYmVsXCI+TW9uaXRvciBuYW1lPC9sYWJlbD5cbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzPVwiZm9ybS1pbnB1dFwiIGlkPVwibW9uaXRvci1uYW1lXCIgdmFsdWU9XCIke2VzY2FwZUF0dHIoZGVmYXVsdE5hbWUpfVwiIG1heGxlbmd0aD1cIjEwMFwiPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWxhYmVsXCI+Q2hlY2sgZnJlcXVlbmN5PC9sYWJlbD5cbiAgICAgIDxkaXYgY2xhc3M9XCJyYWRpby1ncm91cFwiPlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJyYWRpby1sYWJlbFwiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwicmFkaW9cIiBuYW1lPVwiZnJlcXVlbmN5XCIgdmFsdWU9XCJkYWlseVwiIGNoZWNrZWQ+IERhaWx5XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDxsYWJlbCBjbGFzcz1cInJhZGlvLWxhYmVsICR7aG91cmx5RGlzYWJsZWQgPyBcImRpc2FibGVkXCIgOiBcIlwifVwiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwicmFkaW9cIiBuYW1lPVwiZnJlcXVlbmN5XCIgdmFsdWU9XCJob3VybHlcIiAke2hvdXJseURpc2FibGVkID8gXCJkaXNhYmxlZFwiIDogXCJcIn0+XG4gICAgICAgICAgSG91cmx5XG4gICAgICAgICAgJHtob3VybHlEaXNhYmxlZCA/ICc8c3BhbiBjbGFzcz1cInRvb2x0aXAtdGV4dFwiPihQcm8rKTwvc3Bhbj4nIDogXCJcIn1cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJidG4tcm93XCI+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnlcIiBpZD1cInBpY2stYWdhaW4tYnRuXCJcbiAgICAgICAgJHtzZWxlY3Rpb24udXJsICYmIHNlbGVjdGlvbi51cmwgIT09IGN1cnJlbnRUYWJVcmwgPyBcImRpc2FibGVkIHRpdGxlPVxcXCJTd2l0Y2ggdG8gdGhlIG9yaWdpbmFsIHRhYiB0byBwaWNrIGFnYWluXFxcIlwiIDogXCJcIn0+UGljayBhZ2FpbjwvYnV0dG9uPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiIGlkPVwiY3JlYXRlLWJ0blwiPkNyZWF0ZSBtb25pdG9yPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwaWNrLWFnYWluLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBzZWxlY3Rpb24gPSBudWxsO1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogTVNHLlNUQVJUX1BJQ0tFUiwgdGFiSWQ6IGN1cnJlbnRUYWJJZCB9KTtcbiAgICBzdGF0ZSA9IFwicGlja2luZ1wiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNyZWF0ZS1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBjcmVhdGVNb25pdG9yKTtcbn1cblxubGV0IGNyZWF0aW5nID0gZmFsc2U7XG5cbmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZU1vbml0b3IoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmICghc2VsZWN0aW9uIHx8IGNyZWF0aW5nKSByZXR1cm47XG4gIGNyZWF0aW5nID0gdHJ1ZTtcblxuICBjb25zdCBuYW1lSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1vbml0b3ItbmFtZVwiKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICBjb25zdCBuYW1lID0gbmFtZUlucHV0Py52YWx1ZS50cmltKCkgfHwgXCJVbnRpdGxlZCBtb25pdG9yXCI7XG5cbiAgLy8gT3BlbiB0aGUgZGFzaGJvYXJkIHdpdGggcHJlLWZpbGxlZCBxdWVyeSBwYXJhbXMgc28gdGhlIGZ1bGwgd2ViIFVJXG4gIC8vIGhhbmRsZXMgY3JlYXRpb24gKHRhZ3MsIGVtYWlsIG5vdGlmaWNhdGlvbnMsIHZhbGlkYXRpb24sIGV0Yy4pLlxuICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKCk7XG4gIHBhcmFtcy5zZXQoXCJ1cmxcIiwgc2VsZWN0aW9uLnVybCk7XG4gIHBhcmFtcy5zZXQoXCJzZWxlY3RvclwiLCBzZWxlY3Rpb24uc2VsZWN0b3IpO1xuICBpZiAobmFtZSAmJiBuYW1lICE9PSBcIlVudGl0bGVkIG1vbml0b3JcIikgcGFyYW1zLnNldChcIm5hbWVcIiwgbmFtZSk7XG5cbiAgdHJ5IHtcbiAgICBhd2FpdCBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6IGAke0JBU0VfVVJMfS9kYXNoYm9hcmQ/JHtwYXJhbXMudG9TdHJpbmcoKX1gIH0pO1xuICAgIHdpbmRvdy5jbG9zZSgpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKFRBRywgXCJmYWlsZWQgdG8gb3BlbiBkYXNoYm9hcmQgdGFiOlwiLCBlcnIpO1xuICAgIGNyZWF0aW5nID0gZmFsc2U7XG4gIH1cbn1cblxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIEhlbHBlcnNcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBlc2NhcGVIdG1sKHN0cjogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgZGl2LnRleHRDb250ZW50ID0gc3RyO1xuICByZXR1cm4gZGl2LmlubmVySFRNTDtcbn1cblxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIFN0YXJ0XG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuaW5pdCgpO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBR08sTUFBTSxXQUFXO0FBQ2pCLE1BQU0sb0JBQW9CO0FBQzFCLE1BQU0sbUJBQW1CO0FBQ3pCLE1BQU0sbUJBQW1CO0FBRXpCLE1BQU0sd0JBQXdCO0FBRTlCLE1BQU0sTUFBTTtBQUFBLElBQ2pCLGNBQWM7QUFBQSxJQUNkLGVBQWU7QUFBQSxJQUNmLGtCQUFrQjtBQUFBLElBQ2xCLGdCQUFnQjtBQUFBLElBQ2hCLG1CQUFtQjtBQUFBLElBQ25CLHFCQUFxQjtBQUFBLElBQ3JCLGlCQUFpQjtBQUFBLEVBQ25COzs7QUNoQkEsaUJBQXNCLFdBQW1DO0FBQ3ZELFVBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxtQkFBbUIsZ0JBQWdCLENBQUM7QUFDbkYsVUFBTSxRQUFRLE9BQU8saUJBQWlCO0FBQ3RDLFVBQU0sU0FBUyxPQUFPLGdCQUFnQjtBQUV0QyxRQUFJLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUU5QixVQUFNLFdBQVcsSUFBSSxLQUFLLE1BQU0sRUFBRSxRQUFRO0FBQzFDLFFBQUksQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLFdBQVcsS0FBSyxJQUFJLEdBQUc7QUFDdkQsWUFBTSxXQUFXO0FBQ2pCLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFTQSxpQkFBc0IsYUFBNEI7QUFDaEQsVUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLENBQUMsbUJBQW1CLGdCQUFnQixDQUFDO0FBQUEsRUFDekU7QUFFQSxpQkFBc0IsZUFBaUM7QUFDckQsVUFBTSxRQUFRLE1BQU0sU0FBUztBQUM3QixXQUFPLFVBQVU7QUFBQSxFQUNuQjs7O0FDaENPLFdBQVMsV0FBVyxLQUFxQjtBQUM5QyxXQUFPLElBQUksUUFBUSxNQUFNLE9BQU8sRUFBRSxRQUFRLE1BQU0sUUFBUSxFQUFFLFFBQVEsTUFBTSxPQUFPLEVBQUUsUUFBUSxNQUFNLE1BQU0sRUFBRSxRQUFRLE1BQU0sTUFBTTtBQUFBLEVBQzdIO0FBR0EsTUFBTSxjQUFjLENBQUMsUUFBUSxPQUFPLE9BQU87QUFDcEMsV0FBUyxhQUFhLE1BQXNCO0FBQ2pELFdBQU8sWUFBWSxTQUFTLElBQUksSUFBSSxPQUFPO0FBQUEsRUFDN0M7OztBQ0pBLE1BQU0sTUFBTTtBQWlDWixNQUFJLFFBQW9CO0FBQ3hCLE1BQUksV0FBNEI7QUFDaEMsTUFBSSxZQUE4QjtBQUNsQyxNQUFJLGFBQTBCLENBQUM7QUFDL0IsTUFBSSxnQkFBZ0I7QUFDcEIsTUFBSSxrQkFBa0I7QUFDdEIsTUFBSSxlQUFlO0FBQ25CLE1BQUksZUFBZTtBQUVuQixNQUFNLFVBQVUsU0FBUyxlQUFlLFNBQVM7QUFDakQsTUFBTSxjQUFjLFNBQVMsZUFBZSxjQUFjO0FBSzFELE1BQU0sa0JBQWtCO0FBTXhCLE1BQUksY0FBYztBQUNsQixNQUFJLGNBQWM7QUFFbEIsaUJBQWUsT0FBc0I7QUFDbkMsUUFBSSxhQUFhO0FBQ2Ysb0JBQWM7QUFDZCxjQUFRLElBQUksS0FBSyxzQ0FBc0M7QUFDdkQ7QUFBQSxJQUNGO0FBQ0Esa0JBQWM7QUFDZCxZQUFRLElBQUksS0FBSyxZQUFZO0FBQzdCLFFBQUk7QUFHSixZQUFNLENBQUMsR0FBRyxJQUFJLE1BQU0sT0FBTyxLQUFLLE1BQU0sRUFBRSxRQUFRLE1BQU0sZUFBZSxLQUFLLENBQUM7QUFDM0UsVUFBSSxLQUFLO0FBQ1Asd0JBQWdCLElBQUksT0FBTztBQUMzQiwwQkFBa0IsSUFBSSxTQUFTO0FBQy9CLHVCQUFlLElBQUksTUFBTTtBQUFBLE1BQzNCO0FBRUEsWUFBTSxRQUFRLE1BQU0sYUFBYTtBQUNqQyxVQUFJLENBQUMsT0FBTztBQUNWLGdCQUFRLElBQUksS0FBSywyQkFBMkI7QUFLNUMsY0FBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDOUQsY0FBTSxZQUFZLE9BQU8sT0FBTyxnQkFBZ0IsQ0FBQztBQUNqRCxjQUFNLFVBQVUsS0FBSyxJQUFJLElBQUk7QUFDN0IsWUFBSSxPQUFPLFNBQVMsU0FBUyxLQUFLLFVBQVUsaUJBQWlCO0FBQzNELGNBQUksVUFBVSxLQUFRO0FBQ3BCLG9CQUFRLElBQUksS0FBSyw4QkFBOEIsS0FBSyxNQUFNLFVBQVUsR0FBSSxHQUFHLFFBQVE7QUFDbkYsb0JBQVE7QUFBQSxVQUNWLE9BQU87QUFDTCxvQkFBUSxLQUFLLEtBQUsscUVBQWdFO0FBQ2xGLG9CQUFRO0FBQUEsVUFDVjtBQUFBLFFBQ0YsT0FBTztBQUNMLGtCQUFRO0FBQUEsUUFDVjtBQUVBLGVBQU87QUFDUDtBQUFBLE1BQ0Y7QUFHQSxZQUFNLFFBQVEsTUFBTSxTQUFTO0FBQzdCLFVBQUksQ0FBQyxPQUFPO0FBQ1YsZ0JBQVEsSUFBSSxLQUFLLDZDQUE2QztBQUM5RCxnQkFBUTtBQUNSLGVBQU87QUFDUDtBQUFBLE1BQ0Y7QUFFQSxjQUFRLElBQUksS0FBSyxpQ0FBaUM7QUFDbEQsVUFBSTtBQUNGLGNBQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxRQUFRLHlCQUF5QjtBQUFBLFVBQzFELFNBQVMsRUFBRSxlQUFlLFVBQVUsS0FBSyxHQUFHO0FBQUEsUUFDOUMsQ0FBQztBQUVELFlBQUksQ0FBQyxJQUFJLElBQUk7QUFDWCxrQkFBUSxLQUFLLEtBQUssbUJBQW1CLElBQUksTUFBTTtBQUMvQyxnQkFBTSxXQUFXO0FBQ2pCLGtCQUFRO0FBQ1IsaUJBQU87QUFDUDtBQUFBLFFBQ0Y7QUFFQSxtQkFBVyxNQUFNLElBQUksS0FBSyxFQUFFLE1BQU0sTUFBTSxJQUFJO0FBQzVDLFlBQUksQ0FBQyxZQUFZLE9BQU8sU0FBUyxXQUFXLFlBQVksT0FBTyxTQUFTLFNBQVMsVUFBVTtBQUN6RixrQkFBUSxLQUFLLEtBQUssOEJBQThCLFFBQVE7QUFDeEQsZ0JBQU0sV0FBVztBQUNqQixrQkFBUTtBQUNSLGlCQUFPO0FBQ1A7QUFBQSxRQUNGO0FBRUEsY0FBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsZ0JBQWdCLFNBQVMsQ0FBQztBQUUzRCxjQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8sZ0JBQWdCO0FBQ2xELGdCQUFRO0FBQ1IsZ0JBQVEsSUFBSSxLQUFLLG9CQUFvQixTQUFTLEtBQUs7QUFBQSxNQUNyRCxTQUFTLEtBQUs7QUFDWixnQkFBUSxLQUFLLEtBQUsseUJBQXlCLEdBQUc7QUFFOUMsY0FBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxnQkFBZ0I7QUFDOUQsY0FBTSxJQUFJLE9BQU87QUFDakIsWUFBSSxLQUFLLE9BQU8sRUFBRSxXQUFXLFlBQVksT0FBTyxFQUFFLFNBQVMsWUFBWSxPQUFPLEVBQUUsVUFBVSxVQUFVO0FBQ2xHLHFCQUFXO0FBQ1gsa0JBQVE7QUFBQSxRQUNWLE9BQU87QUFDTCxrQkFBUTtBQUFBLFFBQ1Y7QUFBQSxNQUNGO0FBS0EsVUFBSSxVQUFVLGlCQUFpQjtBQUM3QixjQUFNLFVBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLHFCQUFxQjtBQUNwRSxjQUFNLFNBQVMsUUFBUSxxQkFBcUI7QUFDNUMsWUFBSSxVQUFVLE9BQU8sT0FBTyxhQUFhLFVBQVU7QUFDakQsZ0JBQU0sTUFBTSxPQUFPLFlBQVksS0FBSyxJQUFJLElBQUksT0FBTyxZQUFZO0FBRS9ELGdCQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8scUJBQXFCO0FBQ3ZELGNBQUksTUFBTSxLQUFTO0FBQ2pCLG9CQUFRLElBQUksS0FBSyx3REFBd0Q7QUFDekUsd0JBQVk7QUFBQSxjQUNWLFVBQVUsT0FBTztBQUFBLGNBQ2pCLGNBQWMsT0FBTyxPQUFPLGlCQUFpQixXQUFXLE9BQU8sZUFBZTtBQUFBLGNBQzlFLEtBQUssT0FBTyxPQUFPLFFBQVEsV0FBVyxPQUFPLE1BQU07QUFBQSxjQUNuRCxXQUFXLE9BQU8sT0FBTyxjQUFjLFdBQVcsT0FBTyxZQUFZO0FBQUEsWUFDdkU7QUFDQSxvQkFBUTtBQUNSLG1CQUFPO0FBQ1A7QUFBQSxVQUNGLE9BQU87QUFDTCxvQkFBUSxJQUFJLEtBQUssK0JBQStCLEtBQUssTUFBTSxNQUFNLEdBQUksR0FBRyxnQkFBZ0I7QUFBQSxVQUMxRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsYUFBTztBQUFBLElBQ1AsVUFBRTtBQUNBLG9CQUFjO0FBQ2QsVUFBSSxhQUFhO0FBQ2Ysc0JBQWM7QUFHZCxZQUFJLFVBQVUsV0FBVztBQUN2QixlQUFLLEtBQUs7QUFBQSxRQUNaO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBTUEsU0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLFlBQVk7QUFDaEQsUUFBSSxRQUFRLFNBQVMsSUFBSSxrQkFBa0I7QUFDekMsWUFBTSxNQUFNLE9BQU8sUUFBUSxhQUFhLFdBQVcsUUFBUSxTQUFTLEtBQUssRUFBRSxNQUFNLEdBQUcsR0FBRyxJQUFJO0FBQzNGLFVBQUksQ0FBQyxJQUFLO0FBQ1Ysa0JBQVk7QUFBQSxRQUNWLFVBQVU7QUFBQSxRQUNWLGNBQWMsT0FBTyxRQUFRLGlCQUFpQixXQUFXLFFBQVEsYUFBYSxNQUFNLEdBQUcsR0FBRyxJQUFJO0FBQUEsUUFDOUYsS0FBSyxPQUFPLFFBQVEsUUFBUSxXQUFXLFFBQVEsSUFBSSxNQUFNLEdBQUcsR0FBSSxJQUFJO0FBQUEsUUFDcEUsV0FBVyxPQUFPLFFBQVEsY0FBYyxXQUFXLFFBQVEsVUFBVSxNQUFNLEdBQUcsR0FBRyxJQUFJO0FBQUEsTUFDdkY7QUFDQSxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJLFFBQVEsU0FBUyxJQUFJLG1CQUFtQjtBQUMxQyxtQkFBYSxRQUFRLGNBQWMsQ0FBQztBQUNwQyxVQUFJLFVBQVUsbUJBQW1CLFVBQVUsV0FBVztBQUNwRCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxRQUFJLFFBQVEsU0FBUyxJQUFJLGVBQWU7QUFDdEMsVUFBSSxVQUFVLFdBQVc7QUFDdkIsZ0JBQVE7QUFDUixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxRQUFJLFFBQVEsU0FBUyxxQkFBcUI7QUFFeEMsV0FBSztBQUFBLElBQ1A7QUFBQSxFQUNGLENBQUM7QUFJRCxTQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsU0FBUyxTQUFTO0FBQ3RELFFBQUksU0FBUyxRQUFTO0FBQ3RCLFFBQUksUUFBUSxpQkFBaUIsR0FBRyxVQUFVO0FBQ3hDLGNBQVEsSUFBSSxLQUFLLDhEQUE4RDtBQUMvRSxXQUFLLEtBQUs7QUFBQSxJQUNaO0FBQ0EsUUFBSSxRQUFRLHFCQUFxQixHQUFHLFlBQVksVUFBVSxXQUFXO0FBQ25FLGNBQVEsSUFBSSxLQUFLLDJEQUEyRDtBQUM1RSxXQUFLLEtBQUs7QUFBQSxJQUNaO0FBQUEsRUFDRixDQUFDO0FBTUQsV0FBUyxTQUFlO0FBQ3RCLGtCQUFjO0FBRWQsWUFBUSxPQUFPO0FBQUEsTUFDYixLQUFLO0FBQ0gscUJBQWE7QUFDYjtBQUFBLE1BQ0YsS0FBSztBQUNILHlCQUFpQjtBQUNqQjtBQUFBLE1BQ0YsS0FBSztBQUNILHlCQUFpQjtBQUNqQjtBQUFBLE1BQ0YsS0FBSztBQUNILDRCQUFvQjtBQUNwQjtBQUFBLE1BQ0YsS0FBSztBQUNILHNCQUFjO0FBQ2Q7QUFBQSxNQUNGLEtBQUs7QUFDSCxzQkFBYztBQUNkO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixRQUFJLENBQUMsVUFBVTtBQUNiLGtCQUFZLFlBQVk7QUFDeEI7QUFBQSxJQUNGO0FBRUEsZ0JBQVksWUFBWTtBQUFBO0FBQUEsUUFFbEIsV0FBVyxTQUFTLFNBQVMsV0FBVyxDQUFDO0FBQUE7QUFBQSxtQ0FFZCxlQUFlLEtBQUssUUFBUTtBQUFBO0FBQUEsVUFFckQsV0FBVyxTQUFTLFNBQVMsU0FBUyxNQUFNLENBQUM7QUFBQSx1Q0FDaEIsYUFBYSxTQUFTLElBQUksQ0FBQyxLQUFLLFdBQVcsU0FBUyxJQUFJLENBQUM7QUFBQTtBQUFBLHVDQUV6RCxRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFNN0MsYUFBUyxlQUFlLGdCQUFnQixHQUFHLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUMxRSxRQUFFLGdCQUFnQjtBQUNsQixxQkFBZSxDQUFDO0FBQ2hCLG9CQUFjO0FBQUEsSUFDaEIsQ0FBQztBQUVELGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9FLFlBQU0sV0FBVztBQUNqQixZQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8sZ0JBQWdCO0FBQ2xELGlCQUFXO0FBQ1gscUJBQWU7QUFDZixjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUdELGFBQVMsaUJBQWlCLFNBQVMsTUFBTTtBQUN2QyxVQUFJLGNBQWM7QUFDaEIsdUJBQWU7QUFDZixzQkFBYztBQUFBLE1BQ2hCO0FBQUEsSUFDRixHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFBQSxFQUNuQjtBQUVBLFdBQVMsZUFBcUI7QUFDNUIsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUXBCLGFBQVMsZUFBZSxhQUFhLEdBQUcsaUJBQWlCLFNBQVMsYUFBYTtBQUFBLEVBQ2pGO0FBRUEsV0FBUyxtQkFBeUI7QUFDaEMsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBV3BCLGFBQVMsZUFBZSxtQkFBbUIsR0FBRyxpQkFBaUIsU0FBUyxhQUFhO0FBQUEsRUFDdkY7QUFFQSxpQkFBZSxnQkFBK0I7QUFDNUMsWUFBUSxJQUFJLEtBQUssb0JBQW9CO0FBSXJDLFFBQUksb0JBQW9CO0FBQ3hCLFFBQUk7QUFDRixZQUFNLFNBQVMsSUFBSSxJQUFJLFFBQVEsRUFBRTtBQUNqQywwQkFBb0IsTUFBTSxPQUFPLFlBQVksU0FBUyxFQUFFLFNBQVMsQ0FBQyxHQUFHLE1BQU0sSUFBSSxFQUFFLENBQUM7QUFDbEYsY0FBUSxJQUFJLEtBQUssb0NBQW9DLGlCQUFpQjtBQUN0RSxVQUFJLENBQUMsbUJBQW1CO0FBQ3RCLDRCQUFvQixNQUFNLE9BQU8sWUFBWSxRQUFRLEVBQUUsU0FBUyxDQUFDLEdBQUcsTUFBTSxJQUFJLEVBQUUsQ0FBQztBQUNqRixnQkFBUSxJQUFJLEtBQUssbUNBQW1DLGlCQUFpQjtBQUFBLE1BQ3ZFO0FBQUEsSUFDRixTQUFTLEtBQUs7QUFDWixjQUFRLEtBQUssS0FBSyw2QkFBNkIsR0FBRztBQUFBLElBRXBEO0FBS0EsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLElBQUksRUFBRSxDQUFDO0FBRWpFLFFBQUk7QUFDSixRQUFJO0FBQ0YsWUFBTSxNQUFNLE9BQU8sS0FBSyxPQUFPLEVBQUUsS0FBSyxHQUFHLFFBQVEsa0JBQWtCLENBQUM7QUFBQSxJQUN0RSxTQUFTLEtBQUs7QUFDWixjQUFRLE1BQU0sS0FBSyw0QkFBNEIsR0FBRztBQUNsRCxjQUFRO0FBQ1IsYUFBTztBQUNQO0FBQUEsSUFDRjtBQUNBLFlBQVEsSUFBSSxLQUFLLHFCQUFxQixJQUFJLEVBQUU7QUFHNUMsUUFBSSxJQUFJLElBQUk7QUFDVixhQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sSUFBSSxpQkFBaUIsT0FBTyxJQUFJLEdBQUcsQ0FBQyxFQUFFO0FBQUEsUUFBTSxDQUFDLFFBQzlFLFFBQVEsS0FBSyxLQUFLLGdEQUFnRCxHQUFHO0FBQUEsTUFDdkU7QUFBQSxJQUNGO0FBRUEsWUFBUTtBQUNSLFdBQU87QUFBQSxFQUNUO0FBRUEsV0FBUyxtQkFBeUI7QUFDaEMsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFTcEIsYUFBUyxlQUFlLGdCQUFnQixHQUFHLGlCQUFpQixTQUFTLFlBQVk7QUFDL0UsWUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLGdCQUFnQjtBQUNsRCxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTLHNCQUE0QjtBQUNuQyxVQUFNLGVBQWUsY0FBYyxTQUFTLEtBQ3hDLGNBQWMsTUFBTSxHQUFHLEVBQUUsSUFBSSxRQUM3QjtBQUVKLFFBQUksaUJBQWlCO0FBQ3JCLFFBQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsdUJBQWlCO0FBQUE7QUFBQSxRQUViLFdBQ0M7QUFBQSxRQUNDLENBQUMsR0FBRyxNQUFNO0FBQUEsMkNBQ3VCLENBQUM7QUFBQSx5Q0FDSCxXQUFXLEVBQUUsSUFBSSxDQUFDO0FBQUEsNkNBQ2QsV0FBVyxFQUFFLFFBQVEsQ0FBQztBQUFBLDZFQUNVLENBQUM7QUFBQTtBQUFBO0FBQUEsTUFHdEUsRUFDQyxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUEsSUFFZjtBQUVBLFlBQVEsWUFBWTtBQUFBLDBEQUNvQyxXQUFXLFlBQVksQ0FBQztBQUFBLE1BQzVFLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWFsQixhQUFTLGVBQWUsVUFBVSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDbkUsVUFBSSxDQUFDLGNBQWMsV0FBVyxTQUFTLEtBQUssQ0FBQyxjQUFjLFdBQVcsVUFBVSxHQUFHO0FBR2pGLGNBQU0sVUFBVSxTQUFTLGVBQWUsVUFBVTtBQUNsRCxjQUFNLFdBQVcsU0FBUyxjQUFjLHFCQUFxQjtBQUM3RCxZQUFJLFNBQVUsVUFBUyxPQUFPO0FBQzlCLGNBQU0sVUFBVSxTQUFTLGNBQWMsS0FBSztBQUM1QyxnQkFBUSxZQUFZO0FBQ3BCLGdCQUFRLE1BQU0sVUFBVTtBQUN4QixnQkFBUSxjQUFjO0FBQ3RCLGlCQUFTLE1BQU0sT0FBTztBQUN0QjtBQUFBLE1BQ0Y7QUFDQSxhQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sSUFBSSxjQUFjLE9BQU8sYUFBYSxDQUFDO0FBQzFFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBR0QsYUFBUyxpQkFBaUIsa0JBQWtCLEVBQUUsUUFBUSxDQUFDLFFBQVE7QUFDN0QsVUFBSSxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDbkMsY0FBTSxNQUFNLFNBQVUsRUFBRSxPQUF1QixRQUFRLE9BQU8sR0FBRztBQUNqRSxjQUFNLElBQUksV0FBVyxHQUFHO0FBQ3hCLFlBQUksR0FBRztBQUNMLHNCQUFZO0FBQUEsWUFDVixVQUFVLEVBQUU7QUFBQSxZQUNaLGNBQWMsRUFBRTtBQUFBLFlBQ2hCLEtBQUs7QUFBQSxZQUNMLFdBQVc7QUFBQSxVQUNiO0FBQ0Esa0JBQVE7QUFDUixpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxhQUFTLGVBQWUsaUJBQWlCLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUMxRSxZQUFNLEtBQUssU0FBUyxlQUFlLGtCQUFrQjtBQUNyRCxVQUFJLFVBQVUsT0FBTyxNQUFNO0FBQUEsSUFDN0IsQ0FBQztBQUdELGFBQVMsZUFBZSxrQkFBa0IsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQzNFLFlBQU0sUUFBUSxTQUFTLGVBQWUsaUJBQWlCO0FBQ3ZELFlBQU0sV0FBVyxPQUFPLE1BQU0sS0FBSztBQUNuQyxVQUFJLFVBQVU7QUFDWixvQkFBWTtBQUFBLFVBQ1Y7QUFBQSxVQUNBLGNBQWM7QUFBQSxVQUNkLEtBQUs7QUFBQSxVQUNMLFdBQVc7QUFBQSxRQUNiO0FBQ0EsZ0JBQVE7QUFDUixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVNwQixhQUFTLGVBQWUsYUFBYSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDdEUsYUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLElBQUksZUFBZSxPQUFPLGFBQWEsQ0FBQztBQUMzRSxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixRQUFJLENBQUMsVUFBVztBQUVoQixVQUFNLE9BQU8sVUFBVSxRQUFRO0FBQy9CLFVBQU0saUJBQWlCLFNBQVM7QUFDaEMsVUFBTSxlQUFlLFVBQVUsYUFBYSxJQUFJLE1BQU0sR0FBRyxHQUFHO0FBRTVELFlBQVEsWUFBWTtBQUFBLDBEQUNvQztBQUFBLE1BQ3BELFVBQVUsSUFBSSxTQUFTLEtBQUssVUFBVSxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksUUFBUSxVQUFVO0FBQUEsSUFDN0UsQ0FBQztBQUFBO0FBQUE7QUFBQSxRQUlHLFVBQVUsZUFDTixpQ0FBaUMsV0FBVyxVQUFVLGFBQWEsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLFdBQ2pGLEVBQ047QUFBQSw4QkFDd0IsV0FBVyxVQUFVLFFBQVEsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVFQUlXLFdBQVcsV0FBVyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FRMUQsaUJBQWlCLGFBQWEsRUFBRTtBQUFBLGdFQUNKLGlCQUFpQixhQUFhLEVBQUU7QUFBQTtBQUFBLFlBRXBGLGlCQUFpQiw2Q0FBNkMsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1sRSxVQUFVLE9BQU8sVUFBVSxRQUFRLGdCQUFnQiw4REFBZ0UsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUs3SCxhQUFTLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN6RSxrQkFBWTtBQUNaLGFBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxJQUFJLGNBQWMsT0FBTyxhQUFhLENBQUM7QUFDMUUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFFRCxhQUFTLGVBQWUsWUFBWSxHQUFHLGlCQUFpQixTQUFTLGFBQWE7QUFBQSxFQUNoRjtBQUVBLE1BQUksV0FBVztBQUVmLGlCQUFlLGdCQUErQjtBQUM1QyxRQUFJLENBQUMsYUFBYSxTQUFVO0FBQzVCLGVBQVc7QUFFWCxVQUFNLFlBQVksU0FBUyxlQUFlLGNBQWM7QUFDeEQsVUFBTSxPQUFPLFdBQVcsTUFBTSxLQUFLLEtBQUs7QUFJeEMsVUFBTSxTQUFTLElBQUksZ0JBQWdCO0FBQ25DLFdBQU8sSUFBSSxPQUFPLFVBQVUsR0FBRztBQUMvQixXQUFPLElBQUksWUFBWSxVQUFVLFFBQVE7QUFDekMsUUFBSSxRQUFRLFNBQVMsbUJBQW9CLFFBQU8sSUFBSSxRQUFRLElBQUk7QUFFaEUsUUFBSTtBQUNGLFlBQU0sT0FBTyxLQUFLLE9BQU8sRUFBRSxLQUFLLEdBQUcsUUFBUSxjQUFjLE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQztBQUM5RSxhQUFPLE1BQU07QUFBQSxJQUNmLFNBQVMsS0FBSztBQUNaLGNBQVEsTUFBTSxLQUFLLGlDQUFpQyxHQUFHO0FBQ3ZELGlCQUFXO0FBQUEsSUFDYjtBQUFBLEVBQ0Y7QUFPQSxXQUFTLFdBQVcsS0FBcUI7QUFDdkMsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksY0FBYztBQUNsQixXQUFPLElBQUk7QUFBQSxFQUNiO0FBT0EsT0FBSzsiLAogICJuYW1lcyI6IFtdCn0K
