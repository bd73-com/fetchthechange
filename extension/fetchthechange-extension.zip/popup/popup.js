"use strict";
(() => {
  // src/shared/constants.ts
  var BASE_URL = "https://ftc.bd73.com";
  var TOKEN_STORAGE_KEY = "ftc_extension_token";
  var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
  var AUTH_STARTED_KEY = "ftc_auth_started_at";
  var MSG = {
    START_PICKER: "FTC_START_PICKER",
    CANCEL_PICKER: "FTC_CANCEL_PICKER",
    ELEMENT_SELECTED: "FTC_ELEMENT_SELECTED",
    GET_CANDIDATES: "FTC_GET_CANDIDATES",
    CANDIDATES_RESULT: "FTC_CANDIDATES_RESULT",
    FTC_EXTENSION_TOKEN: "FTC_EXTENSION_TOKEN",
    AUTH_TAB_OPENED: "FTC_AUTH_TAB_OPENED"
  };

  // src/auth/token.ts
  async function getToken() {
    const result = await chrome.storage.local.get([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
    const token = result[TOKEN_STORAGE_KEY];
    const expiry = result[TOKEN_EXPIRY_KEY];
    if (!token || !expiry) return null;
    const expiryMs = new Date(expiry).getTime();
    if (!Number.isFinite(expiryMs) || expiryMs < Date.now()) {
      await clearToken();
      return null;
    }
    return token;
  }
  async function clearToken() {
    await chrome.storage.local.remove([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
  }
  async function isTokenValid() {
    const token = await getToken();
    return token !== null;
  }

  // src/popup/utils.ts
  function escapeAttr(str) {
    return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  var KNOWN_TIERS = ["free", "pro", "power"];
  function sanitizeTier(tier) {
    return KNOWN_TIERS.includes(tier) ? tier : "free";
  }

  // src/popup/popup.ts
  var TAG = "[FTC:popup]";
  var state = "unauthenticated";
  var userInfo = null;
  var selection = null;
  var candidates = [];
  var currentTabUrl = "";
  var currentTabTitle = "";
  var currentTabId = 0;
  var errorMessage = "";
  var createdMonitorName = "";
  var createdMonitorValue = "";
  var dropdownOpen = false;
  var content = document.getElementById("content");
  var accountArea = document.getElementById("account-area");
  var AUTH_TIMEOUT_MS = 12e4;
  var initRunning = false;
  var initPending = false;
  async function init() {
    if (initRunning) {
      initPending = true;
      console.log(TAG, "init already running, queueing rerun");
      return;
    }
    initRunning = true;
    console.log(TAG, "init start");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        currentTabUrl = tab.url || "";
        currentTabTitle = tab.title || "";
        currentTabId = tab.id || 0;
      }
      const valid = await isTokenValid();
      if (!valid) {
        console.log(TAG, "no valid token in storage");
        const stored = await chrome.storage.local.get(AUTH_STARTED_KEY);
        const startedAt = Number(stored[AUTH_STARTED_KEY]);
        const elapsed = Date.now() - startedAt;
        if (Number.isFinite(startedAt) && elapsed < AUTH_TIMEOUT_MS) {
          if (elapsed < 3e4) {
            console.log(TAG, "auth attempt in progress (", Math.round(elapsed / 1e3), "s ago)");
            state = "connecting";
          } else {
            console.warn(TAG, "recent auth attempt found but no token \u2014 showing failure state");
            state = "auth_failed";
          }
        } else {
          state = "unauthenticated";
        }
        render();
        return;
      }
      const token = await getToken();
      if (!token) {
        console.log(TAG, "getToken returned null despite isTokenValid");
        state = "unauthenticated";
        render();
        return;
      }
      console.log(TAG, "verifying token with backend...");
      try {
        const res = await fetch(`${BASE_URL}/api/extension/verify`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) {
          console.warn(TAG, "verify returned", res.status);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        userInfo = await res.json().catch(() => null);
        if (!userInfo || typeof userInfo.userId !== "string" || typeof userInfo.tier !== "string") {
          console.warn(TAG, "verify response malformed:", userInfo);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        await chrome.storage.local.set({ cachedUserInfo: userInfo });
        await chrome.storage.local.remove(AUTH_STARTED_KEY);
        state = "authenticated";
        console.log(TAG, "authenticated as", userInfo.email);
      } catch (err) {
        console.warn(TAG, "verify network error:", err);
        const cached = await chrome.storage.local.get("cachedUserInfo");
        const c = cached.cachedUserInfo;
        if (c && typeof c.userId === "string" && typeof c.tier === "string" && typeof c.email === "string") {
          userInfo = c;
          state = "authenticated";
        } else {
          state = "unauthenticated";
        }
      }
      render();
    } finally {
      initRunning = false;
      if (initPending) {
        initPending = false;
        void init();
      }
    }
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === MSG.ELEMENT_SELECTED) {
      selection = {
        selector: message.selector,
        currentValue: message.currentValue,
        url: message.url,
        pageTitle: message.pageTitle
      };
      state = "confirm";
      render();
    }
    if (message.type === MSG.CANDIDATES_RESULT) {
      candidates = message.candidates || [];
      if (state === "authenticated" || state === "picking") {
        render();
      }
    }
    if (message.type === MSG.CANCEL_PICKER) {
      if (state === "picking") {
        state = "authenticated";
        render();
      }
    }
    if (message.type === "FTC_AUTH_COMPLETE") {
      init();
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[TOKEN_STORAGE_KEY]?.newValue) {
      console.log(TAG, "token appeared in storage (direct write), re-initialising...");
      void init();
    }
  });
  function render() {
    renderAccount();
    switch (state) {
      case "unauthenticated":
        renderUnauth();
        break;
      case "connecting":
        renderConnecting();
        break;
      case "auth_failed":
        renderAuthFailed();
        break;
      case "authenticated":
        renderAuthenticated();
        break;
      case "picking":
        renderPicking();
        break;
      case "confirm":
        renderConfirm();
        break;
      case "creating":
        renderCreating();
        break;
      case "success":
        renderSuccess();
        break;
      case "error":
        renderError();
        break;
    }
  }
  function renderAccount() {
    if (!userInfo) {
      accountArea.innerHTML = "";
      return;
    }
    accountArea.innerHTML = `
    <button class="account-btn" id="account-toggle">
      ${escapeHtml(userInfo.email || "Connected")} &#9662;
    </button>
    <div class="account-dropdown ${dropdownOpen ? "" : "hidden"}" id="account-dropdown">
      <div class="dropdown-email">
        ${escapeHtml(userInfo.email || userInfo.userId)}
        <span class="tier-badge tier-${sanitizeTier(userInfo.tier)}">${escapeHtml(userInfo.tier)}</span>
      </div>
      <a class="dropdown-item" href="${BASE_URL}/dashboard" target="_blank">Open dashboard</a>
      <div class="dropdown-divider"></div>
      <button class="dropdown-item" id="disconnect-btn">Disconnect</button>
    </div>
  `;
    document.getElementById("account-toggle")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdownOpen = !dropdownOpen;
      renderAccount();
    });
    document.getElementById("disconnect-btn")?.addEventListener("click", async () => {
      await clearToken();
      await chrome.storage.local.remove("cachedUserInfo");
      userInfo = null;
      dropdownOpen = false;
      state = "unauthenticated";
      render();
    });
    document.addEventListener("click", () => {
      if (dropdownOpen) {
        dropdownOpen = false;
        renderAccount();
      }
    }, { once: true });
  }
  function renderUnauth() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Track what matters on any webpage.</h2>
      <button class="btn btn-primary btn-full" id="connect-btn">Connect your account</button>
      <p>Already have an account? Sign in above.</p>
    </div>
  `;
    document.getElementById("connect-btn")?.addEventListener("click", startAuthFlow);
  }
  function renderAuthFailed() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Connection failed</h2>
      <p>We couldn't connect the extension to your account. This can happen if your browser blocked the connection.</p>
      <button class="btn btn-primary btn-full" id="retry-connect-btn">Try again</button>
      <p style="margin-top: 12px; font-size: 12px; opacity: 0.7;">
        Tip: when Chrome asks to allow access to ftc.bd73.com, click <strong>Allow</strong>.
      </p>
    </div>
  `;
    document.getElementById("retry-connect-btn")?.addEventListener("click", startAuthFlow);
  }
  async function startAuthFlow() {
    console.log(TAG, "starting auth flow");
    let permissionGranted = false;
    try {
      const origin = new URL(BASE_URL).origin;
      permissionGranted = await chrome.permissions.contains({ origins: [`${origin}/*`] });
      console.log(TAG, "host permission already granted:", permissionGranted);
      if (!permissionGranted) {
        permissionGranted = await chrome.permissions.request({ origins: [`${origin}/*`] });
        console.log(TAG, "host permission request result:", permissionGranted);
      }
    } catch (err) {
      console.warn(TAG, "permission request error:", err);
    }
    await chrome.storage.local.set({ [AUTH_STARTED_KEY]: Date.now() });
    let tab;
    try {
      tab = await chrome.tabs.create({ url: `${BASE_URL}/extension-auth` });
    } catch (err) {
      console.error(TAG, "failed to open auth tab:", err);
      state = "auth_failed";
      render();
      return;
    }
    console.log(TAG, "auth tab created:", tab.id);
    if (tab.id) {
      chrome.runtime.sendMessage({ type: MSG.AUTH_TAB_OPENED, tabId: tab.id }).catch(
        (err) => console.warn(TAG, "failed to notify service worker of auth tab:", err)
      );
    }
    state = "connecting";
    render();
  }
  function renderConnecting() {
    content.innerHTML = `
    <div class="connecting">
      <div class="spinner"></div>
      <p>Connecting...</p>
      <p>Waiting for you to sign in at FetchTheChange.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-connect" style="margin-top: 16px;">Cancel</button>
    </div>
  `;
    document.getElementById("cancel-connect")?.addEventListener("click", async () => {
      await chrome.storage.local.remove(AUTH_STARTED_KEY);
      state = "unauthenticated";
      render();
    });
  }
  function renderAuthenticated() {
    const truncatedUrl = currentTabUrl.length > 45 ? currentTabUrl.slice(0, 45) + "..." : currentTabUrl;
    let candidatesHtml = "";
    if (candidates.length > 0) {
      candidatesHtml = `
      <div class="section-header">Suggested elements</div>
      ${candidates.map(
        (c, i) => `
        <div class="candidate" data-idx="${i}">
          <span class="candidate-text">${escapeHtml(c.text)}</span>
          <span class="candidate-selector">${escapeHtml(c.selector)}</span>
          <button class="btn btn-primary btn-sm candidate-track" data-idx="${i}">Track this</button>
        </div>
      `
      ).join("")}
    `;
    }
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(truncatedUrl)}</div>
    ${candidatesHtml}
    <div class="section-header">Or pick manually</div>
    <button class="btn btn-primary btn-full" id="pick-btn">Pick an element on this page</button>
    <button class="advanced-toggle" id="advanced-toggle">&#9662; Advanced (CSS selector)</button>
    <div class="advanced-content" id="advanced-content">
      <div class="form-group">
        <input type="text" class="form-input" id="manual-selector" placeholder="e.g. .product-price">
      </div>
      <button class="btn btn-secondary btn-sm" id="manual-track-btn">Use this selector</button>
    </div>
  `;
    document.getElementById("pick-btn")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.querySelectorAll(".candidate-track").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const idx = parseInt(e.target.dataset.idx || "0");
        const c = candidates[idx];
        if (c) {
          selection = {
            selector: c.selector,
            currentValue: c.text,
            url: currentTabUrl,
            pageTitle: currentTabTitle
          };
          state = "confirm";
          render();
        }
      });
    });
    document.getElementById("advanced-toggle")?.addEventListener("click", () => {
      const el = document.getElementById("advanced-content");
      el?.classList.toggle("open");
    });
    document.getElementById("manual-track-btn")?.addEventListener("click", () => {
      const input = document.getElementById("manual-selector");
      const selector = input?.value.trim();
      if (selector) {
        selection = {
          selector,
          currentValue: "",
          url: currentTabUrl,
          pageTitle: ""
        };
        state = "confirm";
        render();
      }
    });
  }
  function renderPicking() {
    content.innerHTML = `
    <div class="picker-info">
      <div class="icon">&#127919;</div>
      <p><strong>Click any element on the page to track it.</strong></p>
      <p>Press Esc to cancel.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-pick" style="margin-top: 16px;">Cancel picking</button>
    </div>
  `;
    document.getElementById("cancel-pick")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.CANCEL_PICKER, tabId: currentTabId });
      state = "authenticated";
      render();
    });
  }
  function renderConfirm() {
    if (!selection) return;
    const tier = userInfo?.tier || "free";
    const hourlyDisabled = tier === "free";
    const defaultName = (selection.pageTitle || "").slice(0, 100);
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(
      selection.url.length > 45 ? selection.url.slice(0, 45) + "..." : selection.url
    )}</div>
    <div class="confirm-card">
      <div class="label">Element selected</div>
      ${selection.currentValue ? `<div class="value">Currently: ${escapeHtml(selection.currentValue.slice(0, 100))}</div>` : ""}
      <div class="selector">${escapeHtml(selection.selector)}</div>
    </div>
    <div class="form-group">
      <label class="form-label">Monitor name</label>
      <input type="text" class="form-input" id="monitor-name" value="${escapeAttr(defaultName)}" maxlength="100">
    </div>
    <div class="form-group">
      <label class="form-label">Check frequency</label>
      <div class="radio-group">
        <label class="radio-label">
          <input type="radio" name="frequency" value="daily" checked> Daily
        </label>
        <label class="radio-label ${hourlyDisabled ? "disabled" : ""}">
          <input type="radio" name="frequency" value="hourly" ${hourlyDisabled ? "disabled" : ""}>
          Hourly
          ${hourlyDisabled ? '<span class="tooltip-text">(Pro+)</span>' : ""}
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="pick-again-btn">Pick again</button>
      <button class="btn btn-primary" id="create-btn">Create monitor</button>
    </div>
  `;
    document.getElementById("pick-again-btn")?.addEventListener("click", () => {
      selection = null;
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.getElementById("create-btn")?.addEventListener("click", createMonitor);
  }
  async function createMonitor() {
    if (!selection || state === "creating") return;
    const nameInput = document.getElementById("monitor-name");
    const name = nameInput?.value.trim() || "Untitled monitor";
    const frequency = document.querySelector('input[name="frequency"]:checked')?.value || "daily";
    state = "creating";
    createdMonitorName = name;
    createdMonitorValue = selection.currentValue;
    render();
    try {
      const token = await getToken();
      if (!token) {
        errorMessage = "Not authenticated. Please reconnect.";
        state = "error";
        render();
        return;
      }
      const res = await fetch(`${BASE_URL}/api/extension/monitors`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name,
          url: selection.url,
          selector: selection.selector,
          frequency
        })
      });
      if (res.ok) {
        state = "success";
        render();
        return;
      }
      const data = await res.json().catch(() => null);
      if (data?.code === "TIER_LIMIT_REACHED") {
        errorMessage = `${data.message || data.error || "Monitor limit reached."}`;
        state = "error";
        render();
        const errContainer = content.querySelector(".error p");
        if (errContainer) {
          errContainer.appendChild(document.createElement("br"));
          const link = document.createElement("a");
          link.href = `${BASE_URL}/pricing`;
          link.target = "_blank";
          link.style.color = "#6366f1";
          link.textContent = "Upgrade your plan";
          errContainer.appendChild(link);
        }
        return;
      }
      errorMessage = data?.message || data?.error || `Failed (${res.status})`;
      state = "error";
      render();
    } catch {
      errorMessage = "Network error. Please try again.";
      state = "error";
      render();
    }
  }
  function renderCreating() {
    content.innerHTML = `
    <div class="connecting" style="padding-top: 64px;">
      <div class="spinner"></div>
      <p>Creating monitor...</p>
    </div>
  `;
  }
  function renderSuccess() {
    content.innerHTML = `
    <div class="success">
      <div class="icon">&#10003;</div>
      <h3>Monitor created!</h3>
      <p><strong>${escapeHtml(createdMonitorName)}</strong> is now being watched.</p>
      ${createdMonitorValue ? `<p>You'll be notified when <strong>${escapeHtml(createdMonitorValue.slice(0, 60))}</strong> changes.</p>` : ""}
      <div class="btn-row" style="margin-top: 24px; justify-content: center;">
        <a class="btn btn-primary btn-sm" href="${BASE_URL}/dashboard" target="_blank">View in dashboard</a>
        <button class="btn btn-secondary btn-sm" id="track-another-btn">Track another</button>
      </div>
    </div>
  `;
    document.getElementById("track-another-btn")?.addEventListener("click", () => {
      selection = null;
      candidates = [];
      state = "authenticated";
      render();
    });
  }
  function renderError() {
    content.innerHTML = `
    <div class="error">
      <div class="icon">&#10007;</div>
      <h3>Couldn't create monitor</h3>
      <p>${escapeHtml(errorMessage)}</p>
      <button class="btn btn-secondary" id="try-again-btn">Try again</button>
    </div>
  `;
    document.getElementById("try-again-btn")?.addEventListener("click", () => {
      state = selection ? "confirm" : "authenticated";
      render();
    });
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
  init();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL3NoYXJlZC9jb25zdGFudHMudHMiLCAiLi4vLi4vc3JjL2F1dGgvdG9rZW4udHMiLCAiLi4vLi4vc3JjL3BvcHVwL3V0aWxzLnRzIiwgIi4uLy4uL3NyYy9wb3B1cC9wb3B1cC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLy8gQkFTRV9VUkwgaXMgaW5qZWN0ZWQgYXQgYnVpbGQgdGltZSB2aWEgZXNidWlsZCBkZWZpbmUuXG4vLyBTZXQgQkFTRV9VUkwgZW52IHZhciB0byBvdmVycmlkZSAoZGVmYXVsdDogaHR0cHM6Ly9mdGMuYmQ3My5jb20pXG5kZWNsYXJlIGNvbnN0IEJBU0VfVVJMX0lOSkVDVEVEOiBzdHJpbmc7XG5leHBvcnQgY29uc3QgQkFTRV9VUkwgPSBCQVNFX1VSTF9JTkpFQ1RFRDtcbmV4cG9ydCBjb25zdCBUT0tFTl9TVE9SQUdFX0tFWSA9IFwiZnRjX2V4dGVuc2lvbl90b2tlblwiO1xuZXhwb3J0IGNvbnN0IFRPS0VOX0VYUElSWV9LRVkgPSBcImZ0Y19leHRlbnNpb25fdG9rZW5fZXhwaXJ5XCI7XG5leHBvcnQgY29uc3QgQVVUSF9TVEFSVEVEX0tFWSA9IFwiZnRjX2F1dGhfc3RhcnRlZF9hdFwiO1xuZXhwb3J0IGNvbnN0IEFVVEhfVEFCX0lEX0tFWSA9IFwiZnRjX2F1dGhfdGFiX2lkXCI7XG5cbmV4cG9ydCBjb25zdCBNU0cgPSB7XG4gIFNUQVJUX1BJQ0tFUjogXCJGVENfU1RBUlRfUElDS0VSXCIsXG4gIENBTkNFTF9QSUNLRVI6IFwiRlRDX0NBTkNFTF9QSUNLRVJcIixcbiAgRUxFTUVOVF9TRUxFQ1RFRDogXCJGVENfRUxFTUVOVF9TRUxFQ1RFRFwiLFxuICBHRVRfQ0FORElEQVRFUzogXCJGVENfR0VUX0NBTkRJREFURVNcIixcbiAgQ0FORElEQVRFU19SRVNVTFQ6IFwiRlRDX0NBTkRJREFURVNfUkVTVUxUXCIsXG4gIEZUQ19FWFRFTlNJT05fVE9LRU46IFwiRlRDX0VYVEVOU0lPTl9UT0tFTlwiLFxuICBBVVRIX1RBQl9PUEVORUQ6IFwiRlRDX0FVVEhfVEFCX09QRU5FRFwiLFxufSBhcyBjb25zdDtcbiIsICJpbXBvcnQgeyBUT0tFTl9TVE9SQUdFX0tFWSwgVE9LRU5fRVhQSVJZX0tFWSB9IGZyb20gXCIuLi9zaGFyZWQvY29uc3RhbnRzXCI7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUb2tlbigpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFtUT0tFTl9TVE9SQUdFX0tFWSwgVE9LRU5fRVhQSVJZX0tFWV0pO1xuICBjb25zdCB0b2tlbiA9IHJlc3VsdFtUT0tFTl9TVE9SQUdFX0tFWV07XG4gIGNvbnN0IGV4cGlyeSA9IHJlc3VsdFtUT0tFTl9FWFBJUllfS0VZXTtcblxuICBpZiAoIXRva2VuIHx8ICFleHBpcnkpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGV4cGlyeU1zID0gbmV3IERhdGUoZXhwaXJ5KS5nZXRUaW1lKCk7XG4gIGlmICghTnVtYmVyLmlzRmluaXRlKGV4cGlyeU1zKSB8fCBleHBpcnlNcyA8IERhdGUubm93KCkpIHtcbiAgICBhd2FpdCBjbGVhclRva2VuKCk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICByZXR1cm4gdG9rZW47XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRUb2tlbih0b2tlbjogc3RyaW5nLCBleHBpcmVzQXQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1xuICAgIFtUT0tFTl9TVE9SQUdFX0tFWV06IHRva2VuLFxuICAgIFtUT0tFTl9FWFBJUllfS0VZXTogZXhwaXJlc0F0LFxuICB9KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyVG9rZW4oKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnJlbW92ZShbVE9LRU5fU1RPUkFHRV9LRVksIFRPS0VOX0VYUElSWV9LRVldKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGlzVG9rZW5WYWxpZCgpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgdG9rZW4gPSBhd2FpdCBnZXRUb2tlbigpO1xuICByZXR1cm4gdG9rZW4gIT09IG51bGw7XG59XG4iLCAiZXhwb3J0IGZ1bmN0aW9uIGVzY2FwZUF0dHIoc3RyOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gc3RyLnJlcGxhY2UoLyYvZywgXCImYW1wO1wiKS5yZXBsYWNlKC9cIi9nLCBcIiZxdW90O1wiKS5yZXBsYWNlKC8nL2csIFwiJiMzOTtcIikucmVwbGFjZSgvPC9nLCBcIiZsdDtcIikucmVwbGFjZSgvPi9nLCBcIiZndDtcIik7XG59XG5cbi8vIEtlZXAgaW4gc3luYyB3aXRoIHNoYXJlZC9tb2RlbHMvYXV0aC50cyBUSUVSX0xJTUlUU1xuY29uc3QgS05PV05fVElFUlMgPSBbXCJmcmVlXCIsIFwicHJvXCIsIFwicG93ZXJcIl07XG5leHBvcnQgZnVuY3Rpb24gc2FuaXRpemVUaWVyKHRpZXI6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBLTk9XTl9USUVSUy5pbmNsdWRlcyh0aWVyKSA/IHRpZXIgOiBcImZyZWVcIjtcbn1cbiIsICJpbXBvcnQgeyBCQVNFX1VSTCwgTVNHLCBBVVRIX1NUQVJURURfS0VZLCBUT0tFTl9TVE9SQUdFX0tFWSB9IGZyb20gXCIuLi9zaGFyZWQvY29uc3RhbnRzXCI7XG5pbXBvcnQgeyBnZXRUb2tlbiwgY2xlYXJUb2tlbiwgaXNUb2tlblZhbGlkIH0gZnJvbSBcIi4uL2F1dGgvdG9rZW5cIjtcbmltcG9ydCB7IGVzY2FwZUF0dHIsIHNhbml0aXplVGllciB9IGZyb20gXCIuL3V0aWxzXCI7XG5cbmNvbnN0IFRBRyA9IFwiW0ZUQzpwb3B1cF1cIjtcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vLyBTdGF0ZVxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmludGVyZmFjZSBVc2VySW5mbyB7XG4gIHVzZXJJZDogc3RyaW5nO1xuICB0aWVyOiBzdHJpbmc7XG4gIGVtYWlsOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBTZWxlY3Rpb24ge1xuICBzZWxlY3Rvcjogc3RyaW5nO1xuICBjdXJyZW50VmFsdWU6IHN0cmluZztcbiAgdXJsOiBzdHJpbmc7XG4gIHBhZ2VUaXRsZTogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgQ2FuZGlkYXRlIHtcbiAgc2VsZWN0b3I6IHN0cmluZztcbiAgdGV4dDogc3RyaW5nO1xuICBzY29yZTogbnVtYmVyO1xufVxuXG50eXBlIFBvcHVwU3RhdGUgPVxuICB8IFwidW5hdXRoZW50aWNhdGVkXCJcbiAgfCBcImNvbm5lY3RpbmdcIlxuICB8IFwiYXV0aF9mYWlsZWRcIlxuICB8IFwiYXV0aGVudGljYXRlZFwiXG4gIHwgXCJwaWNraW5nXCJcbiAgfCBcImNvbmZpcm1cIlxuICB8IFwiY3JlYXRpbmdcIlxuICB8IFwic3VjY2Vzc1wiXG4gIHwgXCJlcnJvclwiO1xuXG5sZXQgc3RhdGU6IFBvcHVwU3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xubGV0IHVzZXJJbmZvOiBVc2VySW5mbyB8IG51bGwgPSBudWxsO1xubGV0IHNlbGVjdGlvbjogU2VsZWN0aW9uIHwgbnVsbCA9IG51bGw7XG5sZXQgY2FuZGlkYXRlczogQ2FuZGlkYXRlW10gPSBbXTtcbmxldCBjdXJyZW50VGFiVXJsID0gXCJcIjtcbmxldCBjdXJyZW50VGFiVGl0bGUgPSBcIlwiO1xubGV0IGN1cnJlbnRUYWJJZCA9IDA7XG5sZXQgZXJyb3JNZXNzYWdlID0gXCJcIjtcbmxldCBjcmVhdGVkTW9uaXRvck5hbWUgPSBcIlwiO1xubGV0IGNyZWF0ZWRNb25pdG9yVmFsdWUgPSBcIlwiO1xubGV0IGRyb3Bkb3duT3BlbiA9IGZhbHNlO1xuXG5jb25zdCBjb250ZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjb250ZW50XCIpITtcbmNvbnN0IGFjY291bnRBcmVhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhY2NvdW50LWFyZWFcIikhO1xuXG4vLyBIb3cgbG9uZyB3ZSBjb25zaWRlciBhbiBhdXRoIGF0dGVtcHQgXCJyZWNlbnRcIiBcdTIwMTQgaWYgbm8gdG9rZW4gd2FzIHN0b3JlZFxuLy8gd2l0aGluIHRoaXMgd2luZG93LCB3ZSBzaG93IGFuIGVycm9yIGluc3RlYWQgb2YgdGhlIGRlZmF1bHQgY29ubmVjdCBzY3JlZW4uXG4vLyBNdXN0IG1hdGNoIHRoZSBTVydzIGZhbGxiYWNrIHdpbmRvdyAoMTIwIHMgaW4gc2VydmljZS13b3JrZXIudHMgb25VcGRhdGVkKS5cbmNvbnN0IEFVVEhfVElNRU9VVF9NUyA9IDEyMF8wMDA7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gSW5pdGlhbGlzZVxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmxldCBpbml0UnVubmluZyA9IGZhbHNlO1xubGV0IGluaXRQZW5kaW5nID0gZmFsc2U7XG5cbmFzeW5jIGZ1bmN0aW9uIGluaXQoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChpbml0UnVubmluZykge1xuICAgIGluaXRQZW5kaW5nID0gdHJ1ZTtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwiaW5pdCBhbHJlYWR5IHJ1bm5pbmcsIHF1ZXVlaW5nIHJlcnVuXCIpO1xuICAgIHJldHVybjtcbiAgfVxuICBpbml0UnVubmluZyA9IHRydWU7XG4gIGNvbnNvbGUubG9nKFRBRywgXCJpbml0IHN0YXJ0XCIpO1xuICB0cnkge1xuXG4gIC8vIEdldCBjdXJyZW50IHRhYiBpbmZvXG4gIGNvbnN0IFt0YWJdID0gYXdhaXQgY2hyb21lLnRhYnMucXVlcnkoeyBhY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWUgfSk7XG4gIGlmICh0YWIpIHtcbiAgICBjdXJyZW50VGFiVXJsID0gdGFiLnVybCB8fCBcIlwiO1xuICAgIGN1cnJlbnRUYWJUaXRsZSA9IHRhYi50aXRsZSB8fCBcIlwiO1xuICAgIGN1cnJlbnRUYWJJZCA9IHRhYi5pZCB8fCAwO1xuICB9XG5cbiAgY29uc3QgdmFsaWQgPSBhd2FpdCBpc1Rva2VuVmFsaWQoKTtcbiAgaWYgKCF2YWxpZCkge1xuICAgIGNvbnNvbGUubG9nKFRBRywgXCJubyB2YWxpZCB0b2tlbiBpbiBzdG9yYWdlXCIpO1xuXG4gICAgLy8gQ2hlY2sgaWYgYW4gYXV0aCBhdHRlbXB0IHdhcyByZWNlbnRseSBzdGFydGVkLlxuICAgIC8vIFNob3cgXCJjb25uZWN0aW5nXCIgZm9yIHRoZSBmaXJzdCAzMCBzIChhdXRoIG1heSBzdGlsbCBiZSBpbiBwcm9ncmVzcyksXG4gICAgLy8gdGhlbiBcImF1dGhfZmFpbGVkXCIgdXAgdG8gQVVUSF9USU1FT1VUX01TLlxuICAgIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChBVVRIX1NUQVJURURfS0VZKTtcbiAgICBjb25zdCBzdGFydGVkQXQgPSBOdW1iZXIoc3RvcmVkW0FVVEhfU1RBUlRFRF9LRVldKTtcbiAgICBjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIHN0YXJ0ZWRBdDtcbiAgICBpZiAoTnVtYmVyLmlzRmluaXRlKHN0YXJ0ZWRBdCkgJiYgZWxhcHNlZCA8IEFVVEhfVElNRU9VVF9NUykge1xuICAgICAgaWYgKGVsYXBzZWQgPCAzMF8wMDApIHtcbiAgICAgICAgY29uc29sZS5sb2coVEFHLCBcImF1dGggYXR0ZW1wdCBpbiBwcm9ncmVzcyAoXCIsIE1hdGgucm91bmQoZWxhcHNlZCAvIDEwMDApLCBcInMgYWdvKVwiKTtcbiAgICAgICAgc3RhdGUgPSBcImNvbm5lY3RpbmdcIjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUud2FybihUQUcsIFwicmVjZW50IGF1dGggYXR0ZW1wdCBmb3VuZCBidXQgbm8gdG9rZW4gXHUyMDE0IHNob3dpbmcgZmFpbHVyZSBzdGF0ZVwiKTtcbiAgICAgICAgc3RhdGUgPSBcImF1dGhfZmFpbGVkXCI7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICB9XG5cbiAgICByZW5kZXIoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBWZXJpZnkgdG9rZW4gd2l0aCBiYWNrZW5kXG4gIGNvbnN0IHRva2VuID0gYXdhaXQgZ2V0VG9rZW4oKTtcbiAgaWYgKCF0b2tlbikge1xuICAgIGNvbnNvbGUubG9nKFRBRywgXCJnZXRUb2tlbiByZXR1cm5lZCBudWxsIGRlc3BpdGUgaXNUb2tlblZhbGlkXCIpO1xuICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBjb25zb2xlLmxvZyhUQUcsIFwidmVyaWZ5aW5nIHRva2VuIHdpdGggYmFja2VuZC4uLlwiKTtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vYXBpL2V4dGVuc2lvbi92ZXJpZnlgLCB7XG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0b2tlbn1gIH0sXG4gICAgfSk7XG5cbiAgICBpZiAoIXJlcy5vaykge1xuICAgICAgY29uc29sZS53YXJuKFRBRywgXCJ2ZXJpZnkgcmV0dXJuZWRcIiwgcmVzLnN0YXR1cyk7XG4gICAgICBhd2FpdCBjbGVhclRva2VuKCk7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB1c2VySW5mbyA9IGF3YWl0IHJlcy5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbCk7XG4gICAgaWYgKCF1c2VySW5mbyB8fCB0eXBlb2YgdXNlckluZm8udXNlcklkICE9PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB1c2VySW5mby50aWVyICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zb2xlLndhcm4oVEFHLCBcInZlcmlmeSByZXNwb25zZSBtYWxmb3JtZWQ6XCIsIHVzZXJJbmZvKTtcbiAgICAgIGF3YWl0IGNsZWFyVG9rZW4oKTtcbiAgICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICAgIHJlbmRlcigpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBDYWNoZSB1c2VySW5mbyBmb3Igb2ZmbGluZSBmYWxsYmFja1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IGNhY2hlZFVzZXJJbmZvOiB1c2VySW5mbyB9KTtcbiAgICAvLyBDbGVhciBhbnkgc3RhbGUgYXV0aC1zdGFydGVkIGZsYWdcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoQVVUSF9TVEFSVEVEX0tFWSk7XG4gICAgc3RhdGUgPSBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwiYXV0aGVudGljYXRlZCBhc1wiLCB1c2VySW5mby5lbWFpbCk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUud2FybihUQUcsIFwidmVyaWZ5IG5ldHdvcmsgZXJyb3I6XCIsIGVycik7XG4gICAgLy8gTmV0d29yayBlcnJvciBcdTIwMTQgdHJ5IHRvIHJlc3RvcmUgY2FjaGVkIHVzZXJJbmZvIHNvIHRpZXIvYWNjb3VudCBkaXNwbGF5IGNvcnJlY3RseVxuICAgIGNvbnN0IGNhY2hlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcImNhY2hlZFVzZXJJbmZvXCIpO1xuICAgIGNvbnN0IGMgPSBjYWNoZWQuY2FjaGVkVXNlckluZm87XG4gICAgaWYgKGMgJiYgdHlwZW9mIGMudXNlcklkID09PSBcInN0cmluZ1wiICYmIHR5cGVvZiBjLnRpZXIgPT09IFwic3RyaW5nXCIgJiYgdHlwZW9mIGMuZW1haWwgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHVzZXJJbmZvID0gYztcbiAgICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICB9XG4gIH1cblxuICByZW5kZXIoKTtcbiAgfSBmaW5hbGx5IHtcbiAgICBpbml0UnVubmluZyA9IGZhbHNlO1xuICAgIGlmIChpbml0UGVuZGluZykge1xuICAgICAgaW5pdFBlbmRpbmcgPSBmYWxzZTtcbiAgICAgIHZvaWQgaW5pdCgpO1xuICAgIH1cbiAgfVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIExpc3RlbiBmb3IgbWVzc2FnZXMgZnJvbSBiYWNrZ3JvdW5kL2NvbnRlbnRcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UpID0+IHtcbiAgaWYgKG1lc3NhZ2UudHlwZSA9PT0gTVNHLkVMRU1FTlRfU0VMRUNURUQpIHtcbiAgICBzZWxlY3Rpb24gPSB7XG4gICAgICBzZWxlY3RvcjogbWVzc2FnZS5zZWxlY3RvcixcbiAgICAgIGN1cnJlbnRWYWx1ZTogbWVzc2FnZS5jdXJyZW50VmFsdWUsXG4gICAgICB1cmw6IG1lc3NhZ2UudXJsLFxuICAgICAgcGFnZVRpdGxlOiBtZXNzYWdlLnBhZ2VUaXRsZSxcbiAgICB9O1xuICAgIHN0YXRlID0gXCJjb25maXJtXCI7XG4gICAgcmVuZGVyKCk7XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuQ0FORElEQVRFU19SRVNVTFQpIHtcbiAgICBjYW5kaWRhdGVzID0gbWVzc2FnZS5jYW5kaWRhdGVzIHx8IFtdO1xuICAgIGlmIChzdGF0ZSA9PT0gXCJhdXRoZW50aWNhdGVkXCIgfHwgc3RhdGUgPT09IFwicGlja2luZ1wiKSB7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuQ0FOQ0VMX1BJQ0tFUikge1xuICAgIGlmIChzdGF0ZSA9PT0gXCJwaWNraW5nXCIpIHtcbiAgICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBcIkZUQ19BVVRIX0NPTVBMRVRFXCIpIHtcbiAgICAvLyBSZS1pbml0aWFsaXNlIGFmdGVyIGF1dGhcbiAgICBpbml0KCk7XG4gIH1cbn0pO1xuXG4vLyBBbHNvIGxpc3RlbiBmb3IgZGlyZWN0IHN0b3JhZ2Ugd3JpdGVzIChlLmcuIGZyb20gYXV0aC1yZWxheSBjb250ZW50IHNjcmlwdFxuLy8gd3JpdGluZyB0aGUgdG9rZW4gZGlyZWN0bHksIGJ5cGFzc2luZyB0aGUgc2VydmljZSB3b3JrZXIpLlxuY2hyb21lLnN0b3JhZ2Uub25DaGFuZ2VkLmFkZExpc3RlbmVyKChjaGFuZ2VzLCBhcmVhKSA9PiB7XG4gIGlmIChhcmVhICE9PSBcImxvY2FsXCIpIHJldHVybjtcbiAgaWYgKGNoYW5nZXNbVE9LRU5fU1RPUkFHRV9LRVldPy5uZXdWYWx1ZSkge1xuICAgIGNvbnNvbGUubG9nKFRBRywgXCJ0b2tlbiBhcHBlYXJlZCBpbiBzdG9yYWdlIChkaXJlY3Qgd3JpdGUpLCByZS1pbml0aWFsaXNpbmcuLi5cIik7XG4gICAgdm9pZCBpbml0KCk7XG4gIH1cbn0pO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIFJlbmRlclxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIHJlbmRlcigpOiB2b2lkIHtcbiAgcmVuZGVyQWNjb3VudCgpO1xuXG4gIHN3aXRjaCAoc3RhdGUpIHtcbiAgICBjYXNlIFwidW5hdXRoZW50aWNhdGVkXCI6XG4gICAgICByZW5kZXJVbmF1dGgoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJjb25uZWN0aW5nXCI6XG4gICAgICByZW5kZXJDb25uZWN0aW5nKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiYXV0aF9mYWlsZWRcIjpcbiAgICAgIHJlbmRlckF1dGhGYWlsZWQoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJhdXRoZW50aWNhdGVkXCI6XG4gICAgICByZW5kZXJBdXRoZW50aWNhdGVkKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwicGlja2luZ1wiOlxuICAgICAgcmVuZGVyUGlja2luZygpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImNvbmZpcm1cIjpcbiAgICAgIHJlbmRlckNvbmZpcm0oKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJjcmVhdGluZ1wiOlxuICAgICAgcmVuZGVyQ3JlYXRpbmcoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJzdWNjZXNzXCI6XG4gICAgICByZW5kZXJTdWNjZXNzKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZXJyb3JcIjpcbiAgICAgIHJlbmRlckVycm9yKCk7XG4gICAgICBicmVhaztcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50KCk6IHZvaWQge1xuICBpZiAoIXVzZXJJbmZvKSB7XG4gICAgYWNjb3VudEFyZWEuaW5uZXJIVE1MID0gXCJcIjtcbiAgICByZXR1cm47XG4gIH1cblxuICBhY2NvdW50QXJlYS5pbm5lckhUTUwgPSBgXG4gICAgPGJ1dHRvbiBjbGFzcz1cImFjY291bnQtYnRuXCIgaWQ9XCJhY2NvdW50LXRvZ2dsZVwiPlxuICAgICAgJHtlc2NhcGVIdG1sKHVzZXJJbmZvLmVtYWlsIHx8IFwiQ29ubmVjdGVkXCIpfSAmIzk2NjI7XG4gICAgPC9idXR0b24+XG4gICAgPGRpdiBjbGFzcz1cImFjY291bnQtZHJvcGRvd24gJHtkcm9wZG93bk9wZW4gPyBcIlwiIDogXCJoaWRkZW5cIn1cIiBpZD1cImFjY291bnQtZHJvcGRvd25cIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJkcm9wZG93bi1lbWFpbFwiPlxuICAgICAgICAke2VzY2FwZUh0bWwodXNlckluZm8uZW1haWwgfHwgdXNlckluZm8udXNlcklkKX1cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ0aWVyLWJhZGdlIHRpZXItJHtzYW5pdGl6ZVRpZXIodXNlckluZm8udGllcil9XCI+JHtlc2NhcGVIdG1sKHVzZXJJbmZvLnRpZXIpfTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGEgY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgaHJlZj1cIiR7QkFTRV9VUkx9L2Rhc2hib2FyZFwiIHRhcmdldD1cIl9ibGFua1wiPk9wZW4gZGFzaGJvYXJkPC9hPlxuICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLWRpdmlkZXJcIj48L2Rpdj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgaWQ9XCJkaXNjb25uZWN0LWJ0blwiPkRpc2Nvbm5lY3Q8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImFjY291bnQtdG9nZ2xlXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIGRyb3Bkb3duT3BlbiA9ICFkcm9wZG93bk9wZW47XG4gICAgcmVuZGVyQWNjb3VudCgpO1xuICB9KTtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRpc2Nvbm5lY3QtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGNsZWFyVG9rZW4oKTtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICB1c2VySW5mbyA9IG51bGw7XG4gICAgZHJvcGRvd25PcGVuID0gZmFsc2U7XG4gICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcblxuICAvLyBDbG9zZSBkcm9wZG93biBvbiBjbGljayBvdXRzaWRlXG4gIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgaWYgKGRyb3Bkb3duT3Blbikge1xuICAgICAgZHJvcGRvd25PcGVuID0gZmFsc2U7XG4gICAgICByZW5kZXJBY2NvdW50KCk7XG4gICAgfVxuICB9LCB7IG9uY2U6IHRydWUgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclVuYXV0aCgpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInVuYXV0aFwiPlxuICAgICAgPGgyPlRyYWNrIHdoYXQgbWF0dGVycyBvbiBhbnkgd2VicGFnZS48L2gyPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbFwiIGlkPVwiY29ubmVjdC1idG5cIj5Db25uZWN0IHlvdXIgYWNjb3VudDwvYnV0dG9uPlxuICAgICAgPHA+QWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/IFNpZ24gaW4gYWJvdmUuPC9wPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29ubmVjdC1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBzdGFydEF1dGhGbG93KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQXV0aEZhaWxlZCgpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInVuYXV0aFwiPlxuICAgICAgPGgyPkNvbm5lY3Rpb24gZmFpbGVkPC9oMj5cbiAgICAgIDxwPldlIGNvdWxkbid0IGNvbm5lY3QgdGhlIGV4dGVuc2lvbiB0byB5b3VyIGFjY291bnQuIFRoaXMgY2FuIGhhcHBlbiBpZiB5b3VyIGJyb3dzZXIgYmxvY2tlZCB0aGUgY29ubmVjdGlvbi48L3A+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1mdWxsXCIgaWQ9XCJyZXRyeS1jb25uZWN0LWJ0blwiPlRyeSBhZ2FpbjwvYnV0dG9uPlxuICAgICAgPHAgc3R5bGU9XCJtYXJnaW4tdG9wOiAxMnB4OyBmb250LXNpemU6IDEycHg7IG9wYWNpdHk6IDAuNztcIj5cbiAgICAgICAgVGlwOiB3aGVuIENocm9tZSBhc2tzIHRvIGFsbG93IGFjY2VzcyB0byBmdGMuYmQ3My5jb20sIGNsaWNrIDxzdHJvbmc+QWxsb3c8L3N0cm9uZz4uXG4gICAgICA8L3A+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyZXRyeS1jb25uZWN0LWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHN0YXJ0QXV0aEZsb3cpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydEF1dGhGbG93KCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zb2xlLmxvZyhUQUcsIFwic3RhcnRpbmcgYXV0aCBmbG93XCIpO1xuXG4gIC8vIENocm9tZSAxMjcrIHRyZWF0cyBob3N0X3Blcm1pc3Npb25zIGFzIG9wdGlvbmFsLlxuICAvLyBSZXF1ZXN0IHRoZSBwZXJtaXNzaW9uIHNvIHRoZSBhdXRoLXJlbGF5IGNvbnRlbnQgc2NyaXB0IGdldHMgaW5qZWN0ZWQuXG4gIGxldCBwZXJtaXNzaW9uR3JhbnRlZCA9IGZhbHNlO1xuICB0cnkge1xuICAgIGNvbnN0IG9yaWdpbiA9IG5ldyBVUkwoQkFTRV9VUkwpLm9yaWdpbjtcbiAgICBwZXJtaXNzaW9uR3JhbnRlZCA9IGF3YWl0IGNocm9tZS5wZXJtaXNzaW9ucy5jb250YWlucyh7IG9yaWdpbnM6IFtgJHtvcmlnaW59LypgXSB9KTtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwiaG9zdCBwZXJtaXNzaW9uIGFscmVhZHkgZ3JhbnRlZDpcIiwgcGVybWlzc2lvbkdyYW50ZWQpO1xuICAgIGlmICghcGVybWlzc2lvbkdyYW50ZWQpIHtcbiAgICAgIHBlcm1pc3Npb25HcmFudGVkID0gYXdhaXQgY2hyb21lLnBlcm1pc3Npb25zLnJlcXVlc3QoeyBvcmlnaW5zOiBbYCR7b3JpZ2lufS8qYF0gfSk7XG4gICAgICBjb25zb2xlLmxvZyhUQUcsIFwiaG9zdCBwZXJtaXNzaW9uIHJlcXVlc3QgcmVzdWx0OlwiLCBwZXJtaXNzaW9uR3JhbnRlZCk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oVEFHLCBcInBlcm1pc3Npb24gcmVxdWVzdCBlcnJvcjpcIiwgZXJyKTtcbiAgICAvLyBGYWxsYmFjayBhdXRoIHN0aWxsIHdvcmtzIHdpdGhvdXQgdGhlIHBlcm1pc3Npb25cbiAgfVxuXG4gIC8vIFJlY29yZCB0aGF0IHdlIHN0YXJ0ZWQgYW4gYXV0aCBhdHRlbXB0IHNvIGlmIHRoZSBwb3B1cFxuICAvLyByZS1vcGVucyB3aXRob3V0IGEgdG9rZW4sIHdlIGNhbiBzaG93IGFuIGVycm9yIGluc3RlYWQgb2ZcbiAgLy8gdGhlIGdlbmVyaWMgXCJDb25uZWN0IHlvdXIgYWNjb3VudFwiIHNjcmVlbi5cbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW0FVVEhfU1RBUlRFRF9LRVldOiBEYXRlLm5vdygpIH0pO1xuXG4gIGxldCB0YWI6IGNocm9tZS50YWJzLlRhYjtcbiAgdHJ5IHtcbiAgICB0YWIgPSBhd2FpdCBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6IGAke0JBU0VfVVJMfS9leHRlbnNpb24tYXV0aGAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoVEFHLCBcImZhaWxlZCB0byBvcGVuIGF1dGggdGFiOlwiLCBlcnIpO1xuICAgIHN0YXRlID0gXCJhdXRoX2ZhaWxlZFwiO1xuICAgIHJlbmRlcigpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zb2xlLmxvZyhUQUcsIFwiYXV0aCB0YWIgY3JlYXRlZDpcIiwgdGFiLmlkKTtcblxuICAvLyBUZWxsIHRoZSBzZXJ2aWNlIHdvcmtlciB3aGljaCB0YWIgdG8gd2F0Y2hcbiAgaWYgKHRhYi5pZCkge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogTVNHLkFVVEhfVEFCX09QRU5FRCwgdGFiSWQ6IHRhYi5pZCB9KS5jYXRjaCgoZXJyKSA9PlxuICAgICAgY29uc29sZS53YXJuKFRBRywgXCJmYWlsZWQgdG8gbm90aWZ5IHNlcnZpY2Ugd29ya2VyIG9mIGF1dGggdGFiOlwiLCBlcnIpLFxuICAgICk7XG4gIH1cblxuICBzdGF0ZSA9IFwiY29ubmVjdGluZ1wiO1xuICByZW5kZXIoKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQ29ubmVjdGluZygpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImNvbm5lY3RpbmdcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyXCI+PC9kaXY+XG4gICAgICA8cD5Db25uZWN0aW5nLi4uPC9wPlxuICAgICAgPHA+V2FpdGluZyBmb3IgeW91IHRvIHNpZ24gaW4gYXQgRmV0Y2hUaGVDaGFuZ2UuPC9wPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGlkPVwiY2FuY2VsLWNvbm5lY3RcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDE2cHg7XCI+Q2FuY2VsPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYW5jZWwtY29ubmVjdFwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoQVVUSF9TVEFSVEVEX0tFWSk7XG4gICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQXV0aGVudGljYXRlZCgpOiB2b2lkIHtcbiAgY29uc3QgdHJ1bmNhdGVkVXJsID0gY3VycmVudFRhYlVybC5sZW5ndGggPiA0NVxuICAgID8gY3VycmVudFRhYlVybC5zbGljZSgwLCA0NSkgKyBcIi4uLlwiXG4gICAgOiBjdXJyZW50VGFiVXJsO1xuXG4gIGxldCBjYW5kaWRhdGVzSHRtbCA9IFwiXCI7XG4gIGlmIChjYW5kaWRhdGVzLmxlbmd0aCA+IDApIHtcbiAgICBjYW5kaWRhdGVzSHRtbCA9IGBcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLWhlYWRlclwiPlN1Z2dlc3RlZCBlbGVtZW50czwvZGl2PlxuICAgICAgJHtjYW5kaWRhdGVzXG4gICAgICAgIC5tYXAoXG4gICAgICAgICAgKGMsIGkpID0+IGBcbiAgICAgICAgPGRpdiBjbGFzcz1cImNhbmRpZGF0ZVwiIGRhdGEtaWR4PVwiJHtpfVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY2FuZGlkYXRlLXRleHRcIj4ke2VzY2FwZUh0bWwoYy50ZXh0KX08L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJjYW5kaWRhdGUtc2VsZWN0b3JcIj4ke2VzY2FwZUh0bWwoYy5zZWxlY3Rvcil9PC9zcGFuPlxuICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLXNtIGNhbmRpZGF0ZS10cmFja1wiIGRhdGEtaWR4PVwiJHtpfVwiPlRyYWNrIHRoaXM8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICBgXG4gICAgICAgIClcbiAgICAgICAgLmpvaW4oXCJcIil9XG4gICAgYDtcbiAgfVxuXG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjdXJyZW50LXVybFwiPjxzdHJvbmc+VHJhY2tpbmc6PC9zdHJvbmc+ICR7ZXNjYXBlSHRtbCh0cnVuY2F0ZWRVcmwpfTwvZGl2PlxuICAgICR7Y2FuZGlkYXRlc0h0bWx9XG4gICAgPGRpdiBjbGFzcz1cInNlY3Rpb24taGVhZGVyXCI+T3IgcGljayBtYW51YWxseTwvZGl2PlxuICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLWZ1bGxcIiBpZD1cInBpY2stYnRuXCI+UGljayBhbiBlbGVtZW50IG9uIHRoaXMgcGFnZTwvYnV0dG9uPlxuICAgIDxidXR0b24gY2xhc3M9XCJhZHZhbmNlZC10b2dnbGVcIiBpZD1cImFkdmFuY2VkLXRvZ2dsZVwiPiYjOTY2MjsgQWR2YW5jZWQgKENTUyBzZWxlY3Rvcik8L2J1dHRvbj5cbiAgICA8ZGl2IGNsYXNzPVwiYWR2YW5jZWQtY29udGVudFwiIGlkPVwiYWR2YW5jZWQtY29udGVudFwiPlxuICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3M9XCJmb3JtLWlucHV0XCIgaWQ9XCJtYW51YWwtc2VsZWN0b3JcIiBwbGFjZWhvbGRlcj1cImUuZy4gLnByb2R1Y3QtcHJpY2VcIj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGlkPVwibWFudWFsLXRyYWNrLWJ0blwiPlVzZSB0aGlzIHNlbGVjdG9yPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgLy8gUGljayBlbGVtZW50IGJ1dHRvblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBpY2stYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogTVNHLlNUQVJUX1BJQ0tFUiwgdGFiSWQ6IGN1cnJlbnRUYWJJZCB9KTtcbiAgICBzdGF0ZSA9IFwicGlja2luZ1wiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcblxuICAvLyBDYW5kaWRhdGUgdHJhY2sgYnV0dG9uc1xuICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmNhbmRpZGF0ZS10cmFja1wiKS5mb3JFYWNoKChidG4pID0+IHtcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIChlKSA9PiB7XG4gICAgICBjb25zdCBpZHggPSBwYXJzZUludCgoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLmRhdGFzZXQuaWR4IHx8IFwiMFwiKTtcbiAgICAgIGNvbnN0IGMgPSBjYW5kaWRhdGVzW2lkeF07XG4gICAgICBpZiAoYykge1xuICAgICAgICBzZWxlY3Rpb24gPSB7XG4gICAgICAgICAgc2VsZWN0b3I6IGMuc2VsZWN0b3IsXG4gICAgICAgICAgY3VycmVudFZhbHVlOiBjLnRleHQsXG4gICAgICAgICAgdXJsOiBjdXJyZW50VGFiVXJsLFxuICAgICAgICAgIHBhZ2VUaXRsZTogY3VycmVudFRhYlRpdGxlLFxuICAgICAgICB9O1xuICAgICAgICBzdGF0ZSA9IFwiY29uZmlybVwiO1xuICAgICAgICByZW5kZXIoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gQWR2YW5jZWQgdG9nZ2xlXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWR2YW5jZWQtdG9nZ2xlXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhZHZhbmNlZC1jb250ZW50XCIpO1xuICAgIGVsPy5jbGFzc0xpc3QudG9nZ2xlKFwib3BlblwiKTtcbiAgfSk7XG5cbiAgLy8gTWFudWFsIHNlbGVjdG9yXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibWFudWFsLXRyYWNrLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjb25zdCBpbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibWFudWFsLXNlbGVjdG9yXCIpIGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gICAgY29uc3Qgc2VsZWN0b3IgPSBpbnB1dD8udmFsdWUudHJpbSgpO1xuICAgIGlmIChzZWxlY3Rvcikge1xuICAgICAgc2VsZWN0aW9uID0ge1xuICAgICAgICBzZWxlY3RvcixcbiAgICAgICAgY3VycmVudFZhbHVlOiBcIlwiLFxuICAgICAgICB1cmw6IGN1cnJlbnRUYWJVcmwsXG4gICAgICAgIHBhZ2VUaXRsZTogXCJcIixcbiAgICAgIH07XG4gICAgICBzdGF0ZSA9IFwiY29uZmlybVwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgfVxuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyUGlja2luZygpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInBpY2tlci1pbmZvXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiaWNvblwiPiYjMTI3OTE5OzwvZGl2PlxuICAgICAgPHA+PHN0cm9uZz5DbGljayBhbnkgZWxlbWVudCBvbiB0aGUgcGFnZSB0byB0cmFjayBpdC48L3N0cm9uZz48L3A+XG4gICAgICA8cD5QcmVzcyBFc2MgdG8gY2FuY2VsLjwvcD5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cImNhbmNlbC1waWNrXCIgc3R5bGU9XCJtYXJnaW4tdG9wOiAxNnB4O1wiPkNhbmNlbCBwaWNraW5nPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYW5jZWwtcGlja1wiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5DQU5DRUxfUElDS0VSLCB0YWJJZDogY3VycmVudFRhYklkIH0pO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJDb25maXJtKCk6IHZvaWQge1xuICBpZiAoIXNlbGVjdGlvbikgcmV0dXJuO1xuXG4gIGNvbnN0IHRpZXIgPSB1c2VySW5mbz8udGllciB8fCBcImZyZWVcIjtcbiAgY29uc3QgaG91cmx5RGlzYWJsZWQgPSB0aWVyID09PSBcImZyZWVcIjtcbiAgY29uc3QgZGVmYXVsdE5hbWUgPSAoc2VsZWN0aW9uLnBhZ2VUaXRsZSB8fCBcIlwiKS5zbGljZSgwLCAxMDApO1xuXG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjdXJyZW50LXVybFwiPjxzdHJvbmc+VHJhY2tpbmc6PC9zdHJvbmc+ICR7ZXNjYXBlSHRtbChcbiAgICAgIHNlbGVjdGlvbi51cmwubGVuZ3RoID4gNDUgPyBzZWxlY3Rpb24udXJsLnNsaWNlKDAsIDQ1KSArIFwiLi4uXCIgOiBzZWxlY3Rpb24udXJsXG4gICAgKX08L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiY29uZmlybS1jYXJkXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibGFiZWxcIj5FbGVtZW50IHNlbGVjdGVkPC9kaXY+XG4gICAgICAke1xuICAgICAgICBzZWxlY3Rpb24uY3VycmVudFZhbHVlXG4gICAgICAgICAgPyBgPGRpdiBjbGFzcz1cInZhbHVlXCI+Q3VycmVudGx5OiAke2VzY2FwZUh0bWwoc2VsZWN0aW9uLmN1cnJlbnRWYWx1ZS5zbGljZSgwLCAxMDApKX08L2Rpdj5gXG4gICAgICAgICAgOiBcIlwiXG4gICAgICB9XG4gICAgICA8ZGl2IGNsYXNzPVwic2VsZWN0b3JcIj4ke2VzY2FwZUh0bWwoc2VsZWN0aW9uLnNlbGVjdG9yKX08L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1sYWJlbFwiPk1vbml0b3IgbmFtZTwvbGFiZWw+XG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzcz1cImZvcm0taW5wdXRcIiBpZD1cIm1vbml0b3ItbmFtZVwiIHZhbHVlPVwiJHtlc2NhcGVBdHRyKGRlZmF1bHROYW1lKX1cIiBtYXhsZW5ndGg9XCIxMDBcIj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1sYWJlbFwiPkNoZWNrIGZyZXF1ZW5jeTwvbGFiZWw+XG4gICAgICA8ZGl2IGNsYXNzPVwicmFkaW8tZ3JvdXBcIj5cbiAgICAgICAgPGxhYmVsIGNsYXNzPVwicmFkaW8tbGFiZWxcIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT1cImZyZXF1ZW5jeVwiIHZhbHVlPVwiZGFpbHlcIiBjaGVja2VkPiBEYWlseVxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJyYWRpby1sYWJlbCAke2hvdXJseURpc2FibGVkID8gXCJkaXNhYmxlZFwiIDogXCJcIn1cIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT1cImZyZXF1ZW5jeVwiIHZhbHVlPVwiaG91cmx5XCIgJHtob3VybHlEaXNhYmxlZCA/IFwiZGlzYWJsZWRcIiA6IFwiXCJ9PlxuICAgICAgICAgIEhvdXJseVxuICAgICAgICAgICR7aG91cmx5RGlzYWJsZWQgPyAnPHNwYW4gY2xhc3M9XCJ0b29sdGlwLXRleHRcIj4oUHJvKyk8L3NwYW4+JyA6IFwiXCJ9XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiYnRuLXJvd1wiPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5XCIgaWQ9XCJwaWNrLWFnYWluLWJ0blwiPlBpY2sgYWdhaW48L2J1dHRvbj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiBpZD1cImNyZWF0ZS1idG5cIj5DcmVhdGUgbW9uaXRvcjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGljay1hZ2Fpbi1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgc2VsZWN0aW9uID0gbnVsbDtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5TVEFSVF9QSUNLRVIsIHRhYklkOiBjdXJyZW50VGFiSWQgfSk7XG4gICAgc3RhdGUgPSBcInBpY2tpbmdcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjcmVhdGUtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgY3JlYXRlTW9uaXRvcik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZU1vbml0b3IoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmICghc2VsZWN0aW9uIHx8IHN0YXRlID09PSBcImNyZWF0aW5nXCIpIHJldHVybjtcblxuICBjb25zdCBuYW1lSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1vbml0b3ItbmFtZVwiKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICBjb25zdCBuYW1lID0gbmFtZUlucHV0Py52YWx1ZS50cmltKCkgfHwgXCJVbnRpdGxlZCBtb25pdG9yXCI7XG4gIGNvbnN0IGZyZXF1ZW5jeSA9XG4gICAgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2lucHV0W25hbWU9XCJmcmVxdWVuY3lcIl06Y2hlY2tlZCcpIGFzIEhUTUxJbnB1dEVsZW1lbnQpPy52YWx1ZSB8fCBcImRhaWx5XCI7XG5cbiAgc3RhdGUgPSBcImNyZWF0aW5nXCI7XG4gIGNyZWF0ZWRNb25pdG9yTmFtZSA9IG5hbWU7XG4gIGNyZWF0ZWRNb25pdG9yVmFsdWUgPSBzZWxlY3Rpb24uY3VycmVudFZhbHVlO1xuICByZW5kZXIoKTtcblxuICB0cnkge1xuICAgIGNvbnN0IHRva2VuID0gYXdhaXQgZ2V0VG9rZW4oKTtcbiAgICBpZiAoIXRva2VuKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBcIk5vdCBhdXRoZW50aWNhdGVkLiBQbGVhc2UgcmVjb25uZWN0LlwiO1xuICAgICAgc3RhdGUgPSBcImVycm9yXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vYXBpL2V4dGVuc2lvbi9tb25pdG9yc2AsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIHVybDogc2VsZWN0aW9uLnVybCxcbiAgICAgICAgc2VsZWN0b3I6IHNlbGVjdGlvbi5zZWxlY3RvcixcbiAgICAgICAgZnJlcXVlbmN5LFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBpZiAocmVzLm9rKSB7XG4gICAgICBzdGF0ZSA9IFwic3VjY2Vzc1wiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbCk7XG5cbiAgICBpZiAoZGF0YT8uY29kZSA9PT0gXCJUSUVSX0xJTUlUX1JFQUNIRURcIikge1xuICAgICAgZXJyb3JNZXNzYWdlID0gYCR7ZGF0YS5tZXNzYWdlIHx8IGRhdGEuZXJyb3IgfHwgXCJNb25pdG9yIGxpbWl0IHJlYWNoZWQuXCJ9YDtcbiAgICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICAvLyBBZGQgdXBncmFkZSBsaW5rIGFmdGVyIHJlbmRlciB1c2luZyBET00gQVBJXG4gICAgICBjb25zdCBlcnJDb250YWluZXIgPSBjb250ZW50LnF1ZXJ5U2VsZWN0b3IoXCIuZXJyb3IgcFwiKTtcbiAgICAgIGlmIChlcnJDb250YWluZXIpIHtcbiAgICAgICAgZXJyQ29udGFpbmVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJiclwiKSk7XG4gICAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYVwiKTtcbiAgICAgICAgbGluay5ocmVmID0gYCR7QkFTRV9VUkx9L3ByaWNpbmdgO1xuICAgICAgICBsaW5rLnRhcmdldCA9IFwiX2JsYW5rXCI7XG4gICAgICAgIGxpbmsuc3R5bGUuY29sb3IgPSBcIiM2MzY2ZjFcIjtcbiAgICAgICAgbGluay50ZXh0Q29udGVudCA9IFwiVXBncmFkZSB5b3VyIHBsYW5cIjtcbiAgICAgICAgZXJyQ29udGFpbmVyLmFwcGVuZENoaWxkKGxpbmspO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGVycm9yTWVzc2FnZSA9IGRhdGE/Lm1lc3NhZ2UgfHwgZGF0YT8uZXJyb3IgfHwgYEZhaWxlZCAoJHtyZXMuc3RhdHVzfSlgO1xuICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgIHJlbmRlcigpO1xuICB9IGNhdGNoIHtcbiAgICBlcnJvck1lc3NhZ2UgPSBcIk5ldHdvcmsgZXJyb3IuIFBsZWFzZSB0cnkgYWdhaW4uXCI7XG4gICAgc3RhdGUgPSBcImVycm9yXCI7XG4gICAgcmVuZGVyKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyQ3JlYXRpbmcoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjb25uZWN0aW5nXCIgc3R5bGU9XCJwYWRkaW5nLXRvcDogNjRweDtcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyXCI+PC9kaXY+XG4gICAgICA8cD5DcmVhdGluZyBtb25pdG9yLi4uPC9wPlxuICAgIDwvZGl2PlxuICBgO1xufVxuXG5mdW5jdGlvbiByZW5kZXJTdWNjZXNzKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwic3VjY2Vzc1wiPlxuICAgICAgPGRpdiBjbGFzcz1cImljb25cIj4mIzEwMDAzOzwvZGl2PlxuICAgICAgPGgzPk1vbml0b3IgY3JlYXRlZCE8L2gzPlxuICAgICAgPHA+PHN0cm9uZz4ke2VzY2FwZUh0bWwoY3JlYXRlZE1vbml0b3JOYW1lKX08L3N0cm9uZz4gaXMgbm93IGJlaW5nIHdhdGNoZWQuPC9wPlxuICAgICAgJHtjcmVhdGVkTW9uaXRvclZhbHVlID8gYDxwPllvdSdsbCBiZSBub3RpZmllZCB3aGVuIDxzdHJvbmc+JHtlc2NhcGVIdG1sKGNyZWF0ZWRNb25pdG9yVmFsdWUuc2xpY2UoMCwgNjApKX08L3N0cm9uZz4gY2hhbmdlcy48L3A+YCA6IFwiXCJ9XG4gICAgICA8ZGl2IGNsYXNzPVwiYnRuLXJvd1wiIHN0eWxlPVwibWFyZ2luLXRvcDogMjRweDsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XCI+XG4gICAgICAgIDxhIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbVwiIGhyZWY9XCIke0JBU0VfVVJMfS9kYXNoYm9hcmRcIiB0YXJnZXQ9XCJfYmxhbmtcIj5WaWV3IGluIGRhc2hib2FyZDwvYT5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGlkPVwidHJhY2stYW5vdGhlci1idG5cIj5UcmFjayBhbm90aGVyPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRyYWNrLWFub3RoZXItYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHNlbGVjdGlvbiA9IG51bGw7XG4gICAgY2FuZGlkYXRlcyA9IFtdO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJFcnJvcigpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImVycm9yXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiaWNvblwiPiYjMTAwMDc7PC9kaXY+XG4gICAgICA8aDM+Q291bGRuJ3QgY3JlYXRlIG1vbml0b3I8L2gzPlxuICAgICAgPHA+JHtlc2NhcGVIdG1sKGVycm9yTWVzc2FnZSl9PC9wPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5XCIgaWQ9XCJ0cnktYWdhaW4tYnRuXCI+VHJ5IGFnYWluPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0cnktYWdhaW4tYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHN0YXRlID0gc2VsZWN0aW9uID8gXCJjb25maXJtXCIgOiBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gSGVscGVyc1xuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoc3RyOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICBkaXYudGV4dENvbnRlbnQgPSBzdHI7XG4gIHJldHVybiBkaXYuaW5uZXJIVE1MO1xufVxuXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gU3RhcnRcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5pbml0KCk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFHTyxNQUFNLFdBQVc7QUFDakIsTUFBTSxvQkFBb0I7QUFDMUIsTUFBTSxtQkFBbUI7QUFDekIsTUFBTSxtQkFBbUI7QUFHekIsTUFBTSxNQUFNO0FBQUEsSUFDakIsY0FBYztBQUFBLElBQ2QsZUFBZTtBQUFBLElBQ2Ysa0JBQWtCO0FBQUEsSUFDbEIsZ0JBQWdCO0FBQUEsSUFDaEIsbUJBQW1CO0FBQUEsSUFDbkIscUJBQXFCO0FBQUEsSUFDckIsaUJBQWlCO0FBQUEsRUFDbkI7OztBQ2ZBLGlCQUFzQixXQUFtQztBQUN2RCxVQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsbUJBQW1CLGdCQUFnQixDQUFDO0FBQ25GLFVBQU0sUUFBUSxPQUFPLGlCQUFpQjtBQUN0QyxVQUFNLFNBQVMsT0FBTyxnQkFBZ0I7QUFFdEMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFRLFFBQU87QUFFOUIsVUFBTSxXQUFXLElBQUksS0FBSyxNQUFNLEVBQUUsUUFBUTtBQUMxQyxRQUFJLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxXQUFXLEtBQUssSUFBSSxHQUFHO0FBQ3ZELFlBQU0sV0FBVztBQUNqQixhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU87QUFBQSxFQUNUO0FBU0EsaUJBQXNCLGFBQTRCO0FBQ2hELFVBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxDQUFDLG1CQUFtQixnQkFBZ0IsQ0FBQztBQUFBLEVBQ3pFO0FBRUEsaUJBQXNCLGVBQWlDO0FBQ3JELFVBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsV0FBTyxVQUFVO0FBQUEsRUFDbkI7OztBQ2hDTyxXQUFTLFdBQVcsS0FBcUI7QUFDOUMsV0FBTyxJQUFJLFFBQVEsTUFBTSxPQUFPLEVBQUUsUUFBUSxNQUFNLFFBQVEsRUFBRSxRQUFRLE1BQU0sT0FBTyxFQUFFLFFBQVEsTUFBTSxNQUFNLEVBQUUsUUFBUSxNQUFNLE1BQU07QUFBQSxFQUM3SDtBQUdBLE1BQU0sY0FBYyxDQUFDLFFBQVEsT0FBTyxPQUFPO0FBQ3BDLFdBQVMsYUFBYSxNQUFzQjtBQUNqRCxXQUFPLFlBQVksU0FBUyxJQUFJLElBQUksT0FBTztBQUFBLEVBQzdDOzs7QUNKQSxNQUFNLE1BQU07QUFvQ1osTUFBSSxRQUFvQjtBQUN4QixNQUFJLFdBQTRCO0FBQ2hDLE1BQUksWUFBOEI7QUFDbEMsTUFBSSxhQUEwQixDQUFDO0FBQy9CLE1BQUksZ0JBQWdCO0FBQ3BCLE1BQUksa0JBQWtCO0FBQ3RCLE1BQUksZUFBZTtBQUNuQixNQUFJLGVBQWU7QUFDbkIsTUFBSSxxQkFBcUI7QUFDekIsTUFBSSxzQkFBc0I7QUFDMUIsTUFBSSxlQUFlO0FBRW5CLE1BQU0sVUFBVSxTQUFTLGVBQWUsU0FBUztBQUNqRCxNQUFNLGNBQWMsU0FBUyxlQUFlLGNBQWM7QUFLMUQsTUFBTSxrQkFBa0I7QUFNeEIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksY0FBYztBQUVsQixpQkFBZSxPQUFzQjtBQUNuQyxRQUFJLGFBQWE7QUFDZixvQkFBYztBQUNkLGNBQVEsSUFBSSxLQUFLLHNDQUFzQztBQUN2RDtBQUFBLElBQ0Y7QUFDQSxrQkFBYztBQUNkLFlBQVEsSUFBSSxLQUFLLFlBQVk7QUFDN0IsUUFBSTtBQUdKLFlBQU0sQ0FBQyxHQUFHLElBQUksTUFBTSxPQUFPLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUMzRSxVQUFJLEtBQUs7QUFDUCx3QkFBZ0IsSUFBSSxPQUFPO0FBQzNCLDBCQUFrQixJQUFJLFNBQVM7QUFDL0IsdUJBQWUsSUFBSSxNQUFNO0FBQUEsTUFDM0I7QUFFQSxZQUFNLFFBQVEsTUFBTSxhQUFhO0FBQ2pDLFVBQUksQ0FBQyxPQUFPO0FBQ1YsZ0JBQVEsSUFBSSxLQUFLLDJCQUEyQjtBQUs1QyxjQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUM5RCxjQUFNLFlBQVksT0FBTyxPQUFPLGdCQUFnQixDQUFDO0FBQ2pELGNBQU0sVUFBVSxLQUFLLElBQUksSUFBSTtBQUM3QixZQUFJLE9BQU8sU0FBUyxTQUFTLEtBQUssVUFBVSxpQkFBaUI7QUFDM0QsY0FBSSxVQUFVLEtBQVE7QUFDcEIsb0JBQVEsSUFBSSxLQUFLLDhCQUE4QixLQUFLLE1BQU0sVUFBVSxHQUFJLEdBQUcsUUFBUTtBQUNuRixvQkFBUTtBQUFBLFVBQ1YsT0FBTztBQUNMLG9CQUFRLEtBQUssS0FBSyxxRUFBZ0U7QUFDbEYsb0JBQVE7QUFBQSxVQUNWO0FBQUEsUUFDRixPQUFPO0FBQ0wsa0JBQVE7QUFBQSxRQUNWO0FBRUEsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUdBLFlBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsVUFBSSxDQUFDLE9BQU87QUFDVixnQkFBUSxJQUFJLEtBQUssNkNBQTZDO0FBQzlELGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLGNBQVEsSUFBSSxLQUFLLGlDQUFpQztBQUNsRCxVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLFFBQVEseUJBQXlCO0FBQUEsVUFDMUQsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLEdBQUc7QUFBQSxRQUM5QyxDQUFDO0FBRUQsWUFBSSxDQUFDLElBQUksSUFBSTtBQUNYLGtCQUFRLEtBQUssS0FBSyxtQkFBbUIsSUFBSSxNQUFNO0FBQy9DLGdCQUFNLFdBQVc7QUFDakIsa0JBQVE7QUFDUixpQkFBTztBQUNQO0FBQUEsUUFDRjtBQUVBLG1CQUFXLE1BQU0sSUFBSSxLQUFLLEVBQUUsTUFBTSxNQUFNLElBQUk7QUFDNUMsWUFBSSxDQUFDLFlBQVksT0FBTyxTQUFTLFdBQVcsWUFBWSxPQUFPLFNBQVMsU0FBUyxVQUFVO0FBQ3pGLGtCQUFRLEtBQUssS0FBSyw4QkFBOEIsUUFBUTtBQUN4RCxnQkFBTSxXQUFXO0FBQ2pCLGtCQUFRO0FBQ1IsaUJBQU87QUFDUDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxnQkFBZ0IsU0FBUyxDQUFDO0FBRTNELGNBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxnQkFBZ0I7QUFDbEQsZ0JBQVE7QUFDUixnQkFBUSxJQUFJLEtBQUssb0JBQW9CLFNBQVMsS0FBSztBQUFBLE1BQ3JELFNBQVMsS0FBSztBQUNaLGdCQUFRLEtBQUssS0FBSyx5QkFBeUIsR0FBRztBQUU5QyxjQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUM5RCxjQUFNLElBQUksT0FBTztBQUNqQixZQUFJLEtBQUssT0FBTyxFQUFFLFdBQVcsWUFBWSxPQUFPLEVBQUUsU0FBUyxZQUFZLE9BQU8sRUFBRSxVQUFVLFVBQVU7QUFDbEcscUJBQVc7QUFDWCxrQkFBUTtBQUFBLFFBQ1YsT0FBTztBQUNMLGtCQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDUCxVQUFFO0FBQ0Esb0JBQWM7QUFDZCxVQUFJLGFBQWE7QUFDZixzQkFBYztBQUNkLGFBQUssS0FBSztBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQU1BLFNBQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxZQUFZO0FBQ2hELFFBQUksUUFBUSxTQUFTLElBQUksa0JBQWtCO0FBQ3pDLGtCQUFZO0FBQUEsUUFDVixVQUFVLFFBQVE7QUFBQSxRQUNsQixjQUFjLFFBQVE7QUFBQSxRQUN0QixLQUFLLFFBQVE7QUFBQSxRQUNiLFdBQVcsUUFBUTtBQUFBLE1BQ3JCO0FBQ0EsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBSSxRQUFRLFNBQVMsSUFBSSxtQkFBbUI7QUFDMUMsbUJBQWEsUUFBUSxjQUFjLENBQUM7QUFDcEMsVUFBSSxVQUFVLG1CQUFtQixVQUFVLFdBQVc7QUFDcEQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsUUFBSSxRQUFRLFNBQVMsSUFBSSxlQUFlO0FBQ3RDLFVBQUksVUFBVSxXQUFXO0FBQ3ZCLGdCQUFRO0FBQ1IsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsUUFBSSxRQUFRLFNBQVMscUJBQXFCO0FBRXhDLFdBQUs7QUFBQSxJQUNQO0FBQUEsRUFDRixDQUFDO0FBSUQsU0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLFNBQVMsU0FBUztBQUN0RCxRQUFJLFNBQVMsUUFBUztBQUN0QixRQUFJLFFBQVEsaUJBQWlCLEdBQUcsVUFBVTtBQUN4QyxjQUFRLElBQUksS0FBSyw4REFBOEQ7QUFDL0UsV0FBSyxLQUFLO0FBQUEsSUFDWjtBQUFBLEVBQ0YsQ0FBQztBQU1ELFdBQVMsU0FBZTtBQUN0QixrQkFBYztBQUVkLFlBQVEsT0FBTztBQUFBLE1BQ2IsS0FBSztBQUNILHFCQUFhO0FBQ2I7QUFBQSxNQUNGLEtBQUs7QUFDSCx5QkFBaUI7QUFDakI7QUFBQSxNQUNGLEtBQUs7QUFDSCx5QkFBaUI7QUFDakI7QUFBQSxNQUNGLEtBQUs7QUFDSCw0QkFBb0I7QUFDcEI7QUFBQSxNQUNGLEtBQUs7QUFDSCxzQkFBYztBQUNkO0FBQUEsTUFDRixLQUFLO0FBQ0gsc0JBQWM7QUFDZDtBQUFBLE1BQ0YsS0FBSztBQUNILHVCQUFlO0FBQ2Y7QUFBQSxNQUNGLEtBQUs7QUFDSCxzQkFBYztBQUNkO0FBQUEsTUFDRixLQUFLO0FBQ0gsb0JBQVk7QUFDWjtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBRUEsV0FBUyxnQkFBc0I7QUFDN0IsUUFBSSxDQUFDLFVBQVU7QUFDYixrQkFBWSxZQUFZO0FBQ3hCO0FBQUEsSUFDRjtBQUVBLGdCQUFZLFlBQVk7QUFBQTtBQUFBLFFBRWxCLFdBQVcsU0FBUyxTQUFTLFdBQVcsQ0FBQztBQUFBO0FBQUEsbUNBRWQsZUFBZSxLQUFLLFFBQVE7QUFBQTtBQUFBLFVBRXJELFdBQVcsU0FBUyxTQUFTLFNBQVMsTUFBTSxDQUFDO0FBQUEsdUNBQ2hCLGFBQWEsU0FBUyxJQUFJLENBQUMsS0FBSyxXQUFXLFNBQVMsSUFBSSxDQUFDO0FBQUE7QUFBQSx1Q0FFekQsUUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTTdDLGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDMUUsUUFBRSxnQkFBZ0I7QUFDbEIscUJBQWUsQ0FBQztBQUNoQixvQkFBYztBQUFBLElBQ2hCLENBQUM7QUFFRCxhQUFTLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLFNBQVMsWUFBWTtBQUMvRSxZQUFNLFdBQVc7QUFDakIsWUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLGdCQUFnQjtBQUNsRCxpQkFBVztBQUNYLHFCQUFlO0FBQ2YsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFHRCxhQUFTLGlCQUFpQixTQUFTLE1BQU07QUFDdkMsVUFBSSxjQUFjO0FBQ2hCLHVCQUFlO0FBQ2Ysc0JBQWM7QUFBQSxNQUNoQjtBQUFBLElBQ0YsR0FBRyxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQUEsRUFDbkI7QUFFQSxXQUFTLGVBQXFCO0FBQzVCLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVFwQixhQUFTLGVBQWUsYUFBYSxHQUFHLGlCQUFpQixTQUFTLGFBQWE7QUFBQSxFQUNqRjtBQUVBLFdBQVMsbUJBQXlCO0FBQ2hDLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVdwQixhQUFTLGVBQWUsbUJBQW1CLEdBQUcsaUJBQWlCLFNBQVMsYUFBYTtBQUFBLEVBQ3ZGO0FBRUEsaUJBQWUsZ0JBQStCO0FBQzVDLFlBQVEsSUFBSSxLQUFLLG9CQUFvQjtBQUlyQyxRQUFJLG9CQUFvQjtBQUN4QixRQUFJO0FBQ0YsWUFBTSxTQUFTLElBQUksSUFBSSxRQUFRLEVBQUU7QUFDakMsMEJBQW9CLE1BQU0sT0FBTyxZQUFZLFNBQVMsRUFBRSxTQUFTLENBQUMsR0FBRyxNQUFNLElBQUksRUFBRSxDQUFDO0FBQ2xGLGNBQVEsSUFBSSxLQUFLLG9DQUFvQyxpQkFBaUI7QUFDdEUsVUFBSSxDQUFDLG1CQUFtQjtBQUN0Qiw0QkFBb0IsTUFBTSxPQUFPLFlBQVksUUFBUSxFQUFFLFNBQVMsQ0FBQyxHQUFHLE1BQU0sSUFBSSxFQUFFLENBQUM7QUFDakYsZ0JBQVEsSUFBSSxLQUFLLG1DQUFtQyxpQkFBaUI7QUFBQSxNQUN2RTtBQUFBLElBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBUSxLQUFLLEtBQUssNkJBQTZCLEdBQUc7QUFBQSxJQUVwRDtBQUtBLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxJQUFJLEVBQUUsQ0FBQztBQUVqRSxRQUFJO0FBQ0osUUFBSTtBQUNGLFlBQU0sTUFBTSxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssR0FBRyxRQUFRLGtCQUFrQixDQUFDO0FBQUEsSUFDdEUsU0FBUyxLQUFLO0FBQ1osY0FBUSxNQUFNLEtBQUssNEJBQTRCLEdBQUc7QUFDbEQsY0FBUTtBQUNSLGFBQU87QUFDUDtBQUFBLElBQ0Y7QUFDQSxZQUFRLElBQUksS0FBSyxxQkFBcUIsSUFBSSxFQUFFO0FBRzVDLFFBQUksSUFBSSxJQUFJO0FBQ1YsYUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLElBQUksaUJBQWlCLE9BQU8sSUFBSSxHQUFHLENBQUMsRUFBRTtBQUFBLFFBQU0sQ0FBQyxRQUM5RSxRQUFRLEtBQUssS0FBSyxnREFBZ0QsR0FBRztBQUFBLE1BQ3ZFO0FBQUEsSUFDRjtBQUVBLFlBQVE7QUFDUixXQUFPO0FBQUEsRUFDVDtBQUVBLFdBQVMsbUJBQXlCO0FBQ2hDLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBU3BCLGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9FLFlBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxnQkFBZ0I7QUFDbEQsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBUyxzQkFBNEI7QUFDbkMsVUFBTSxlQUFlLGNBQWMsU0FBUyxLQUN4QyxjQUFjLE1BQU0sR0FBRyxFQUFFLElBQUksUUFDN0I7QUFFSixRQUFJLGlCQUFpQjtBQUNyQixRQUFJLFdBQVcsU0FBUyxHQUFHO0FBQ3pCLHVCQUFpQjtBQUFBO0FBQUEsUUFFYixXQUNDO0FBQUEsUUFDQyxDQUFDLEdBQUcsTUFBTTtBQUFBLDJDQUN1QixDQUFDO0FBQUEseUNBQ0gsV0FBVyxFQUFFLElBQUksQ0FBQztBQUFBLDZDQUNkLFdBQVcsRUFBRSxRQUFRLENBQUM7QUFBQSw2RUFDVSxDQUFDO0FBQUE7QUFBQTtBQUFBLE1BR3RFLEVBQ0MsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBLElBRWY7QUFFQSxZQUFRLFlBQVk7QUFBQSwwREFDb0MsV0FBVyxZQUFZLENBQUM7QUFBQSxNQUM1RSxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFhbEIsYUFBUyxlQUFlLFVBQVUsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ25FLGFBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxJQUFJLGNBQWMsT0FBTyxhQUFhLENBQUM7QUFDMUUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFHRCxhQUFTLGlCQUFpQixrQkFBa0IsRUFBRSxRQUFRLENBQUMsUUFBUTtBQUM3RCxVQUFJLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUNuQyxjQUFNLE1BQU0sU0FBVSxFQUFFLE9BQXVCLFFBQVEsT0FBTyxHQUFHO0FBQ2pFLGNBQU0sSUFBSSxXQUFXLEdBQUc7QUFDeEIsWUFBSSxHQUFHO0FBQ0wsc0JBQVk7QUFBQSxZQUNWLFVBQVUsRUFBRTtBQUFBLFlBQ1osY0FBYyxFQUFFO0FBQUEsWUFDaEIsS0FBSztBQUFBLFlBQ0wsV0FBVztBQUFBLFVBQ2I7QUFDQSxrQkFBUTtBQUNSLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdELGFBQVMsZUFBZSxpQkFBaUIsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQzFFLFlBQU0sS0FBSyxTQUFTLGVBQWUsa0JBQWtCO0FBQ3JELFVBQUksVUFBVSxPQUFPLE1BQU07QUFBQSxJQUM3QixDQUFDO0FBR0QsYUFBUyxlQUFlLGtCQUFrQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDM0UsWUFBTSxRQUFRLFNBQVMsZUFBZSxpQkFBaUI7QUFDdkQsWUFBTSxXQUFXLE9BQU8sTUFBTSxLQUFLO0FBQ25DLFVBQUksVUFBVTtBQUNaLG9CQUFZO0FBQUEsVUFDVjtBQUFBLFVBQ0EsY0FBYztBQUFBLFVBQ2QsS0FBSztBQUFBLFVBQ0wsV0FBVztBQUFBLFFBQ2I7QUFDQSxnQkFBUTtBQUNSLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsZ0JBQXNCO0FBQzdCLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBU3BCLGFBQVMsZUFBZSxhQUFhLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN0RSxhQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sSUFBSSxlQUFlLE9BQU8sYUFBYSxDQUFDO0FBQzNFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsZ0JBQXNCO0FBQzdCLFFBQUksQ0FBQyxVQUFXO0FBRWhCLFVBQU0sT0FBTyxVQUFVLFFBQVE7QUFDL0IsVUFBTSxpQkFBaUIsU0FBUztBQUNoQyxVQUFNLGVBQWUsVUFBVSxhQUFhLElBQUksTUFBTSxHQUFHLEdBQUc7QUFFNUQsWUFBUSxZQUFZO0FBQUEsMERBQ29DO0FBQUEsTUFDcEQsVUFBVSxJQUFJLFNBQVMsS0FBSyxVQUFVLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxRQUFRLFVBQVU7QUFBQSxJQUM3RSxDQUFDO0FBQUE7QUFBQTtBQUFBLFFBSUcsVUFBVSxlQUNOLGlDQUFpQyxXQUFXLFVBQVUsYUFBYSxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsV0FDakYsRUFDTjtBQUFBLDhCQUN3QixXQUFXLFVBQVUsUUFBUSxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUVBSVcsV0FBVyxXQUFXLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQVExRCxpQkFBaUIsYUFBYSxFQUFFO0FBQUEsZ0VBQ0osaUJBQWlCLGFBQWEsRUFBRTtBQUFBO0FBQUEsWUFFcEYsaUJBQWlCLDZDQUE2QyxFQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVUxRSxhQUFTLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN6RSxrQkFBWTtBQUNaLGFBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxJQUFJLGNBQWMsT0FBTyxhQUFhLENBQUM7QUFDMUUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFFRCxhQUFTLGVBQWUsWUFBWSxHQUFHLGlCQUFpQixTQUFTLGFBQWE7QUFBQSxFQUNoRjtBQUVBLGlCQUFlLGdCQUErQjtBQUM1QyxRQUFJLENBQUMsYUFBYSxVQUFVLFdBQVk7QUFFeEMsVUFBTSxZQUFZLFNBQVMsZUFBZSxjQUFjO0FBQ3hELFVBQU0sT0FBTyxXQUFXLE1BQU0sS0FBSyxLQUFLO0FBQ3hDLFVBQU0sWUFDSCxTQUFTLGNBQWMsaUNBQWlDLEdBQXdCLFNBQVM7QUFFNUYsWUFBUTtBQUNSLHlCQUFxQjtBQUNyQiwwQkFBc0IsVUFBVTtBQUNoQyxXQUFPO0FBRVAsUUFBSTtBQUNGLFlBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsVUFBSSxDQUFDLE9BQU87QUFDVix1QkFBZTtBQUNmLGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLFlBQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxRQUFRLDJCQUEyQjtBQUFBLFFBQzVELFFBQVE7QUFBQSxRQUNSLFNBQVM7QUFBQSxVQUNQLGdCQUFnQjtBQUFBLFVBQ2hCLGVBQWUsVUFBVSxLQUFLO0FBQUEsUUFDaEM7QUFBQSxRQUNBLE1BQU0sS0FBSyxVQUFVO0FBQUEsVUFDbkI7QUFBQSxVQUNBLEtBQUssVUFBVTtBQUFBLFVBQ2YsVUFBVSxVQUFVO0FBQUEsVUFDcEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILENBQUM7QUFFRCxVQUFJLElBQUksSUFBSTtBQUNWLGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLFlBQU0sT0FBTyxNQUFNLElBQUksS0FBSyxFQUFFLE1BQU0sTUFBTSxJQUFJO0FBRTlDLFVBQUksTUFBTSxTQUFTLHNCQUFzQjtBQUN2Qyx1QkFBZSxHQUFHLEtBQUssV0FBVyxLQUFLLFNBQVMsd0JBQXdCO0FBQ3hFLGdCQUFRO0FBQ1IsZUFBTztBQUVQLGNBQU0sZUFBZSxRQUFRLGNBQWMsVUFBVTtBQUNyRCxZQUFJLGNBQWM7QUFDaEIsdUJBQWEsWUFBWSxTQUFTLGNBQWMsSUFBSSxDQUFDO0FBQ3JELGdCQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7QUFDdkMsZUFBSyxPQUFPLEdBQUcsUUFBUTtBQUN2QixlQUFLLFNBQVM7QUFDZCxlQUFLLE1BQU0sUUFBUTtBQUNuQixlQUFLLGNBQWM7QUFDbkIsdUJBQWEsWUFBWSxJQUFJO0FBQUEsUUFDL0I7QUFDQTtBQUFBLE1BQ0Y7QUFFQSxxQkFBZSxNQUFNLFdBQVcsTUFBTSxTQUFTLFdBQVcsSUFBSSxNQUFNO0FBQ3BFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxRQUFRO0FBQ04scUJBQWU7QUFDZixjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsV0FBUyxpQkFBdUI7QUFDOUIsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTXRCO0FBRUEsV0FBUyxnQkFBc0I7QUFDN0IsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUgsV0FBVyxrQkFBa0IsQ0FBQztBQUFBLFFBQ3pDLHNCQUFzQixzQ0FBc0MsV0FBVyxvQkFBb0IsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLDJCQUEyQixFQUFFO0FBQUE7QUFBQSxrREFFM0YsUUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTXhELGFBQVMsZUFBZSxtQkFBbUIsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQzVFLGtCQUFZO0FBQ1osbUJBQWEsQ0FBQztBQUNkLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsY0FBb0I7QUFDM0IsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJWCxXQUFXLFlBQVksQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUtqQyxhQUFTLGVBQWUsZUFBZSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDeEUsY0FBUSxZQUFZLFlBQVk7QUFDaEMsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFNQSxXQUFTLFdBQVcsS0FBcUI7QUFDdkMsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksY0FBYztBQUNsQixXQUFPLElBQUk7QUFBQSxFQUNiO0FBT0EsT0FBSzsiLAogICJuYW1lcyI6IFtdCn0K
