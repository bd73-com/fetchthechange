"use strict";
(() => {
  // src/shared/constants.ts
  var BASE_URL = "https://ftc.bd73.com";
  var TOKEN_STORAGE_KEY = "ftc_extension_token";
  var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
  var AUTH_STARTED_KEY = "ftc_auth_started_at";
  var PENDING_SELECTION_KEY = "ftc_pending_selection";
  var MSG = {
    START_PICKER: "FTC_START_PICKER",
    CANCEL_PICKER: "FTC_CANCEL_PICKER",
    ELEMENT_SELECTED: "FTC_ELEMENT_SELECTED",
    GET_CANDIDATES: "FTC_GET_CANDIDATES",
    CANDIDATES_RESULT: "FTC_CANDIDATES_RESULT",
    FTC_EXTENSION_TOKEN: "FTC_EXTENSION_TOKEN",
    AUTH_TAB_OPENED: "FTC_AUTH_TAB_OPENED"
  };

  // src/auth/token.ts
  async function getToken() {
    const result = await chrome.storage.local.get([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
    const token = result[TOKEN_STORAGE_KEY];
    const expiry = result[TOKEN_EXPIRY_KEY];
    if (!token || !expiry) return null;
    const expiryMs = new Date(expiry).getTime();
    if (!Number.isFinite(expiryMs) || expiryMs < Date.now()) {
      await clearToken();
      return null;
    }
    return token;
  }
  async function clearToken() {
    await chrome.storage.local.remove([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
  }
  async function isTokenValid() {
    const token = await getToken();
    return token !== null;
  }

  // src/popup/utils.ts
  function escapeAttr(str) {
    return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  var KNOWN_TIERS = ["free", "pro", "power"];
  function sanitizeTier(tier) {
    return KNOWN_TIERS.includes(tier) ? tier : "free";
  }

  // src/popup/popup.ts
  var TAG = "[FTC:popup]";
  var state = "unauthenticated";
  var userInfo = null;
  var selection = null;
  var candidates = [];
  var currentTabUrl = "";
  var currentTabTitle = "";
  var currentTabId = 0;
  var errorMessage = "";
  var createdMonitorName = "";
  var createdMonitorValue = "";
  var dropdownOpen = false;
  var content = document.getElementById("content");
  var accountArea = document.getElementById("account-area");
  var AUTH_TIMEOUT_MS = 12e4;
  var initRunning = false;
  var initPending = false;
  async function init() {
    if (initRunning) {
      initPending = true;
      console.log(TAG, "init already running, queueing rerun");
      return;
    }
    initRunning = true;
    console.log(TAG, "init start");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        currentTabUrl = tab.url || "";
        currentTabTitle = tab.title || "";
        currentTabId = tab.id || 0;
      }
      const valid = await isTokenValid();
      if (!valid) {
        console.log(TAG, "no valid token in storage");
        const stored = await chrome.storage.local.get(AUTH_STARTED_KEY);
        const startedAt = Number(stored[AUTH_STARTED_KEY]);
        const elapsed = Date.now() - startedAt;
        if (Number.isFinite(startedAt) && elapsed < AUTH_TIMEOUT_MS) {
          if (elapsed < 3e4) {
            console.log(TAG, "auth attempt in progress (", Math.round(elapsed / 1e3), "s ago)");
            state = "connecting";
          } else {
            console.warn(TAG, "recent auth attempt found but no token \u2014 showing failure state");
            state = "auth_failed";
          }
        } else {
          state = "unauthenticated";
        }
        render();
        return;
      }
      const token = await getToken();
      if (!token) {
        console.log(TAG, "getToken returned null despite isTokenValid");
        state = "unauthenticated";
        render();
        return;
      }
      console.log(TAG, "verifying token with backend...");
      try {
        const res = await fetch(`${BASE_URL}/api/extension/verify`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) {
          console.warn(TAG, "verify returned", res.status);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        userInfo = await res.json().catch(() => null);
        if (!userInfo || typeof userInfo.userId !== "string" || typeof userInfo.tier !== "string") {
          console.warn(TAG, "verify response malformed:", userInfo);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        await chrome.storage.local.set({ cachedUserInfo: userInfo });
        await chrome.storage.local.remove(AUTH_STARTED_KEY);
        state = "authenticated";
        console.log(TAG, "authenticated as", userInfo.email);
      } catch (err) {
        console.warn(TAG, "verify network error:", err);
        const cached = await chrome.storage.local.get("cachedUserInfo");
        const c = cached.cachedUserInfo;
        if (c && typeof c.userId === "string" && typeof c.tier === "string" && typeof c.email === "string") {
          userInfo = c;
          state = "authenticated";
        } else {
          state = "unauthenticated";
        }
      }
      if (state === "authenticated") {
        const pending = await chrome.storage.local.get(PENDING_SELECTION_KEY);
        const stored = pending[PENDING_SELECTION_KEY];
        if (stored && typeof stored.selector === "string") {
          const age = stored.timestamp ? Date.now() - stored.timestamp : Infinity;
          await chrome.storage.local.remove(PENDING_SELECTION_KEY);
          if (age < 6e5) {
            console.log(TAG, "pending selection found in storage, jumping to confirm");
            selection = {
              selector: stored.selector,
              currentValue: typeof stored.currentValue === "string" ? stored.currentValue : "",
              url: typeof stored.url === "string" ? stored.url : currentTabUrl,
              pageTitle: typeof stored.pageTitle === "string" ? stored.pageTitle : currentTabTitle
            };
            state = "confirm";
            render();
            return;
          } else {
            console.log(TAG, "pending selection too old (", Math.round(age / 1e3), "s), discarding");
          }
        }
      }
      render();
    } finally {
      initRunning = false;
      if (initPending) {
        initPending = false;
        if (state !== "confirm") {
          void init();
        }
      }
    }
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === MSG.ELEMENT_SELECTED) {
      const sel = typeof message.selector === "string" ? message.selector : "";
      if (!sel) return;
      selection = {
        selector: sel,
        currentValue: typeof message.currentValue === "string" ? message.currentValue : "",
        url: typeof message.url === "string" ? message.url : currentTabUrl,
        pageTitle: typeof message.pageTitle === "string" ? message.pageTitle : currentTabTitle
      };
      state = "confirm";
      render();
    }
    if (message.type === MSG.CANDIDATES_RESULT) {
      candidates = message.candidates || [];
      if (state === "authenticated" || state === "picking") {
        render();
      }
    }
    if (message.type === MSG.CANCEL_PICKER) {
      if (state === "picking") {
        state = "authenticated";
        render();
      }
    }
    if (message.type === "FTC_AUTH_COMPLETE") {
      init();
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[TOKEN_STORAGE_KEY]?.newValue) {
      console.log(TAG, "token appeared in storage (direct write), re-initialising...");
      void init();
    }
    if (changes[PENDING_SELECTION_KEY]?.newValue && state !== "confirm") {
      console.log(TAG, "pending selection appeared in storage, re-initialising...");
      void init();
    }
  });
  function render() {
    renderAccount();
    switch (state) {
      case "unauthenticated":
        renderUnauth();
        break;
      case "connecting":
        renderConnecting();
        break;
      case "auth_failed":
        renderAuthFailed();
        break;
      case "authenticated":
        renderAuthenticated();
        break;
      case "picking":
        renderPicking();
        break;
      case "confirm":
        renderConfirm();
        break;
      case "creating":
        renderCreating();
        break;
      case "success":
        renderSuccess();
        break;
      case "error":
        renderError();
        break;
    }
  }
  function renderAccount() {
    if (!userInfo) {
      accountArea.innerHTML = "";
      return;
    }
    accountArea.innerHTML = `
    <button class="account-btn" id="account-toggle">
      ${escapeHtml(userInfo.email || "Connected")} &#9662;
    </button>
    <div class="account-dropdown ${dropdownOpen ? "" : "hidden"}" id="account-dropdown">
      <div class="dropdown-email">
        ${escapeHtml(userInfo.email || userInfo.userId)}
        <span class="tier-badge tier-${sanitizeTier(userInfo.tier)}">${escapeHtml(userInfo.tier)}</span>
      </div>
      <a class="dropdown-item" href="${BASE_URL}/dashboard" target="_blank">Open dashboard</a>
      <div class="dropdown-divider"></div>
      <button class="dropdown-item" id="disconnect-btn">Disconnect</button>
    </div>
  `;
    document.getElementById("account-toggle")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdownOpen = !dropdownOpen;
      renderAccount();
    });
    document.getElementById("disconnect-btn")?.addEventListener("click", async () => {
      await clearToken();
      await chrome.storage.local.remove("cachedUserInfo");
      userInfo = null;
      dropdownOpen = false;
      state = "unauthenticated";
      render();
    });
    document.addEventListener("click", () => {
      if (dropdownOpen) {
        dropdownOpen = false;
        renderAccount();
      }
    }, { once: true });
  }
  function renderUnauth() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Track what matters on any webpage.</h2>
      <button class="btn btn-primary btn-full" id="connect-btn">Connect your account</button>
      <p>Already have an account? Sign in above.</p>
    </div>
  `;
    document.getElementById("connect-btn")?.addEventListener("click", startAuthFlow);
  }
  function renderAuthFailed() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Connection failed</h2>
      <p>We couldn't connect the extension to your account. This can happen if your browser blocked the connection.</p>
      <button class="btn btn-primary btn-full" id="retry-connect-btn">Try again</button>
      <p style="margin-top: 12px; font-size: 12px; opacity: 0.7;">
        Tip: when Chrome asks to allow access to ftc.bd73.com, click <strong>Allow</strong>.
      </p>
    </div>
  `;
    document.getElementById("retry-connect-btn")?.addEventListener("click", startAuthFlow);
  }
  async function startAuthFlow() {
    console.log(TAG, "starting auth flow");
    let permissionGranted = false;
    try {
      const origin = new URL(BASE_URL).origin;
      permissionGranted = await chrome.permissions.contains({ origins: [`${origin}/*`] });
      console.log(TAG, "host permission already granted:", permissionGranted);
      if (!permissionGranted) {
        permissionGranted = await chrome.permissions.request({ origins: [`${origin}/*`] });
        console.log(TAG, "host permission request result:", permissionGranted);
      }
    } catch (err) {
      console.warn(TAG, "permission request error:", err);
    }
    await chrome.storage.local.set({ [AUTH_STARTED_KEY]: Date.now() });
    let tab;
    try {
      tab = await chrome.tabs.create({ url: `${BASE_URL}/extension-auth` });
    } catch (err) {
      console.error(TAG, "failed to open auth tab:", err);
      state = "auth_failed";
      render();
      return;
    }
    console.log(TAG, "auth tab created:", tab.id);
    if (tab.id) {
      chrome.runtime.sendMessage({ type: MSG.AUTH_TAB_OPENED, tabId: tab.id }).catch(
        (err) => console.warn(TAG, "failed to notify service worker of auth tab:", err)
      );
    }
    state = "connecting";
    render();
  }
  function renderConnecting() {
    content.innerHTML = `
    <div class="connecting">
      <div class="spinner"></div>
      <p>Connecting...</p>
      <p>Waiting for you to sign in at FetchTheChange.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-connect" style="margin-top: 16px;">Cancel</button>
    </div>
  `;
    document.getElementById("cancel-connect")?.addEventListener("click", async () => {
      await chrome.storage.local.remove(AUTH_STARTED_KEY);
      state = "unauthenticated";
      render();
    });
  }
  function renderAuthenticated() {
    const truncatedUrl = currentTabUrl.length > 45 ? currentTabUrl.slice(0, 45) + "..." : currentTabUrl;
    let candidatesHtml = "";
    if (candidates.length > 0) {
      candidatesHtml = `
      <div class="section-header">Suggested elements</div>
      ${candidates.map(
        (c, i) => `
        <div class="candidate" data-idx="${i}">
          <span class="candidate-text">${escapeHtml(c.text)}</span>
          <span class="candidate-selector">${escapeHtml(c.selector)}</span>
          <button class="btn btn-primary btn-sm candidate-track" data-idx="${i}">Track this</button>
        </div>
      `
      ).join("")}
    `;
    }
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(truncatedUrl)}</div>
    ${candidatesHtml}
    <div class="section-header">Or pick manually</div>
    <button class="btn btn-primary btn-full" id="pick-btn">Pick an element on this page</button>
    <button class="advanced-toggle" id="advanced-toggle">&#9662; Advanced (CSS selector)</button>
    <div class="advanced-content" id="advanced-content">
      <div class="form-group">
        <input type="text" class="form-input" id="manual-selector" placeholder="e.g. .product-price">
      </div>
      <button class="btn btn-secondary btn-sm" id="manual-track-btn">Use this selector</button>
    </div>
  `;
    document.getElementById("pick-btn")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.querySelectorAll(".candidate-track").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const idx = parseInt(e.target.dataset.idx || "0");
        const c = candidates[idx];
        if (c) {
          selection = {
            selector: c.selector,
            currentValue: c.text,
            url: currentTabUrl,
            pageTitle: currentTabTitle
          };
          state = "confirm";
          render();
        }
      });
    });
    document.getElementById("advanced-toggle")?.addEventListener("click", () => {
      const el = document.getElementById("advanced-content");
      el?.classList.toggle("open");
    });
    document.getElementById("manual-track-btn")?.addEventListener("click", () => {
      const input = document.getElementById("manual-selector");
      const selector = input?.value.trim();
      if (selector) {
        selection = {
          selector,
          currentValue: "",
          url: currentTabUrl,
          pageTitle: ""
        };
        state = "confirm";
        render();
      }
    });
  }
  function renderPicking() {
    content.innerHTML = `
    <div class="picker-info">
      <div class="icon">&#127919;</div>
      <p><strong>Click any element on the page to track it.</strong></p>
      <p>Press Esc to cancel.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-pick" style="margin-top: 16px;">Cancel picking</button>
    </div>
  `;
    document.getElementById("cancel-pick")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.CANCEL_PICKER, tabId: currentTabId });
      state = "authenticated";
      render();
    });
  }
  function renderConfirm() {
    if (!selection) return;
    const tier = userInfo?.tier || "free";
    const hourlyDisabled = tier === "free";
    const defaultName = (selection.pageTitle || "").slice(0, 100);
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(
      selection.url.length > 45 ? selection.url.slice(0, 45) + "..." : selection.url
    )}</div>
    <div class="confirm-card">
      <div class="label">Element selected</div>
      ${selection.currentValue ? `<div class="value">Currently: ${escapeHtml(selection.currentValue.slice(0, 100))}</div>` : ""}
      <div class="selector">${escapeHtml(selection.selector)}</div>
    </div>
    <div class="form-group">
      <label class="form-label">Monitor name</label>
      <input type="text" class="form-input" id="monitor-name" value="${escapeAttr(defaultName)}" maxlength="100">
    </div>
    <div class="form-group">
      <label class="form-label">Check frequency</label>
      <div class="radio-group">
        <label class="radio-label">
          <input type="radio" name="frequency" value="daily" checked> Daily
        </label>
        <label class="radio-label ${hourlyDisabled ? "disabled" : ""}">
          <input type="radio" name="frequency" value="hourly" ${hourlyDisabled ? "disabled" : ""}>
          Hourly
          ${hourlyDisabled ? '<span class="tooltip-text">(Pro+)</span>' : ""}
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="pick-again-btn"
        ${selection.url && selection.url !== currentTabUrl ? 'disabled title="Switch to the original tab to pick again"' : ""}>Pick again</button>
      <button class="btn btn-primary" id="create-btn">Create monitor</button>
    </div>
  `;
    document.getElementById("pick-again-btn")?.addEventListener("click", () => {
      selection = null;
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.getElementById("create-btn")?.addEventListener("click", createMonitor);
  }
  async function createMonitor() {
    if (!selection || state === "creating") return;
    const nameInput = document.getElementById("monitor-name");
    const name = nameInput?.value.trim() || "Untitled monitor";
    const frequency = document.querySelector('input[name="frequency"]:checked')?.value || "daily";
    state = "creating";
    createdMonitorName = name;
    createdMonitorValue = selection.currentValue;
    render();
    try {
      const token = await getToken();
      if (!token) {
        errorMessage = "Not authenticated. Please reconnect.";
        state = "error";
        render();
        return;
      }
      const res = await fetch(`${BASE_URL}/api/extension/monitors`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name,
          url: selection.url,
          selector: selection.selector,
          frequency
        })
      });
      if (res.ok) {
        state = "success";
        render();
        return;
      }
      const data = await res.json().catch(() => null);
      if (data?.code === "TIER_LIMIT_REACHED") {
        errorMessage = `${data.message || data.error || "Monitor limit reached."}`;
        state = "error";
        render();
        const errContainer = content.querySelector(".error p");
        if (errContainer) {
          errContainer.appendChild(document.createElement("br"));
          const link = document.createElement("a");
          link.href = `${BASE_URL}/pricing`;
          link.target = "_blank";
          link.style.color = "#6366f1";
          link.textContent = "Upgrade your plan";
          errContainer.appendChild(link);
        }
        return;
      }
      errorMessage = data?.message || data?.error || `Failed (${res.status})`;
      state = "error";
      render();
    } catch {
      errorMessage = "Network error. Please try again.";
      state = "error";
      render();
    }
  }
  function renderCreating() {
    content.innerHTML = `
    <div class="connecting" style="padding-top: 64px;">
      <div class="spinner"></div>
      <p>Creating monitor...</p>
    </div>
  `;
  }
  function renderSuccess() {
    content.innerHTML = `
    <div class="success">
      <div class="icon">&#10003;</div>
      <h3>Monitor created!</h3>
      <p><strong>${escapeHtml(createdMonitorName)}</strong> is now being watched.</p>
      ${createdMonitorValue ? `<p>You'll be notified when <strong>${escapeHtml(createdMonitorValue.slice(0, 60))}</strong> changes.</p>` : ""}
      <div class="btn-row" style="margin-top: 24px; justify-content: center;">
        <a class="btn btn-primary btn-sm" href="${BASE_URL}/dashboard" target="_blank">View in dashboard</a>
        <button class="btn btn-secondary btn-sm" id="track-another-btn">Track another</button>
      </div>
    </div>
  `;
    document.getElementById("track-another-btn")?.addEventListener("click", () => {
      selection = null;
      candidates = [];
      state = "authenticated";
      render();
    });
  }
  function renderError() {
    content.innerHTML = `
    <div class="error">
      <div class="icon">&#10007;</div>
      <h3>Couldn't create monitor</h3>
      <p>${escapeHtml(errorMessage)}</p>
      <button class="btn btn-secondary" id="try-again-btn">Try again</button>
    </div>
  `;
    document.getElementById("try-again-btn")?.addEventListener("click", () => {
      state = selection ? "confirm" : "authenticated";
      render();
    });
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
  init();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL3NoYXJlZC9jb25zdGFudHMudHMiLCAiLi4vLi4vc3JjL2F1dGgvdG9rZW4udHMiLCAiLi4vLi4vc3JjL3BvcHVwL3V0aWxzLnRzIiwgIi4uLy4uL3NyYy9wb3B1cC9wb3B1cC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLy8gQkFTRV9VUkwgaXMgaW5qZWN0ZWQgYXQgYnVpbGQgdGltZSB2aWEgZXNidWlsZCBkZWZpbmUuXG4vLyBTZXQgQkFTRV9VUkwgZW52IHZhciB0byBvdmVycmlkZSAoZGVmYXVsdDogaHR0cHM6Ly9mdGMuYmQ3My5jb20pXG5kZWNsYXJlIGNvbnN0IEJBU0VfVVJMX0lOSkVDVEVEOiBzdHJpbmc7XG5leHBvcnQgY29uc3QgQkFTRV9VUkwgPSBCQVNFX1VSTF9JTkpFQ1RFRDtcbmV4cG9ydCBjb25zdCBUT0tFTl9TVE9SQUdFX0tFWSA9IFwiZnRjX2V4dGVuc2lvbl90b2tlblwiO1xuZXhwb3J0IGNvbnN0IFRPS0VOX0VYUElSWV9LRVkgPSBcImZ0Y19leHRlbnNpb25fdG9rZW5fZXhwaXJ5XCI7XG5leHBvcnQgY29uc3QgQVVUSF9TVEFSVEVEX0tFWSA9IFwiZnRjX2F1dGhfc3RhcnRlZF9hdFwiO1xuZXhwb3J0IGNvbnN0IEFVVEhfVEFCX0lEX0tFWSA9IFwiZnRjX2F1dGhfdGFiX2lkXCI7XG5leHBvcnQgY29uc3QgUEVORElOR19TRUxFQ1RJT05fS0VZID0gXCJmdGNfcGVuZGluZ19zZWxlY3Rpb25cIjtcblxuZXhwb3J0IGNvbnN0IE1TRyA9IHtcbiAgU1RBUlRfUElDS0VSOiBcIkZUQ19TVEFSVF9QSUNLRVJcIixcbiAgQ0FOQ0VMX1BJQ0tFUjogXCJGVENfQ0FOQ0VMX1BJQ0tFUlwiLFxuICBFTEVNRU5UX1NFTEVDVEVEOiBcIkZUQ19FTEVNRU5UX1NFTEVDVEVEXCIsXG4gIEdFVF9DQU5ESURBVEVTOiBcIkZUQ19HRVRfQ0FORElEQVRFU1wiLFxuICBDQU5ESURBVEVTX1JFU1VMVDogXCJGVENfQ0FORElEQVRFU19SRVNVTFRcIixcbiAgRlRDX0VYVEVOU0lPTl9UT0tFTjogXCJGVENfRVhURU5TSU9OX1RPS0VOXCIsXG4gIEFVVEhfVEFCX09QRU5FRDogXCJGVENfQVVUSF9UQUJfT1BFTkVEXCIsXG59IGFzIGNvbnN0O1xuIiwgImltcG9ydCB7IFRPS0VOX1NUT1JBR0VfS0VZLCBUT0tFTl9FWFBJUllfS0VZIH0gZnJvbSBcIi4uL3NoYXJlZC9jb25zdGFudHNcIjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRva2VuKCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1RPS0VOX1NUT1JBR0VfS0VZLCBUT0tFTl9FWFBJUllfS0VZXSk7XG4gIGNvbnN0IHRva2VuID0gcmVzdWx0W1RPS0VOX1NUT1JBR0VfS0VZXTtcbiAgY29uc3QgZXhwaXJ5ID0gcmVzdWx0W1RPS0VOX0VYUElSWV9LRVldO1xuXG4gIGlmICghdG9rZW4gfHwgIWV4cGlyeSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgZXhwaXJ5TXMgPSBuZXcgRGF0ZShleHBpcnkpLmdldFRpbWUoKTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoZXhwaXJ5TXMpIHx8IGV4cGlyeU1zIDwgRGF0ZS5ub3coKSkge1xuICAgIGF3YWl0IGNsZWFyVG9rZW4oKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiB0b2tlbjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFRva2VuKHRva2VuOiBzdHJpbmcsIGV4cGlyZXNBdDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgW1RPS0VOX1NUT1JBR0VfS0VZXTogdG9rZW4sXG4gICAgW1RPS0VOX0VYUElSWV9LRVldOiBleHBpcmVzQXQsXG4gIH0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJUb2tlbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFtUT0tFTl9TVE9SQUdFX0tFWSwgVE9LRU5fRVhQSVJZX0tFWV0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNUb2tlblZhbGlkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIHJldHVybiB0b2tlbiAhPT0gbnVsbDtcbn1cbiIsICJleHBvcnQgZnVuY3Rpb24gZXNjYXBlQXR0cihzdHI6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzdHIucmVwbGFjZSgvJi9nLCBcIiZhbXA7XCIpLnJlcGxhY2UoL1wiL2csIFwiJnF1b3Q7XCIpLnJlcGxhY2UoLycvZywgXCImIzM5O1wiKS5yZXBsYWNlKC88L2csIFwiJmx0O1wiKS5yZXBsYWNlKC8+L2csIFwiJmd0O1wiKTtcbn1cblxuLy8gS2VlcCBpbiBzeW5jIHdpdGggc2hhcmVkL21vZGVscy9hdXRoLnRzIFRJRVJfTElNSVRTXG5jb25zdCBLTk9XTl9USUVSUyA9IFtcImZyZWVcIiwgXCJwcm9cIiwgXCJwb3dlclwiXTtcbmV4cG9ydCBmdW5jdGlvbiBzYW5pdGl6ZVRpZXIodGllcjogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIEtOT1dOX1RJRVJTLmluY2x1ZGVzKHRpZXIpID8gdGllciA6IFwiZnJlZVwiO1xufVxuIiwgImltcG9ydCB7IEJBU0VfVVJMLCBNU0csIEFVVEhfU1RBUlRFRF9LRVksIFRPS0VOX1NUT1JBR0VfS0VZLCBQRU5ESU5HX1NFTEVDVElPTl9LRVkgfSBmcm9tIFwiLi4vc2hhcmVkL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgZ2V0VG9rZW4sIGNsZWFyVG9rZW4sIGlzVG9rZW5WYWxpZCB9IGZyb20gXCIuLi9hdXRoL3Rva2VuXCI7XG5pbXBvcnQgeyBlc2NhcGVBdHRyLCBzYW5pdGl6ZVRpZXIgfSBmcm9tIFwiLi91dGlsc1wiO1xuXG5jb25zdCBUQUcgPSBcIltGVEM6cG9wdXBdXCI7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gU3RhdGVcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5pbnRlcmZhY2UgVXNlckluZm8ge1xuICB1c2VySWQ6IHN0cmluZztcbiAgdGllcjogc3RyaW5nO1xuICBlbWFpbDogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgU2VsZWN0aW9uIHtcbiAgc2VsZWN0b3I6IHN0cmluZztcbiAgY3VycmVudFZhbHVlOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xuICBwYWdlVGl0bGU6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIENhbmRpZGF0ZSB7XG4gIHNlbGVjdG9yOiBzdHJpbmc7XG4gIHRleHQ6IHN0cmluZztcbiAgc2NvcmU6IG51bWJlcjtcbn1cblxudHlwZSBQb3B1cFN0YXRlID1cbiAgfCBcInVuYXV0aGVudGljYXRlZFwiXG4gIHwgXCJjb25uZWN0aW5nXCJcbiAgfCBcImF1dGhfZmFpbGVkXCJcbiAgfCBcImF1dGhlbnRpY2F0ZWRcIlxuICB8IFwicGlja2luZ1wiXG4gIHwgXCJjb25maXJtXCJcbiAgfCBcImNyZWF0aW5nXCJcbiAgfCBcInN1Y2Nlc3NcIlxuICB8IFwiZXJyb3JcIjtcblxubGV0IHN0YXRlOiBQb3B1cFN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbmxldCB1c2VySW5mbzogVXNlckluZm8gfCBudWxsID0gbnVsbDtcbmxldCBzZWxlY3Rpb246IFNlbGVjdGlvbiB8IG51bGwgPSBudWxsO1xubGV0IGNhbmRpZGF0ZXM6IENhbmRpZGF0ZVtdID0gW107XG5sZXQgY3VycmVudFRhYlVybCA9IFwiXCI7XG5sZXQgY3VycmVudFRhYlRpdGxlID0gXCJcIjtcbmxldCBjdXJyZW50VGFiSWQgPSAwO1xubGV0IGVycm9yTWVzc2FnZSA9IFwiXCI7XG5sZXQgY3JlYXRlZE1vbml0b3JOYW1lID0gXCJcIjtcbmxldCBjcmVhdGVkTW9uaXRvclZhbHVlID0gXCJcIjtcbmxldCBkcm9wZG93bk9wZW4gPSBmYWxzZTtcblxuY29uc3QgY29udGVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29udGVudFwiKSE7XG5jb25zdCBhY2NvdW50QXJlYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWNjb3VudC1hcmVhXCIpITtcblxuLy8gSG93IGxvbmcgd2UgY29uc2lkZXIgYW4gYXV0aCBhdHRlbXB0IFwicmVjZW50XCIgXHUyMDE0IGlmIG5vIHRva2VuIHdhcyBzdG9yZWRcbi8vIHdpdGhpbiB0aGlzIHdpbmRvdywgd2Ugc2hvdyBhbiBlcnJvciBpbnN0ZWFkIG9mIHRoZSBkZWZhdWx0IGNvbm5lY3Qgc2NyZWVuLlxuLy8gTXVzdCBtYXRjaCB0aGUgU1cncyBmYWxsYmFjayB3aW5kb3cgKDEyMCBzIGluIHNlcnZpY2Utd29ya2VyLnRzIG9uVXBkYXRlZCkuXG5jb25zdCBBVVRIX1RJTUVPVVRfTVMgPSAxMjBfMDAwO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIEluaXRpYWxpc2Vcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5sZXQgaW5pdFJ1bm5pbmcgPSBmYWxzZTtcbmxldCBpbml0UGVuZGluZyA9IGZhbHNlO1xuXG5hc3luYyBmdW5jdGlvbiBpbml0KCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaW5pdFJ1bm5pbmcpIHtcbiAgICBpbml0UGVuZGluZyA9IHRydWU7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImluaXQgYWxyZWFkeSBydW5uaW5nLCBxdWV1ZWluZyByZXJ1blwiKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaW5pdFJ1bm5pbmcgPSB0cnVlO1xuICBjb25zb2xlLmxvZyhUQUcsIFwiaW5pdCBzdGFydFwiKTtcbiAgdHJ5IHtcblxuICAvLyBHZXQgY3VycmVudCB0YWIgaW5mb1xuICBjb25zdCBbdGFiXSA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICBpZiAodGFiKSB7XG4gICAgY3VycmVudFRhYlVybCA9IHRhYi51cmwgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiVGl0bGUgPSB0YWIudGl0bGUgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiSWQgPSB0YWIuaWQgfHwgMDtcbiAgfVxuXG4gIGNvbnN0IHZhbGlkID0gYXdhaXQgaXNUb2tlblZhbGlkKCk7XG4gIGlmICghdmFsaWQpIHtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwibm8gdmFsaWQgdG9rZW4gaW4gc3RvcmFnZVwiKTtcblxuICAgIC8vIENoZWNrIGlmIGFuIGF1dGggYXR0ZW1wdCB3YXMgcmVjZW50bHkgc3RhcnRlZC5cbiAgICAvLyBTaG93IFwiY29ubmVjdGluZ1wiIGZvciB0aGUgZmlyc3QgMzAgcyAoYXV0aCBtYXkgc3RpbGwgYmUgaW4gcHJvZ3Jlc3MpLFxuICAgIC8vIHRoZW4gXCJhdXRoX2ZhaWxlZFwiIHVwIHRvIEFVVEhfVElNRU9VVF9NUy5cbiAgICBjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoQVVUSF9TVEFSVEVEX0tFWSk7XG4gICAgY29uc3Qgc3RhcnRlZEF0ID0gTnVtYmVyKHN0b3JlZFtBVVRIX1NUQVJURURfS0VZXSk7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBzdGFydGVkQXQ7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShzdGFydGVkQXQpICYmIGVsYXBzZWQgPCBBVVRIX1RJTUVPVVRfTVMpIHtcbiAgICAgIGlmIChlbGFwc2VkIDwgMzBfMDAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFRBRywgXCJhdXRoIGF0dGVtcHQgaW4gcHJvZ3Jlc3MgKFwiLCBNYXRoLnJvdW5kKGVsYXBzZWQgLyAxMDAwKSwgXCJzIGFnbylcIik7XG4gICAgICAgIHN0YXRlID0gXCJjb25uZWN0aW5nXCI7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLndhcm4oVEFHLCBcInJlY2VudCBhdXRoIGF0dGVtcHQgZm91bmQgYnV0IG5vIHRva2VuIFx1MjAxNCBzaG93aW5nIGZhaWx1cmUgc3RhdGVcIik7XG4gICAgICAgIHN0YXRlID0gXCJhdXRoX2ZhaWxlZFwiO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuXG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gVmVyaWZ5IHRva2VuIHdpdGggYmFja2VuZFxuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIGlmICghdG9rZW4pIHtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwiZ2V0VG9rZW4gcmV0dXJuZWQgbnVsbCBkZXNwaXRlIGlzVG9rZW5WYWxpZFwiKTtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc29sZS5sb2coVEFHLCBcInZlcmlmeWluZyB0b2tlbiB3aXRoIGJhY2tlbmQuLi5cIik7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L2FwaS9leHRlbnNpb24vdmVyaWZ5YCwge1xuICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICAgIH0pO1xuXG4gICAgaWYgKCFyZXMub2spIHtcbiAgICAgIGNvbnNvbGUud2FybihUQUcsIFwidmVyaWZ5IHJldHVybmVkXCIsIHJlcy5zdGF0dXMpO1xuICAgICAgYXdhaXQgY2xlYXJUb2tlbigpO1xuICAgICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdXNlckluZm8gPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgIGlmICghdXNlckluZm8gfHwgdHlwZW9mIHVzZXJJbmZvLnVzZXJJZCAhPT0gXCJzdHJpbmdcIiB8fCB0eXBlb2YgdXNlckluZm8udGllciAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgY29uc29sZS53YXJuKFRBRywgXCJ2ZXJpZnkgcmVzcG9uc2UgbWFsZm9ybWVkOlwiLCB1c2VySW5mbyk7XG4gICAgICBhd2FpdCBjbGVhclRva2VuKCk7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gQ2FjaGUgdXNlckluZm8gZm9yIG9mZmxpbmUgZmFsbGJhY2tcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBjYWNoZWRVc2VySW5mbzogdXNlckluZm8gfSk7XG4gICAgLy8gQ2xlYXIgYW55IHN0YWxlIGF1dGgtc3RhcnRlZCBmbGFnXG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKEFVVEhfU1RBUlRFRF9LRVkpO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImF1dGhlbnRpY2F0ZWQgYXNcIiwgdXNlckluZm8uZW1haWwpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oVEFHLCBcInZlcmlmeSBuZXR3b3JrIGVycm9yOlwiLCBlcnIpO1xuICAgIC8vIE5ldHdvcmsgZXJyb3IgXHUyMDE0IHRyeSB0byByZXN0b3JlIGNhY2hlZCB1c2VySW5mbyBzbyB0aWVyL2FjY291bnQgZGlzcGxheSBjb3JyZWN0bHlcbiAgICBjb25zdCBjYWNoZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICBjb25zdCBjID0gY2FjaGVkLmNhY2hlZFVzZXJJbmZvO1xuICAgIGlmIChjICYmIHR5cGVvZiBjLnVzZXJJZCA9PT0gXCJzdHJpbmdcIiAmJiB0eXBlb2YgYy50aWVyID09PSBcInN0cmluZ1wiICYmIHR5cGVvZiBjLmVtYWlsID09PSBcInN0cmluZ1wiKSB7XG4gICAgICB1c2VySW5mbyA9IGM7XG4gICAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuICB9XG5cbiAgLy8gQ2hlY2sgZm9yIGEgcGVuZGluZyBlbGVtZW50IHNlbGVjdGlvbiBsZWZ0IGJ5IHRoZSBzZXJ2aWNlIHdvcmtlclxuICAvLyAodGhlIHBvcHVwIHdhcyBjbG9zZWQgd2hlbiB0aGUgdXNlciBjbGlja2VkIGFuIGVsZW1lbnQgb24gdGhlIHBhZ2UpLlxuICAvLyBEaXNjYXJkIHNlbGVjdGlvbnMgb2xkZXIgdGhhbiAxMCBtaW51dGVzIHRvIGF2b2lkIGNvbmZ1c2luZyBzdGFsZSBzdGF0ZS5cbiAgaWYgKHN0YXRlID09PSBcImF1dGhlbnRpY2F0ZWRcIikge1xuICAgIGNvbnN0IHBlbmRpbmcgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoUEVORElOR19TRUxFQ1RJT05fS0VZKTtcbiAgICBjb25zdCBzdG9yZWQgPSBwZW5kaW5nW1BFTkRJTkdfU0VMRUNUSU9OX0tFWV07XG4gICAgaWYgKHN0b3JlZCAmJiB0eXBlb2Ygc3RvcmVkLnNlbGVjdG9yID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zdCBhZ2UgPSBzdG9yZWQudGltZXN0YW1wID8gRGF0ZS5ub3coKSAtIHN0b3JlZC50aW1lc3RhbXAgOiBJbmZpbml0eTtcbiAgICAgIC8vIENsZWFyIGltbWVkaWF0ZWx5IHNvIHN0YWxlIHNlbGVjdGlvbnMgZG9uJ3QgcGVyc2lzdFxuICAgICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFBFTkRJTkdfU0VMRUNUSU9OX0tFWSk7XG4gICAgICBpZiAoYWdlIDwgNjAwXzAwMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhUQUcsIFwicGVuZGluZyBzZWxlY3Rpb24gZm91bmQgaW4gc3RvcmFnZSwganVtcGluZyB0byBjb25maXJtXCIpO1xuICAgICAgICBzZWxlY3Rpb24gPSB7XG4gICAgICAgICAgc2VsZWN0b3I6IHN0b3JlZC5zZWxlY3RvcixcbiAgICAgICAgICBjdXJyZW50VmFsdWU6IHR5cGVvZiBzdG9yZWQuY3VycmVudFZhbHVlID09PSBcInN0cmluZ1wiID8gc3RvcmVkLmN1cnJlbnRWYWx1ZSA6IFwiXCIsXG4gICAgICAgICAgdXJsOiB0eXBlb2Ygc3RvcmVkLnVybCA9PT0gXCJzdHJpbmdcIiA/IHN0b3JlZC51cmwgOiBjdXJyZW50VGFiVXJsLFxuICAgICAgICAgIHBhZ2VUaXRsZTogdHlwZW9mIHN0b3JlZC5wYWdlVGl0bGUgPT09IFwic3RyaW5nXCIgPyBzdG9yZWQucGFnZVRpdGxlIDogY3VycmVudFRhYlRpdGxlLFxuICAgICAgICB9O1xuICAgICAgICBzdGF0ZSA9IFwiY29uZmlybVwiO1xuICAgICAgICByZW5kZXIoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coVEFHLCBcInBlbmRpbmcgc2VsZWN0aW9uIHRvbyBvbGQgKFwiLCBNYXRoLnJvdW5kKGFnZSAvIDEwMDApLCBcInMpLCBkaXNjYXJkaW5nXCIpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJlbmRlcigpO1xuICB9IGZpbmFsbHkge1xuICAgIGluaXRSdW5uaW5nID0gZmFsc2U7XG4gICAgaWYgKGluaXRQZW5kaW5nKSB7XG4gICAgICBpbml0UGVuZGluZyA9IGZhbHNlO1xuICAgICAgLy8gRG9uJ3QgcmUtcnVuIGluaXQgaWYgd2UgYWxyZWFkeSByZWFjaGVkIGNvbmZpcm0gXHUyMDE0IHRoZSB1c2VyIGlzXG4gICAgICAvLyBsb29raW5nIGF0IHRoZSBjb25maXJtIHNjcmVlbiBhbmQgYSByZS1pbml0IHdvdWxkIGNsb2JiZXIgaXQuXG4gICAgICBpZiAoc3RhdGUgIT09IFwiY29uZmlybVwiKSB7XG4gICAgICAgIHZvaWQgaW5pdCgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIExpc3RlbiBmb3IgbWVzc2FnZXMgZnJvbSBiYWNrZ3JvdW5kL2NvbnRlbnRcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UpID0+IHtcbiAgaWYgKG1lc3NhZ2UudHlwZSA9PT0gTVNHLkVMRU1FTlRfU0VMRUNURUQpIHtcbiAgICBjb25zdCBzZWwgPSB0eXBlb2YgbWVzc2FnZS5zZWxlY3RvciA9PT0gXCJzdHJpbmdcIiA/IG1lc3NhZ2Uuc2VsZWN0b3IgOiBcIlwiO1xuICAgIGlmICghc2VsKSByZXR1cm47XG4gICAgc2VsZWN0aW9uID0ge1xuICAgICAgc2VsZWN0b3I6IHNlbCxcbiAgICAgIGN1cnJlbnRWYWx1ZTogdHlwZW9mIG1lc3NhZ2UuY3VycmVudFZhbHVlID09PSBcInN0cmluZ1wiID8gbWVzc2FnZS5jdXJyZW50VmFsdWUgOiBcIlwiLFxuICAgICAgdXJsOiB0eXBlb2YgbWVzc2FnZS51cmwgPT09IFwic3RyaW5nXCIgPyBtZXNzYWdlLnVybCA6IGN1cnJlbnRUYWJVcmwsXG4gICAgICBwYWdlVGl0bGU6IHR5cGVvZiBtZXNzYWdlLnBhZ2VUaXRsZSA9PT0gXCJzdHJpbmdcIiA/IG1lc3NhZ2UucGFnZVRpdGxlIDogY3VycmVudFRhYlRpdGxlLFxuICAgIH07XG4gICAgc3RhdGUgPSBcImNvbmZpcm1cIjtcbiAgICByZW5kZXIoKTtcbiAgfVxuXG4gIGlmIChtZXNzYWdlLnR5cGUgPT09IE1TRy5DQU5ESURBVEVTX1JFU1VMVCkge1xuICAgIGNhbmRpZGF0ZXMgPSBtZXNzYWdlLmNhbmRpZGF0ZXMgfHwgW107XG4gICAgaWYgKHN0YXRlID09PSBcImF1dGhlbnRpY2F0ZWRcIiB8fCBzdGF0ZSA9PT0gXCJwaWNraW5nXCIpIHtcbiAgICAgIHJlbmRlcigpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChtZXNzYWdlLnR5cGUgPT09IE1TRy5DQU5DRUxfUElDS0VSKSB7XG4gICAgaWYgKHN0YXRlID09PSBcInBpY2tpbmdcIikge1xuICAgICAgc3RhdGUgPSBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICAgIHJlbmRlcigpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChtZXNzYWdlLnR5cGUgPT09IFwiRlRDX0FVVEhfQ09NUExFVEVcIikge1xuICAgIC8vIFJlLWluaXRpYWxpc2UgYWZ0ZXIgYXV0aFxuICAgIGluaXQoKTtcbiAgfVxufSk7XG5cbi8vIEFsc28gbGlzdGVuIGZvciBkaXJlY3Qgc3RvcmFnZSB3cml0ZXMgKGUuZy4gZnJvbSBhdXRoLXJlbGF5IGNvbnRlbnQgc2NyaXB0XG4vLyB3cml0aW5nIHRoZSB0b2tlbiBkaXJlY3RseSwgYnlwYXNzaW5nIHRoZSBzZXJ2aWNlIHdvcmtlcikuXG5jaHJvbWUuc3RvcmFnZS5vbkNoYW5nZWQuYWRkTGlzdGVuZXIoKGNoYW5nZXMsIGFyZWEpID0+IHtcbiAgaWYgKGFyZWEgIT09IFwibG9jYWxcIikgcmV0dXJuO1xuICBpZiAoY2hhbmdlc1tUT0tFTl9TVE9SQUdFX0tFWV0/Lm5ld1ZhbHVlKSB7XG4gICAgY29uc29sZS5sb2coVEFHLCBcInRva2VuIGFwcGVhcmVkIGluIHN0b3JhZ2UgKGRpcmVjdCB3cml0ZSksIHJlLWluaXRpYWxpc2luZy4uLlwiKTtcbiAgICB2b2lkIGluaXQoKTtcbiAgfVxuICBpZiAoY2hhbmdlc1tQRU5ESU5HX1NFTEVDVElPTl9LRVldPy5uZXdWYWx1ZSAmJiBzdGF0ZSAhPT0gXCJjb25maXJtXCIpIHtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwicGVuZGluZyBzZWxlY3Rpb24gYXBwZWFyZWQgaW4gc3RvcmFnZSwgcmUtaW5pdGlhbGlzaW5nLi4uXCIpO1xuICAgIHZvaWQgaW5pdCgpO1xuICB9XG59KTtcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vLyBSZW5kZXJcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiByZW5kZXIoKTogdm9pZCB7XG4gIHJlbmRlckFjY291bnQoKTtcblxuICBzd2l0Y2ggKHN0YXRlKSB7XG4gICAgY2FzZSBcInVuYXV0aGVudGljYXRlZFwiOlxuICAgICAgcmVuZGVyVW5hdXRoKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiY29ubmVjdGluZ1wiOlxuICAgICAgcmVuZGVyQ29ubmVjdGluZygpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImF1dGhfZmFpbGVkXCI6XG4gICAgICByZW5kZXJBdXRoRmFpbGVkKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiYXV0aGVudGljYXRlZFwiOlxuICAgICAgcmVuZGVyQXV0aGVudGljYXRlZCgpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInBpY2tpbmdcIjpcbiAgICAgIHJlbmRlclBpY2tpbmcoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJjb25maXJtXCI6XG4gICAgICByZW5kZXJDb25maXJtKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiY3JlYXRpbmdcIjpcbiAgICAgIHJlbmRlckNyZWF0aW5nKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwic3VjY2Vzc1wiOlxuICAgICAgcmVuZGVyU3VjY2VzcygpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImVycm9yXCI6XG4gICAgICByZW5kZXJFcnJvcigpO1xuICAgICAgYnJlYWs7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyQWNjb3VudCgpOiB2b2lkIHtcbiAgaWYgKCF1c2VySW5mbykge1xuICAgIGFjY291bnRBcmVhLmlubmVySFRNTCA9IFwiXCI7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgYWNjb3VudEFyZWEuaW5uZXJIVE1MID0gYFxuICAgIDxidXR0b24gY2xhc3M9XCJhY2NvdW50LWJ0blwiIGlkPVwiYWNjb3VudC10b2dnbGVcIj5cbiAgICAgICR7ZXNjYXBlSHRtbCh1c2VySW5mby5lbWFpbCB8fCBcIkNvbm5lY3RlZFwiKX0gJiM5NjYyO1xuICAgIDwvYnV0dG9uPlxuICAgIDxkaXYgY2xhc3M9XCJhY2NvdW50LWRyb3Bkb3duICR7ZHJvcGRvd25PcGVuID8gXCJcIiA6IFwiaGlkZGVuXCJ9XCIgaWQ9XCJhY2NvdW50LWRyb3Bkb3duXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiZHJvcGRvd24tZW1haWxcIj5cbiAgICAgICAgJHtlc2NhcGVIdG1sKHVzZXJJbmZvLmVtYWlsIHx8IHVzZXJJbmZvLnVzZXJJZCl9XG4gICAgICAgIDxzcGFuIGNsYXNzPVwidGllci1iYWRnZSB0aWVyLSR7c2FuaXRpemVUaWVyKHVzZXJJbmZvLnRpZXIpfVwiPiR7ZXNjYXBlSHRtbCh1c2VySW5mby50aWVyKX08L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxhIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIGhyZWY9XCIke0JBU0VfVVJMfS9kYXNoYm9hcmRcIiB0YXJnZXQ9XCJfYmxhbmtcIj5PcGVuIGRhc2hib2FyZDwvYT5cbiAgICAgIDxkaXYgY2xhc3M9XCJkcm9wZG93bi1kaXZpZGVyXCI+PC9kaXY+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiZHJvcGRvd24taXRlbVwiIGlkPVwiZGlzY29ubmVjdC1idG5cIj5EaXNjb25uZWN0PC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhY2NvdW50LXRvZ2dsZVwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIChlKSA9PiB7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBkcm9wZG93bk9wZW4gPSAhZHJvcGRvd25PcGVuO1xuICAgIHJlbmRlckFjY291bnQoKTtcbiAgfSk7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJkaXNjb25uZWN0LWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBjbGVhclRva2VuKCk7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFwiY2FjaGVkVXNlckluZm9cIik7XG4gICAgdXNlckluZm8gPSBudWxsO1xuICAgIGRyb3Bkb3duT3BlbiA9IGZhbHNlO1xuICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG5cbiAgLy8gQ2xvc2UgZHJvcGRvd24gb24gY2xpY2sgb3V0c2lkZVxuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGlmIChkcm9wZG93bk9wZW4pIHtcbiAgICAgIGRyb3Bkb3duT3BlbiA9IGZhbHNlO1xuICAgICAgcmVuZGVyQWNjb3VudCgpO1xuICAgIH1cbiAgfSwgeyBvbmNlOiB0cnVlIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJVbmF1dGgoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJ1bmF1dGhcIj5cbiAgICAgIDxoMj5UcmFjayB3aGF0IG1hdHRlcnMgb24gYW55IHdlYnBhZ2UuPC9oMj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLWZ1bGxcIiBpZD1cImNvbm5lY3QtYnRuXCI+Q29ubmVjdCB5b3VyIGFjY291bnQ8L2J1dHRvbj5cbiAgICAgIDxwPkFscmVhZHkgaGF2ZSBhbiBhY2NvdW50PyBTaWduIGluIGFib3ZlLjwvcD5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNvbm5lY3QtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgc3RhcnRBdXRoRmxvdyk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckF1dGhGYWlsZWQoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJ1bmF1dGhcIj5cbiAgICAgIDxoMj5Db25uZWN0aW9uIGZhaWxlZDwvaDI+XG4gICAgICA8cD5XZSBjb3VsZG4ndCBjb25uZWN0IHRoZSBleHRlbnNpb24gdG8geW91ciBhY2NvdW50LiBUaGlzIGNhbiBoYXBwZW4gaWYgeW91ciBicm93c2VyIGJsb2NrZWQgdGhlIGNvbm5lY3Rpb24uPC9wPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbFwiIGlkPVwicmV0cnktY29ubmVjdC1idG5cIj5UcnkgYWdhaW48L2J1dHRvbj5cbiAgICAgIDxwIHN0eWxlPVwibWFyZ2luLXRvcDogMTJweDsgZm9udC1zaXplOiAxMnB4OyBvcGFjaXR5OiAwLjc7XCI+XG4gICAgICAgIFRpcDogd2hlbiBDaHJvbWUgYXNrcyB0byBhbGxvdyBhY2Nlc3MgdG8gZnRjLmJkNzMuY29tLCBjbGljayA8c3Ryb25nPkFsbG93PC9zdHJvbmc+LlxuICAgICAgPC9wPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicmV0cnktY29ubmVjdC1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBzdGFydEF1dGhGbG93KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3RhcnRBdXRoRmxvdygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc29sZS5sb2coVEFHLCBcInN0YXJ0aW5nIGF1dGggZmxvd1wiKTtcblxuICAvLyBDaHJvbWUgMTI3KyB0cmVhdHMgaG9zdF9wZXJtaXNzaW9ucyBhcyBvcHRpb25hbC5cbiAgLy8gUmVxdWVzdCB0aGUgcGVybWlzc2lvbiBzbyB0aGUgYXV0aC1yZWxheSBjb250ZW50IHNjcmlwdCBnZXRzIGluamVjdGVkLlxuICBsZXQgcGVybWlzc2lvbkdyYW50ZWQgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICBjb25zdCBvcmlnaW4gPSBuZXcgVVJMKEJBU0VfVVJMKS5vcmlnaW47XG4gICAgcGVybWlzc2lvbkdyYW50ZWQgPSBhd2FpdCBjaHJvbWUucGVybWlzc2lvbnMuY29udGFpbnMoeyBvcmlnaW5zOiBbYCR7b3JpZ2lufS8qYF0gfSk7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImhvc3QgcGVybWlzc2lvbiBhbHJlYWR5IGdyYW50ZWQ6XCIsIHBlcm1pc3Npb25HcmFudGVkKTtcbiAgICBpZiAoIXBlcm1pc3Npb25HcmFudGVkKSB7XG4gICAgICBwZXJtaXNzaW9uR3JhbnRlZCA9IGF3YWl0IGNocm9tZS5wZXJtaXNzaW9ucy5yZXF1ZXN0KHsgb3JpZ2luczogW2Ake29yaWdpbn0vKmBdIH0pO1xuICAgICAgY29uc29sZS5sb2coVEFHLCBcImhvc3QgcGVybWlzc2lvbiByZXF1ZXN0IHJlc3VsdDpcIiwgcGVybWlzc2lvbkdyYW50ZWQpO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS53YXJuKFRBRywgXCJwZXJtaXNzaW9uIHJlcXVlc3QgZXJyb3I6XCIsIGVycik7XG4gICAgLy8gRmFsbGJhY2sgYXV0aCBzdGlsbCB3b3JrcyB3aXRob3V0IHRoZSBwZXJtaXNzaW9uXG4gIH1cblxuICAvLyBSZWNvcmQgdGhhdCB3ZSBzdGFydGVkIGFuIGF1dGggYXR0ZW1wdCBzbyBpZiB0aGUgcG9wdXBcbiAgLy8gcmUtb3BlbnMgd2l0aG91dCBhIHRva2VuLCB3ZSBjYW4gc2hvdyBhbiBlcnJvciBpbnN0ZWFkIG9mXG4gIC8vIHRoZSBnZW5lcmljIFwiQ29ubmVjdCB5b3VyIGFjY291bnRcIiBzY3JlZW4uXG4gIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtBVVRIX1NUQVJURURfS0VZXTogRGF0ZS5ub3coKSB9KTtcblxuICBsZXQgdGFiOiBjaHJvbWUudGFicy5UYWI7XG4gIHRyeSB7XG4gICAgdGFiID0gYXdhaXQgY2hyb21lLnRhYnMuY3JlYXRlKHsgdXJsOiBgJHtCQVNFX1VSTH0vZXh0ZW5zaW9uLWF1dGhgIH0pO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKFRBRywgXCJmYWlsZWQgdG8gb3BlbiBhdXRoIHRhYjpcIiwgZXJyKTtcbiAgICBzdGF0ZSA9IFwiYXV0aF9mYWlsZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc29sZS5sb2coVEFHLCBcImF1dGggdGFiIGNyZWF0ZWQ6XCIsIHRhYi5pZCk7XG5cbiAgLy8gVGVsbCB0aGUgc2VydmljZSB3b3JrZXIgd2hpY2ggdGFiIHRvIHdhdGNoXG4gIGlmICh0YWIuaWQpIHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5BVVRIX1RBQl9PUEVORUQsIHRhYklkOiB0YWIuaWQgfSkuY2F0Y2goKGVycikgPT5cbiAgICAgIGNvbnNvbGUud2FybihUQUcsIFwiZmFpbGVkIHRvIG5vdGlmeSBzZXJ2aWNlIHdvcmtlciBvZiBhdXRoIHRhYjpcIiwgZXJyKSxcbiAgICApO1xuICB9XG5cbiAgc3RhdGUgPSBcImNvbm5lY3RpbmdcIjtcbiAgcmVuZGVyKCk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckNvbm5lY3RpbmcoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjb25uZWN0aW5nXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lclwiPjwvZGl2PlxuICAgICAgPHA+Q29ubmVjdGluZy4uLjwvcD5cbiAgICAgIDxwPldhaXRpbmcgZm9yIHlvdSB0byBzaWduIGluIGF0IEZldGNoVGhlQ2hhbmdlLjwvcD5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cImNhbmNlbC1jb25uZWN0XCIgc3R5bGU9XCJtYXJnaW4tdG9wOiAxNnB4O1wiPkNhbmNlbDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY2FuY2VsLWNvbm5lY3RcIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKEFVVEhfU1RBUlRFRF9LRVkpO1xuICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckF1dGhlbnRpY2F0ZWQoKTogdm9pZCB7XG4gIGNvbnN0IHRydW5jYXRlZFVybCA9IGN1cnJlbnRUYWJVcmwubGVuZ3RoID4gNDVcbiAgICA/IGN1cnJlbnRUYWJVcmwuc2xpY2UoMCwgNDUpICsgXCIuLi5cIlxuICAgIDogY3VycmVudFRhYlVybDtcblxuICBsZXQgY2FuZGlkYXRlc0h0bWwgPSBcIlwiO1xuICBpZiAoY2FuZGlkYXRlcy5sZW5ndGggPiAwKSB7XG4gICAgY2FuZGlkYXRlc0h0bWwgPSBgXG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvbi1oZWFkZXJcIj5TdWdnZXN0ZWQgZWxlbWVudHM8L2Rpdj5cbiAgICAgICR7Y2FuZGlkYXRlc1xuICAgICAgICAubWFwKFxuICAgICAgICAgIChjLCBpKSA9PiBgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYW5kaWRhdGVcIiBkYXRhLWlkeD1cIiR7aX1cIj5cbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImNhbmRpZGF0ZS10ZXh0XCI+JHtlc2NhcGVIdG1sKGMudGV4dCl9PC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY2FuZGlkYXRlLXNlbGVjdG9yXCI+JHtlc2NhcGVIdG1sKGMuc2VsZWN0b3IpfTwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbSBjYW5kaWRhdGUtdHJhY2tcIiBkYXRhLWlkeD1cIiR7aX1cIj5UcmFjayB0aGlzPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgYFxuICAgICAgICApXG4gICAgICAgIC5qb2luKFwiXCIpfVxuICAgIGA7XG4gIH1cblxuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY3VycmVudC11cmxcIj48c3Ryb25nPlRyYWNraW5nOjwvc3Ryb25nPiAke2VzY2FwZUh0bWwodHJ1bmNhdGVkVXJsKX08L2Rpdj5cbiAgICAke2NhbmRpZGF0ZXNIdG1sfVxuICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLWhlYWRlclwiPk9yIHBpY2sgbWFudWFsbHk8L2Rpdj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1mdWxsXCIgaWQ9XCJwaWNrLWJ0blwiPlBpY2sgYW4gZWxlbWVudCBvbiB0aGlzIHBhZ2U8L2J1dHRvbj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiYWR2YW5jZWQtdG9nZ2xlXCIgaWQ9XCJhZHZhbmNlZC10b2dnbGVcIj4mIzk2NjI7IEFkdmFuY2VkIChDU1Mgc2VsZWN0b3IpPC9idXR0b24+XG4gICAgPGRpdiBjbGFzcz1cImFkdmFuY2VkLWNvbnRlbnRcIiBpZD1cImFkdmFuY2VkLWNvbnRlbnRcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzPVwiZm9ybS1pbnB1dFwiIGlkPVwibWFudWFsLXNlbGVjdG9yXCIgcGxhY2Vob2xkZXI9XCJlLmcuIC5wcm9kdWN0LXByaWNlXCI+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cIm1hbnVhbC10cmFjay1idG5cIj5Vc2UgdGhpcyBzZWxlY3RvcjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIC8vIFBpY2sgZWxlbWVudCBidXR0b25cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwaWNrLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5TVEFSVF9QSUNLRVIsIHRhYklkOiBjdXJyZW50VGFiSWQgfSk7XG4gICAgc3RhdGUgPSBcInBpY2tpbmdcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG5cbiAgLy8gQ2FuZGlkYXRlIHRyYWNrIGJ1dHRvbnNcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5jYW5kaWRhdGUtdHJhY2tcIikuZm9yRWFjaCgoYnRuKSA9PiB7XG4gICAgYnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZSkgPT4ge1xuICAgICAgY29uc3QgaWR4ID0gcGFyc2VJbnQoKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS5kYXRhc2V0LmlkeCB8fCBcIjBcIik7XG4gICAgICBjb25zdCBjID0gY2FuZGlkYXRlc1tpZHhdO1xuICAgICAgaWYgKGMpIHtcbiAgICAgICAgc2VsZWN0aW9uID0ge1xuICAgICAgICAgIHNlbGVjdG9yOiBjLnNlbGVjdG9yLFxuICAgICAgICAgIGN1cnJlbnRWYWx1ZTogYy50ZXh0LFxuICAgICAgICAgIHVybDogY3VycmVudFRhYlVybCxcbiAgICAgICAgICBwYWdlVGl0bGU6IGN1cnJlbnRUYWJUaXRsZSxcbiAgICAgICAgfTtcbiAgICAgICAgc3RhdGUgPSBcImNvbmZpcm1cIjtcbiAgICAgICAgcmVuZGVyKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0pO1xuXG4gIC8vIEFkdmFuY2VkIHRvZ2dsZVxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImFkdmFuY2VkLXRvZ2dsZVwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWR2YW5jZWQtY29udGVudFwiKTtcbiAgICBlbD8uY2xhc3NMaXN0LnRvZ2dsZShcIm9wZW5cIik7XG4gIH0pO1xuXG4gIC8vIE1hbnVhbCBzZWxlY3RvclxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1hbnVhbC10cmFjay1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgY29uc3QgaW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1hbnVhbC1zZWxlY3RvclwiKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgIGNvbnN0IHNlbGVjdG9yID0gaW5wdXQ/LnZhbHVlLnRyaW0oKTtcbiAgICBpZiAoc2VsZWN0b3IpIHtcbiAgICAgIHNlbGVjdGlvbiA9IHtcbiAgICAgICAgc2VsZWN0b3IsXG4gICAgICAgIGN1cnJlbnRWYWx1ZTogXCJcIixcbiAgICAgICAgdXJsOiBjdXJyZW50VGFiVXJsLFxuICAgICAgICBwYWdlVGl0bGU6IFwiXCIsXG4gICAgICB9O1xuICAgICAgc3RhdGUgPSBcImNvbmZpcm1cIjtcbiAgICAgIHJlbmRlcigpO1xuICAgIH1cbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclBpY2tpbmcoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJwaWNrZXItaW5mb1wiPlxuICAgICAgPGRpdiBjbGFzcz1cImljb25cIj4mIzEyNzkxOTs8L2Rpdj5cbiAgICAgIDxwPjxzdHJvbmc+Q2xpY2sgYW55IGVsZW1lbnQgb24gdGhlIHBhZ2UgdG8gdHJhY2sgaXQuPC9zdHJvbmc+PC9wPlxuICAgICAgPHA+UHJlc3MgRXNjIHRvIGNhbmNlbC48L3A+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnkgYnRuLXNtXCIgaWQ9XCJjYW5jZWwtcGlja1wiIHN0eWxlPVwibWFyZ2luLXRvcDogMTZweDtcIj5DYW5jZWwgcGlja2luZzwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY2FuY2VsLXBpY2tcIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiBNU0cuQ0FOQ0VMX1BJQ0tFUiwgdGFiSWQ6IGN1cnJlbnRUYWJJZCB9KTtcbiAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQ29uZmlybSgpOiB2b2lkIHtcbiAgaWYgKCFzZWxlY3Rpb24pIHJldHVybjtcblxuICBjb25zdCB0aWVyID0gdXNlckluZm8/LnRpZXIgfHwgXCJmcmVlXCI7XG4gIGNvbnN0IGhvdXJseURpc2FibGVkID0gdGllciA9PT0gXCJmcmVlXCI7XG4gIGNvbnN0IGRlZmF1bHROYW1lID0gKHNlbGVjdGlvbi5wYWdlVGl0bGUgfHwgXCJcIikuc2xpY2UoMCwgMTAwKTtcblxuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY3VycmVudC11cmxcIj48c3Ryb25nPlRyYWNraW5nOjwvc3Ryb25nPiAke2VzY2FwZUh0bWwoXG4gICAgICBzZWxlY3Rpb24udXJsLmxlbmd0aCA+IDQ1ID8gc2VsZWN0aW9uLnVybC5zbGljZSgwLCA0NSkgKyBcIi4uLlwiIDogc2VsZWN0aW9uLnVybFxuICAgICl9PC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImNvbmZpcm0tY2FyZFwiPlxuICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+RWxlbWVudCBzZWxlY3RlZDwvZGl2PlxuICAgICAgJHtcbiAgICAgICAgc2VsZWN0aW9uLmN1cnJlbnRWYWx1ZVxuICAgICAgICAgID8gYDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPkN1cnJlbnRseTogJHtlc2NhcGVIdG1sKHNlbGVjdGlvbi5jdXJyZW50VmFsdWUuc2xpY2UoMCwgMTAwKSl9PC9kaXY+YFxuICAgICAgICAgIDogXCJcIlxuICAgICAgfVxuICAgICAgPGRpdiBjbGFzcz1cInNlbGVjdG9yXCI+JHtlc2NhcGVIdG1sKHNlbGVjdGlvbi5zZWxlY3Rvcil9PC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tbGFiZWxcIj5Nb25pdG9yIG5hbWU8L2xhYmVsPlxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3M9XCJmb3JtLWlucHV0XCIgaWQ9XCJtb25pdG9yLW5hbWVcIiB2YWx1ZT1cIiR7ZXNjYXBlQXR0cihkZWZhdWx0TmFtZSl9XCIgbWF4bGVuZ3RoPVwiMTAwXCI+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tbGFiZWxcIj5DaGVjayBmcmVxdWVuY3k8L2xhYmVsPlxuICAgICAgPGRpdiBjbGFzcz1cInJhZGlvLWdyb3VwXCI+XG4gICAgICAgIDxsYWJlbCBjbGFzcz1cInJhZGlvLWxhYmVsXCI+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJyYWRpb1wiIG5hbWU9XCJmcmVxdWVuY3lcIiB2YWx1ZT1cImRhaWx5XCIgY2hlY2tlZD4gRGFpbHlcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPGxhYmVsIGNsYXNzPVwicmFkaW8tbGFiZWwgJHtob3VybHlEaXNhYmxlZCA/IFwiZGlzYWJsZWRcIiA6IFwiXCJ9XCI+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJyYWRpb1wiIG5hbWU9XCJmcmVxdWVuY3lcIiB2YWx1ZT1cImhvdXJseVwiICR7aG91cmx5RGlzYWJsZWQgPyBcImRpc2FibGVkXCIgOiBcIlwifT5cbiAgICAgICAgICBIb3VybHlcbiAgICAgICAgICAke2hvdXJseURpc2FibGVkID8gJzxzcGFuIGNsYXNzPVwidG9vbHRpcC10ZXh0XCI+KFBybyspPC9zcGFuPicgOiBcIlwifVxuICAgICAgICA8L2xhYmVsPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImJ0bi1yb3dcIj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeVwiIGlkPVwicGljay1hZ2Fpbi1idG5cIlxuICAgICAgICAke3NlbGVjdGlvbi51cmwgJiYgc2VsZWN0aW9uLnVybCAhPT0gY3VycmVudFRhYlVybCA/IFwiZGlzYWJsZWQgdGl0bGU9XFxcIlN3aXRjaCB0byB0aGUgb3JpZ2luYWwgdGFiIHRvIHBpY2sgYWdhaW5cXFwiXCIgOiBcIlwifT5QaWNrIGFnYWluPC9idXR0b24+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5XCIgaWQ9XCJjcmVhdGUtYnRuXCI+Q3JlYXRlIG1vbml0b3I8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBpY2stYWdhaW4tYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHNlbGVjdGlvbiA9IG51bGw7XG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiBNU0cuU1RBUlRfUElDS0VSLCB0YWJJZDogY3VycmVudFRhYklkIH0pO1xuICAgIHN0YXRlID0gXCJwaWNraW5nXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY3JlYXRlLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGNyZWF0ZU1vbml0b3IpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjcmVhdGVNb25pdG9yKCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoIXNlbGVjdGlvbiB8fCBzdGF0ZSA9PT0gXCJjcmVhdGluZ1wiKSByZXR1cm47XG5cbiAgY29uc3QgbmFtZUlucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtb25pdG9yLW5hbWVcIikgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgY29uc3QgbmFtZSA9IG5hbWVJbnB1dD8udmFsdWUudHJpbSgpIHx8IFwiVW50aXRsZWQgbW9uaXRvclwiO1xuICBjb25zdCBmcmVxdWVuY3kgPVxuICAgIChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdpbnB1dFtuYW1lPVwiZnJlcXVlbmN5XCJdOmNoZWNrZWQnKSBhcyBIVE1MSW5wdXRFbGVtZW50KT8udmFsdWUgfHwgXCJkYWlseVwiO1xuXG4gIHN0YXRlID0gXCJjcmVhdGluZ1wiO1xuICBjcmVhdGVkTW9uaXRvck5hbWUgPSBuYW1lO1xuICBjcmVhdGVkTW9uaXRvclZhbHVlID0gc2VsZWN0aW9uLmN1cnJlbnRWYWx1ZTtcbiAgcmVuZGVyKCk7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gICAgaWYgKCF0b2tlbikge1xuICAgICAgZXJyb3JNZXNzYWdlID0gXCJOb3QgYXV0aGVudGljYXRlZC4gUGxlYXNlIHJlY29ubmVjdC5cIjtcbiAgICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L2FwaS9leHRlbnNpb24vbW9uaXRvcnNgLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBuYW1lLFxuICAgICAgICB1cmw6IHNlbGVjdGlvbi51cmwsXG4gICAgICAgIHNlbGVjdG9yOiBzZWxlY3Rpb24uc2VsZWN0b3IsXG4gICAgICAgIGZyZXF1ZW5jeSxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgaWYgKHJlcy5vaykge1xuICAgICAgc3RhdGUgPSBcInN1Y2Nlc3NcIjtcbiAgICAgIHJlbmRlcigpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuXG4gICAgaWYgKGRhdGE/LmNvZGUgPT09IFwiVElFUl9MSU1JVF9SRUFDSEVEXCIpIHtcbiAgICAgIGVycm9yTWVzc2FnZSA9IGAke2RhdGEubWVzc2FnZSB8fCBkYXRhLmVycm9yIHx8IFwiTW9uaXRvciBsaW1pdCByZWFjaGVkLlwifWA7XG4gICAgICBzdGF0ZSA9IFwiZXJyb3JcIjtcbiAgICAgIHJlbmRlcigpO1xuICAgICAgLy8gQWRkIHVwZ3JhZGUgbGluayBhZnRlciByZW5kZXIgdXNpbmcgRE9NIEFQSVxuICAgICAgY29uc3QgZXJyQ29udGFpbmVyID0gY29udGVudC5xdWVyeVNlbGVjdG9yKFwiLmVycm9yIHBcIik7XG4gICAgICBpZiAoZXJyQ29udGFpbmVyKSB7XG4gICAgICAgIGVyckNvbnRhaW5lci5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnJcIikpO1xuICAgICAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImFcIik7XG4gICAgICAgIGxpbmsuaHJlZiA9IGAke0JBU0VfVVJMfS9wcmljaW5nYDtcbiAgICAgICAgbGluay50YXJnZXQgPSBcIl9ibGFua1wiO1xuICAgICAgICBsaW5rLnN0eWxlLmNvbG9yID0gXCIjNjM2NmYxXCI7XG4gICAgICAgIGxpbmsudGV4dENvbnRlbnQgPSBcIlVwZ3JhZGUgeW91ciBwbGFuXCI7XG4gICAgICAgIGVyckNvbnRhaW5lci5hcHBlbmRDaGlsZChsaW5rKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBlcnJvck1lc3NhZ2UgPSBkYXRhPy5tZXNzYWdlIHx8IGRhdGE/LmVycm9yIHx8IGBGYWlsZWQgKCR7cmVzLnN0YXR1c30pYDtcbiAgICBzdGF0ZSA9IFwiZXJyb3JcIjtcbiAgICByZW5kZXIoKTtcbiAgfSBjYXRjaCB7XG4gICAgZXJyb3JNZXNzYWdlID0gXCJOZXR3b3JrIGVycm9yLiBQbGVhc2UgdHJ5IGFnYWluLlwiO1xuICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgIHJlbmRlcigpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlckNyZWF0aW5nKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY29ubmVjdGluZ1wiIHN0eWxlPVwicGFkZGluZy10b3A6IDY0cHg7XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lclwiPjwvZGl2PlxuICAgICAgPHA+Q3JlYXRpbmcgbW9uaXRvci4uLjwvcD5cbiAgICA8L2Rpdj5cbiAgYDtcbn1cblxuZnVuY3Rpb24gcmVuZGVyU3VjY2VzcygpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInN1Y2Nlc3NcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJpY29uXCI+JiMxMDAwMzs8L2Rpdj5cbiAgICAgIDxoMz5Nb25pdG9yIGNyZWF0ZWQhPC9oMz5cbiAgICAgIDxwPjxzdHJvbmc+JHtlc2NhcGVIdG1sKGNyZWF0ZWRNb25pdG9yTmFtZSl9PC9zdHJvbmc+IGlzIG5vdyBiZWluZyB3YXRjaGVkLjwvcD5cbiAgICAgICR7Y3JlYXRlZE1vbml0b3JWYWx1ZSA/IGA8cD5Zb3UnbGwgYmUgbm90aWZpZWQgd2hlbiA8c3Ryb25nPiR7ZXNjYXBlSHRtbChjcmVhdGVkTW9uaXRvclZhbHVlLnNsaWNlKDAsIDYwKSl9PC9zdHJvbmc+IGNoYW5nZXMuPC9wPmAgOiBcIlwifVxuICAgICAgPGRpdiBjbGFzcz1cImJ0bi1yb3dcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDI0cHg7IGp1c3RpZnktY29udGVudDogY2VudGVyO1wiPlxuICAgICAgICA8YSBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tc21cIiBocmVmPVwiJHtCQVNFX1VSTH0vZGFzaGJvYXJkXCIgdGFyZ2V0PVwiX2JsYW5rXCI+VmlldyBpbiBkYXNoYm9hcmQ8L2E+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cInRyYWNrLWFub3RoZXItYnRuXCI+VHJhY2sgYW5vdGhlcjwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0cmFjay1hbm90aGVyLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBzZWxlY3Rpb24gPSBudWxsO1xuICAgIGNhbmRpZGF0ZXMgPSBbXTtcbiAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyRXJyb3IoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJlcnJvclwiPlxuICAgICAgPGRpdiBjbGFzcz1cImljb25cIj4mIzEwMDA3OzwvZGl2PlxuICAgICAgPGgzPkNvdWxkbid0IGNyZWF0ZSBtb25pdG9yPC9oMz5cbiAgICAgIDxwPiR7ZXNjYXBlSHRtbChlcnJvck1lc3NhZ2UpfTwvcD5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeVwiIGlkPVwidHJ5LWFnYWluLWJ0blwiPlRyeSBhZ2FpbjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidHJ5LWFnYWluLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBzdGF0ZSA9IHNlbGVjdGlvbiA/IFwiY29uZmlybVwiIDogXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIEhlbHBlcnNcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBlc2NhcGVIdG1sKHN0cjogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgZGl2LnRleHRDb250ZW50ID0gc3RyO1xuICByZXR1cm4gZGl2LmlubmVySFRNTDtcbn1cblxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIFN0YXJ0XG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuaW5pdCgpO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBR08sTUFBTSxXQUFXO0FBQ2pCLE1BQU0sb0JBQW9CO0FBQzFCLE1BQU0sbUJBQW1CO0FBQ3pCLE1BQU0sbUJBQW1CO0FBRXpCLE1BQU0sd0JBQXdCO0FBRTlCLE1BQU0sTUFBTTtBQUFBLElBQ2pCLGNBQWM7QUFBQSxJQUNkLGVBQWU7QUFBQSxJQUNmLGtCQUFrQjtBQUFBLElBQ2xCLGdCQUFnQjtBQUFBLElBQ2hCLG1CQUFtQjtBQUFBLElBQ25CLHFCQUFxQjtBQUFBLElBQ3JCLGlCQUFpQjtBQUFBLEVBQ25COzs7QUNoQkEsaUJBQXNCLFdBQW1DO0FBQ3ZELFVBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxtQkFBbUIsZ0JBQWdCLENBQUM7QUFDbkYsVUFBTSxRQUFRLE9BQU8saUJBQWlCO0FBQ3RDLFVBQU0sU0FBUyxPQUFPLGdCQUFnQjtBQUV0QyxRQUFJLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUU5QixVQUFNLFdBQVcsSUFBSSxLQUFLLE1BQU0sRUFBRSxRQUFRO0FBQzFDLFFBQUksQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLFdBQVcsS0FBSyxJQUFJLEdBQUc7QUFDdkQsWUFBTSxXQUFXO0FBQ2pCLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFTQSxpQkFBc0IsYUFBNEI7QUFDaEQsVUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLENBQUMsbUJBQW1CLGdCQUFnQixDQUFDO0FBQUEsRUFDekU7QUFFQSxpQkFBc0IsZUFBaUM7QUFDckQsVUFBTSxRQUFRLE1BQU0sU0FBUztBQUM3QixXQUFPLFVBQVU7QUFBQSxFQUNuQjs7O0FDaENPLFdBQVMsV0FBVyxLQUFxQjtBQUM5QyxXQUFPLElBQUksUUFBUSxNQUFNLE9BQU8sRUFBRSxRQUFRLE1BQU0sUUFBUSxFQUFFLFFBQVEsTUFBTSxPQUFPLEVBQUUsUUFBUSxNQUFNLE1BQU0sRUFBRSxRQUFRLE1BQU0sTUFBTTtBQUFBLEVBQzdIO0FBR0EsTUFBTSxjQUFjLENBQUMsUUFBUSxPQUFPLE9BQU87QUFDcEMsV0FBUyxhQUFhLE1BQXNCO0FBQ2pELFdBQU8sWUFBWSxTQUFTLElBQUksSUFBSSxPQUFPO0FBQUEsRUFDN0M7OztBQ0pBLE1BQU0sTUFBTTtBQW9DWixNQUFJLFFBQW9CO0FBQ3hCLE1BQUksV0FBNEI7QUFDaEMsTUFBSSxZQUE4QjtBQUNsQyxNQUFJLGFBQTBCLENBQUM7QUFDL0IsTUFBSSxnQkFBZ0I7QUFDcEIsTUFBSSxrQkFBa0I7QUFDdEIsTUFBSSxlQUFlO0FBQ25CLE1BQUksZUFBZTtBQUNuQixNQUFJLHFCQUFxQjtBQUN6QixNQUFJLHNCQUFzQjtBQUMxQixNQUFJLGVBQWU7QUFFbkIsTUFBTSxVQUFVLFNBQVMsZUFBZSxTQUFTO0FBQ2pELE1BQU0sY0FBYyxTQUFTLGVBQWUsY0FBYztBQUsxRCxNQUFNLGtCQUFrQjtBQU14QixNQUFJLGNBQWM7QUFDbEIsTUFBSSxjQUFjO0FBRWxCLGlCQUFlLE9BQXNCO0FBQ25DLFFBQUksYUFBYTtBQUNmLG9CQUFjO0FBQ2QsY0FBUSxJQUFJLEtBQUssc0NBQXNDO0FBQ3ZEO0FBQUEsSUFDRjtBQUNBLGtCQUFjO0FBQ2QsWUFBUSxJQUFJLEtBQUssWUFBWTtBQUM3QixRQUFJO0FBR0osWUFBTSxDQUFDLEdBQUcsSUFBSSxNQUFNLE9BQU8sS0FBSyxNQUFNLEVBQUUsUUFBUSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQzNFLFVBQUksS0FBSztBQUNQLHdCQUFnQixJQUFJLE9BQU87QUFDM0IsMEJBQWtCLElBQUksU0FBUztBQUMvQix1QkFBZSxJQUFJLE1BQU07QUFBQSxNQUMzQjtBQUVBLFlBQU0sUUFBUSxNQUFNLGFBQWE7QUFDakMsVUFBSSxDQUFDLE9BQU87QUFDVixnQkFBUSxJQUFJLEtBQUssMkJBQTJCO0FBSzVDLGNBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksZ0JBQWdCO0FBQzlELGNBQU0sWUFBWSxPQUFPLE9BQU8sZ0JBQWdCLENBQUM7QUFDakQsY0FBTSxVQUFVLEtBQUssSUFBSSxJQUFJO0FBQzdCLFlBQUksT0FBTyxTQUFTLFNBQVMsS0FBSyxVQUFVLGlCQUFpQjtBQUMzRCxjQUFJLFVBQVUsS0FBUTtBQUNwQixvQkFBUSxJQUFJLEtBQUssOEJBQThCLEtBQUssTUFBTSxVQUFVLEdBQUksR0FBRyxRQUFRO0FBQ25GLG9CQUFRO0FBQUEsVUFDVixPQUFPO0FBQ0wsb0JBQVEsS0FBSyxLQUFLLHFFQUFnRTtBQUNsRixvQkFBUTtBQUFBLFVBQ1Y7QUFBQSxRQUNGLE9BQU87QUFDTCxrQkFBUTtBQUFBLFFBQ1Y7QUFFQSxlQUFPO0FBQ1A7QUFBQSxNQUNGO0FBR0EsWUFBTSxRQUFRLE1BQU0sU0FBUztBQUM3QixVQUFJLENBQUMsT0FBTztBQUNWLGdCQUFRLElBQUksS0FBSyw2Q0FBNkM7QUFDOUQsZ0JBQVE7QUFDUixlQUFPO0FBQ1A7QUFBQSxNQUNGO0FBRUEsY0FBUSxJQUFJLEtBQUssaUNBQWlDO0FBQ2xELFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsUUFBUSx5QkFBeUI7QUFBQSxVQUMxRCxTQUFTLEVBQUUsZUFBZSxVQUFVLEtBQUssR0FBRztBQUFBLFFBQzlDLENBQUM7QUFFRCxZQUFJLENBQUMsSUFBSSxJQUFJO0FBQ1gsa0JBQVEsS0FBSyxLQUFLLG1CQUFtQixJQUFJLE1BQU07QUFDL0MsZ0JBQU0sV0FBVztBQUNqQixrQkFBUTtBQUNSLGlCQUFPO0FBQ1A7QUFBQSxRQUNGO0FBRUEsbUJBQVcsTUFBTSxJQUFJLEtBQUssRUFBRSxNQUFNLE1BQU0sSUFBSTtBQUM1QyxZQUFJLENBQUMsWUFBWSxPQUFPLFNBQVMsV0FBVyxZQUFZLE9BQU8sU0FBUyxTQUFTLFVBQVU7QUFDekYsa0JBQVEsS0FBSyxLQUFLLDhCQUE4QixRQUFRO0FBQ3hELGdCQUFNLFdBQVc7QUFDakIsa0JBQVE7QUFDUixpQkFBTztBQUNQO0FBQUEsUUFDRjtBQUVBLGNBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLGdCQUFnQixTQUFTLENBQUM7QUFFM0QsY0FBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLGdCQUFnQjtBQUNsRCxnQkFBUTtBQUNSLGdCQUFRLElBQUksS0FBSyxvQkFBb0IsU0FBUyxLQUFLO0FBQUEsTUFDckQsU0FBUyxLQUFLO0FBQ1osZ0JBQVEsS0FBSyxLQUFLLHlCQUF5QixHQUFHO0FBRTlDLGNBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksZ0JBQWdCO0FBQzlELGNBQU0sSUFBSSxPQUFPO0FBQ2pCLFlBQUksS0FBSyxPQUFPLEVBQUUsV0FBVyxZQUFZLE9BQU8sRUFBRSxTQUFTLFlBQVksT0FBTyxFQUFFLFVBQVUsVUFBVTtBQUNsRyxxQkFBVztBQUNYLGtCQUFRO0FBQUEsUUFDVixPQUFPO0FBQ0wsa0JBQVE7QUFBQSxRQUNWO0FBQUEsTUFDRjtBQUtBLFVBQUksVUFBVSxpQkFBaUI7QUFDN0IsY0FBTSxVQUFVLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxxQkFBcUI7QUFDcEUsY0FBTSxTQUFTLFFBQVEscUJBQXFCO0FBQzVDLFlBQUksVUFBVSxPQUFPLE9BQU8sYUFBYSxVQUFVO0FBQ2pELGdCQUFNLE1BQU0sT0FBTyxZQUFZLEtBQUssSUFBSSxJQUFJLE9BQU8sWUFBWTtBQUUvRCxnQkFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLHFCQUFxQjtBQUN2RCxjQUFJLE1BQU0sS0FBUztBQUNqQixvQkFBUSxJQUFJLEtBQUssd0RBQXdEO0FBQ3pFLHdCQUFZO0FBQUEsY0FDVixVQUFVLE9BQU87QUFBQSxjQUNqQixjQUFjLE9BQU8sT0FBTyxpQkFBaUIsV0FBVyxPQUFPLGVBQWU7QUFBQSxjQUM5RSxLQUFLLE9BQU8sT0FBTyxRQUFRLFdBQVcsT0FBTyxNQUFNO0FBQUEsY0FDbkQsV0FBVyxPQUFPLE9BQU8sY0FBYyxXQUFXLE9BQU8sWUFBWTtBQUFBLFlBQ3ZFO0FBQ0Esb0JBQVE7QUFDUixtQkFBTztBQUNQO0FBQUEsVUFDRixPQUFPO0FBQ0wsb0JBQVEsSUFBSSxLQUFLLCtCQUErQixLQUFLLE1BQU0sTUFBTSxHQUFJLEdBQUcsZ0JBQWdCO0FBQUEsVUFDMUY7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNQLFVBQUU7QUFDQSxvQkFBYztBQUNkLFVBQUksYUFBYTtBQUNmLHNCQUFjO0FBR2QsWUFBSSxVQUFVLFdBQVc7QUFDdkIsZUFBSyxLQUFLO0FBQUEsUUFDWjtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQU1BLFNBQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxZQUFZO0FBQ2hELFFBQUksUUFBUSxTQUFTLElBQUksa0JBQWtCO0FBQ3pDLFlBQU0sTUFBTSxPQUFPLFFBQVEsYUFBYSxXQUFXLFFBQVEsV0FBVztBQUN0RSxVQUFJLENBQUMsSUFBSztBQUNWLGtCQUFZO0FBQUEsUUFDVixVQUFVO0FBQUEsUUFDVixjQUFjLE9BQU8sUUFBUSxpQkFBaUIsV0FBVyxRQUFRLGVBQWU7QUFBQSxRQUNoRixLQUFLLE9BQU8sUUFBUSxRQUFRLFdBQVcsUUFBUSxNQUFNO0FBQUEsUUFDckQsV0FBVyxPQUFPLFFBQVEsY0FBYyxXQUFXLFFBQVEsWUFBWTtBQUFBLE1BQ3pFO0FBQ0EsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBSSxRQUFRLFNBQVMsSUFBSSxtQkFBbUI7QUFDMUMsbUJBQWEsUUFBUSxjQUFjLENBQUM7QUFDcEMsVUFBSSxVQUFVLG1CQUFtQixVQUFVLFdBQVc7QUFDcEQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsUUFBSSxRQUFRLFNBQVMsSUFBSSxlQUFlO0FBQ3RDLFVBQUksVUFBVSxXQUFXO0FBQ3ZCLGdCQUFRO0FBQ1IsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsUUFBSSxRQUFRLFNBQVMscUJBQXFCO0FBRXhDLFdBQUs7QUFBQSxJQUNQO0FBQUEsRUFDRixDQUFDO0FBSUQsU0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLFNBQVMsU0FBUztBQUN0RCxRQUFJLFNBQVMsUUFBUztBQUN0QixRQUFJLFFBQVEsaUJBQWlCLEdBQUcsVUFBVTtBQUN4QyxjQUFRLElBQUksS0FBSyw4REFBOEQ7QUFDL0UsV0FBSyxLQUFLO0FBQUEsSUFDWjtBQUNBLFFBQUksUUFBUSxxQkFBcUIsR0FBRyxZQUFZLFVBQVUsV0FBVztBQUNuRSxjQUFRLElBQUksS0FBSywyREFBMkQ7QUFDNUUsV0FBSyxLQUFLO0FBQUEsSUFDWjtBQUFBLEVBQ0YsQ0FBQztBQU1ELFdBQVMsU0FBZTtBQUN0QixrQkFBYztBQUVkLFlBQVEsT0FBTztBQUFBLE1BQ2IsS0FBSztBQUNILHFCQUFhO0FBQ2I7QUFBQSxNQUNGLEtBQUs7QUFDSCx5QkFBaUI7QUFDakI7QUFBQSxNQUNGLEtBQUs7QUFDSCx5QkFBaUI7QUFDakI7QUFBQSxNQUNGLEtBQUs7QUFDSCw0QkFBb0I7QUFDcEI7QUFBQSxNQUNGLEtBQUs7QUFDSCxzQkFBYztBQUNkO0FBQUEsTUFDRixLQUFLO0FBQ0gsc0JBQWM7QUFDZDtBQUFBLE1BQ0YsS0FBSztBQUNILHVCQUFlO0FBQ2Y7QUFBQSxNQUNGLEtBQUs7QUFDSCxzQkFBYztBQUNkO0FBQUEsTUFDRixLQUFLO0FBQ0gsb0JBQVk7QUFDWjtBQUFBLElBQ0o7QUFBQSxFQUNGO0FBRUEsV0FBUyxnQkFBc0I7QUFDN0IsUUFBSSxDQUFDLFVBQVU7QUFDYixrQkFBWSxZQUFZO0FBQ3hCO0FBQUEsSUFDRjtBQUVBLGdCQUFZLFlBQVk7QUFBQTtBQUFBLFFBRWxCLFdBQVcsU0FBUyxTQUFTLFdBQVcsQ0FBQztBQUFBO0FBQUEsbUNBRWQsZUFBZSxLQUFLLFFBQVE7QUFBQTtBQUFBLFVBRXJELFdBQVcsU0FBUyxTQUFTLFNBQVMsTUFBTSxDQUFDO0FBQUEsdUNBQ2hCLGFBQWEsU0FBUyxJQUFJLENBQUMsS0FBSyxXQUFXLFNBQVMsSUFBSSxDQUFDO0FBQUE7QUFBQSx1Q0FFekQsUUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTTdDLGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDMUUsUUFBRSxnQkFBZ0I7QUFDbEIscUJBQWUsQ0FBQztBQUNoQixvQkFBYztBQUFBLElBQ2hCLENBQUM7QUFFRCxhQUFTLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLFNBQVMsWUFBWTtBQUMvRSxZQUFNLFdBQVc7QUFDakIsWUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLGdCQUFnQjtBQUNsRCxpQkFBVztBQUNYLHFCQUFlO0FBQ2YsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFHRCxhQUFTLGlCQUFpQixTQUFTLE1BQU07QUFDdkMsVUFBSSxjQUFjO0FBQ2hCLHVCQUFlO0FBQ2Ysc0JBQWM7QUFBQSxNQUNoQjtBQUFBLElBQ0YsR0FBRyxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQUEsRUFDbkI7QUFFQSxXQUFTLGVBQXFCO0FBQzVCLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVFwQixhQUFTLGVBQWUsYUFBYSxHQUFHLGlCQUFpQixTQUFTLGFBQWE7QUFBQSxFQUNqRjtBQUVBLFdBQVMsbUJBQXlCO0FBQ2hDLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVdwQixhQUFTLGVBQWUsbUJBQW1CLEdBQUcsaUJBQWlCLFNBQVMsYUFBYTtBQUFBLEVBQ3ZGO0FBRUEsaUJBQWUsZ0JBQStCO0FBQzVDLFlBQVEsSUFBSSxLQUFLLG9CQUFvQjtBQUlyQyxRQUFJLG9CQUFvQjtBQUN4QixRQUFJO0FBQ0YsWUFBTSxTQUFTLElBQUksSUFBSSxRQUFRLEVBQUU7QUFDakMsMEJBQW9CLE1BQU0sT0FBTyxZQUFZLFNBQVMsRUFBRSxTQUFTLENBQUMsR0FBRyxNQUFNLElBQUksRUFBRSxDQUFDO0FBQ2xGLGNBQVEsSUFBSSxLQUFLLG9DQUFvQyxpQkFBaUI7QUFDdEUsVUFBSSxDQUFDLG1CQUFtQjtBQUN0Qiw0QkFBb0IsTUFBTSxPQUFPLFlBQVksUUFBUSxFQUFFLFNBQVMsQ0FBQyxHQUFHLE1BQU0sSUFBSSxFQUFFLENBQUM7QUFDakYsZ0JBQVEsSUFBSSxLQUFLLG1DQUFtQyxpQkFBaUI7QUFBQSxNQUN2RTtBQUFBLElBQ0YsU0FBUyxLQUFLO0FBQ1osY0FBUSxLQUFLLEtBQUssNkJBQTZCLEdBQUc7QUFBQSxJQUVwRDtBQUtBLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxJQUFJLEVBQUUsQ0FBQztBQUVqRSxRQUFJO0FBQ0osUUFBSTtBQUNGLFlBQU0sTUFBTSxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssR0FBRyxRQUFRLGtCQUFrQixDQUFDO0FBQUEsSUFDdEUsU0FBUyxLQUFLO0FBQ1osY0FBUSxNQUFNLEtBQUssNEJBQTRCLEdBQUc7QUFDbEQsY0FBUTtBQUNSLGFBQU87QUFDUDtBQUFBLElBQ0Y7QUFDQSxZQUFRLElBQUksS0FBSyxxQkFBcUIsSUFBSSxFQUFFO0FBRzVDLFFBQUksSUFBSSxJQUFJO0FBQ1YsYUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLElBQUksaUJBQWlCLE9BQU8sSUFBSSxHQUFHLENBQUMsRUFBRTtBQUFBLFFBQU0sQ0FBQyxRQUM5RSxRQUFRLEtBQUssS0FBSyxnREFBZ0QsR0FBRztBQUFBLE1BQ3ZFO0FBQUEsSUFDRjtBQUVBLFlBQVE7QUFDUixXQUFPO0FBQUEsRUFDVDtBQUVBLFdBQVMsbUJBQXlCO0FBQ2hDLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBU3BCLGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9FLFlBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxnQkFBZ0I7QUFDbEQsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBUyxzQkFBNEI7QUFDbkMsVUFBTSxlQUFlLGNBQWMsU0FBUyxLQUN4QyxjQUFjLE1BQU0sR0FBRyxFQUFFLElBQUksUUFDN0I7QUFFSixRQUFJLGlCQUFpQjtBQUNyQixRQUFJLFdBQVcsU0FBUyxHQUFHO0FBQ3pCLHVCQUFpQjtBQUFBO0FBQUEsUUFFYixXQUNDO0FBQUEsUUFDQyxDQUFDLEdBQUcsTUFBTTtBQUFBLDJDQUN1QixDQUFDO0FBQUEseUNBQ0gsV0FBVyxFQUFFLElBQUksQ0FBQztBQUFBLDZDQUNkLFdBQVcsRUFBRSxRQUFRLENBQUM7QUFBQSw2RUFDVSxDQUFDO0FBQUE7QUFBQTtBQUFBLE1BR3RFLEVBQ0MsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBLElBRWY7QUFFQSxZQUFRLFlBQVk7QUFBQSwwREFDb0MsV0FBVyxZQUFZLENBQUM7QUFBQSxNQUM1RSxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFhbEIsYUFBUyxlQUFlLFVBQVUsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ25FLGFBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxJQUFJLGNBQWMsT0FBTyxhQUFhLENBQUM7QUFDMUUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFHRCxhQUFTLGlCQUFpQixrQkFBa0IsRUFBRSxRQUFRLENBQUMsUUFBUTtBQUM3RCxVQUFJLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUNuQyxjQUFNLE1BQU0sU0FBVSxFQUFFLE9BQXVCLFFBQVEsT0FBTyxHQUFHO0FBQ2pFLGNBQU0sSUFBSSxXQUFXLEdBQUc7QUFDeEIsWUFBSSxHQUFHO0FBQ0wsc0JBQVk7QUFBQSxZQUNWLFVBQVUsRUFBRTtBQUFBLFlBQ1osY0FBYyxFQUFFO0FBQUEsWUFDaEIsS0FBSztBQUFBLFlBQ0wsV0FBVztBQUFBLFVBQ2I7QUFDQSxrQkFBUTtBQUNSLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdELGFBQVMsZUFBZSxpQkFBaUIsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQzFFLFlBQU0sS0FBSyxTQUFTLGVBQWUsa0JBQWtCO0FBQ3JELFVBQUksVUFBVSxPQUFPLE1BQU07QUFBQSxJQUM3QixDQUFDO0FBR0QsYUFBUyxlQUFlLGtCQUFrQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDM0UsWUFBTSxRQUFRLFNBQVMsZUFBZSxpQkFBaUI7QUFDdkQsWUFBTSxXQUFXLE9BQU8sTUFBTSxLQUFLO0FBQ25DLFVBQUksVUFBVTtBQUNaLG9CQUFZO0FBQUEsVUFDVjtBQUFBLFVBQ0EsY0FBYztBQUFBLFVBQ2QsS0FBSztBQUFBLFVBQ0wsV0FBVztBQUFBLFFBQ2I7QUFDQSxnQkFBUTtBQUNSLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsZ0JBQXNCO0FBQzdCLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBU3BCLGFBQVMsZUFBZSxhQUFhLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN0RSxhQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sSUFBSSxlQUFlLE9BQU8sYUFBYSxDQUFDO0FBQzNFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsZ0JBQXNCO0FBQzdCLFFBQUksQ0FBQyxVQUFXO0FBRWhCLFVBQU0sT0FBTyxVQUFVLFFBQVE7QUFDL0IsVUFBTSxpQkFBaUIsU0FBUztBQUNoQyxVQUFNLGVBQWUsVUFBVSxhQUFhLElBQUksTUFBTSxHQUFHLEdBQUc7QUFFNUQsWUFBUSxZQUFZO0FBQUEsMERBQ29DO0FBQUEsTUFDcEQsVUFBVSxJQUFJLFNBQVMsS0FBSyxVQUFVLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxRQUFRLFVBQVU7QUFBQSxJQUM3RSxDQUFDO0FBQUE7QUFBQTtBQUFBLFFBSUcsVUFBVSxlQUNOLGlDQUFpQyxXQUFXLFVBQVUsYUFBYSxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsV0FDakYsRUFDTjtBQUFBLDhCQUN3QixXQUFXLFVBQVUsUUFBUSxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUVBSVcsV0FBVyxXQUFXLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQVExRCxpQkFBaUIsYUFBYSxFQUFFO0FBQUEsZ0VBQ0osaUJBQWlCLGFBQWEsRUFBRTtBQUFBO0FBQUEsWUFFcEYsaUJBQWlCLDZDQUE2QyxFQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTWxFLFVBQVUsT0FBTyxVQUFVLFFBQVEsZ0JBQWdCLDhEQUFnRSxFQUFFO0FBQUE7QUFBQTtBQUFBO0FBSzdILGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3pFLGtCQUFZO0FBQ1osYUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLElBQUksY0FBYyxPQUFPLGFBQWEsQ0FBQztBQUMxRSxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUVELGFBQVMsZUFBZSxZQUFZLEdBQUcsaUJBQWlCLFNBQVMsYUFBYTtBQUFBLEVBQ2hGO0FBRUEsaUJBQWUsZ0JBQStCO0FBQzVDLFFBQUksQ0FBQyxhQUFhLFVBQVUsV0FBWTtBQUV4QyxVQUFNLFlBQVksU0FBUyxlQUFlLGNBQWM7QUFDeEQsVUFBTSxPQUFPLFdBQVcsTUFBTSxLQUFLLEtBQUs7QUFDeEMsVUFBTSxZQUNILFNBQVMsY0FBYyxpQ0FBaUMsR0FBd0IsU0FBUztBQUU1RixZQUFRO0FBQ1IseUJBQXFCO0FBQ3JCLDBCQUFzQixVQUFVO0FBQ2hDLFdBQU87QUFFUCxRQUFJO0FBQ0YsWUFBTSxRQUFRLE1BQU0sU0FBUztBQUM3QixVQUFJLENBQUMsT0FBTztBQUNWLHVCQUFlO0FBQ2YsZ0JBQVE7QUFDUixlQUFPO0FBQ1A7QUFBQSxNQUNGO0FBRUEsWUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLFFBQVEsMkJBQTJCO0FBQUEsUUFDNUQsUUFBUTtBQUFBLFFBQ1IsU0FBUztBQUFBLFVBQ1AsZ0JBQWdCO0FBQUEsVUFDaEIsZUFBZSxVQUFVLEtBQUs7QUFBQSxRQUNoQztBQUFBLFFBQ0EsTUFBTSxLQUFLLFVBQVU7QUFBQSxVQUNuQjtBQUFBLFVBQ0EsS0FBSyxVQUFVO0FBQUEsVUFDZixVQUFVLFVBQVU7QUFBQSxVQUNwQjtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUVELFVBQUksSUFBSSxJQUFJO0FBQ1YsZ0JBQVE7QUFDUixlQUFPO0FBQ1A7QUFBQSxNQUNGO0FBRUEsWUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLLEVBQUUsTUFBTSxNQUFNLElBQUk7QUFFOUMsVUFBSSxNQUFNLFNBQVMsc0JBQXNCO0FBQ3ZDLHVCQUFlLEdBQUcsS0FBSyxXQUFXLEtBQUssU0FBUyx3QkFBd0I7QUFDeEUsZ0JBQVE7QUFDUixlQUFPO0FBRVAsY0FBTSxlQUFlLFFBQVEsY0FBYyxVQUFVO0FBQ3JELFlBQUksY0FBYztBQUNoQix1QkFBYSxZQUFZLFNBQVMsY0FBYyxJQUFJLENBQUM7QUFDckQsZ0JBQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztBQUN2QyxlQUFLLE9BQU8sR0FBRyxRQUFRO0FBQ3ZCLGVBQUssU0FBUztBQUNkLGVBQUssTUFBTSxRQUFRO0FBQ25CLGVBQUssY0FBYztBQUNuQix1QkFBYSxZQUFZLElBQUk7QUFBQSxRQUMvQjtBQUNBO0FBQUEsTUFDRjtBQUVBLHFCQUFlLE1BQU0sV0FBVyxNQUFNLFNBQVMsV0FBVyxJQUFJLE1BQU07QUFDcEUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULFFBQVE7QUFDTixxQkFBZTtBQUNmLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGlCQUF1QjtBQUM5QixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNdEI7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJSCxXQUFXLGtCQUFrQixDQUFDO0FBQUEsUUFDekMsc0JBQXNCLHNDQUFzQyxXQUFXLG9CQUFvQixNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsMkJBQTJCLEVBQUU7QUFBQTtBQUFBLGtEQUUzRixRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFNeEQsYUFBUyxlQUFlLG1CQUFtQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDNUUsa0JBQVk7QUFDWixtQkFBYSxDQUFDO0FBQ2QsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBUyxjQUFvQjtBQUMzQixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlYLFdBQVcsWUFBWSxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBS2pDLGFBQVMsZUFBZSxlQUFlLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN4RSxjQUFRLFlBQVksWUFBWTtBQUNoQyxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQU1BLFdBQVMsV0FBVyxLQUFxQjtBQUN2QyxVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxjQUFjO0FBQ2xCLFdBQU8sSUFBSTtBQUFBLEVBQ2I7QUFPQSxPQUFLOyIsCiAgIm5hbWVzIjogW10KfQo=
