"use strict";
(() => {
  // src/shared/constants.ts
  var BASE_URL = "https://ftc.bd73.com";
  var TOKEN_STORAGE_KEY = "ftc_extension_token";
  var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
  var AUTH_STARTED_KEY = "ftc_auth_started_at";
  var MSG = {
    START_PICKER: "FTC_START_PICKER",
    CANCEL_PICKER: "FTC_CANCEL_PICKER",
    ELEMENT_SELECTED: "FTC_ELEMENT_SELECTED",
    GET_CANDIDATES: "FTC_GET_CANDIDATES",
    CANDIDATES_RESULT: "FTC_CANDIDATES_RESULT",
    FTC_EXTENSION_TOKEN: "FTC_EXTENSION_TOKEN",
    AUTH_TAB_OPENED: "FTC_AUTH_TAB_OPENED"
  };

  // src/auth/token.ts
  async function getToken() {
    const result = await chrome.storage.local.get([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
    const token = result[TOKEN_STORAGE_KEY];
    const expiry = result[TOKEN_EXPIRY_KEY];
    if (!token || !expiry) return null;
    const expiryMs = new Date(expiry).getTime();
    if (!Number.isFinite(expiryMs) || expiryMs < Date.now()) {
      await clearToken();
      return null;
    }
    return token;
  }
  async function clearToken() {
    await chrome.storage.local.remove([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
  }
  async function isTokenValid() {
    const token = await getToken();
    return token !== null;
  }

  // src/popup/utils.ts
  function escapeAttr(str) {
    return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  var KNOWN_TIERS = ["free", "pro", "power"];
  function sanitizeTier(tier) {
    return KNOWN_TIERS.includes(tier) ? tier : "free";
  }

  // src/popup/popup.ts
  var TAG = "[FTC:popup]";
  var state = "unauthenticated";
  var userInfo = null;
  var selection = null;
  var candidates = [];
  var currentTabUrl = "";
  var currentTabTitle = "";
  var currentTabId = 0;
  var errorMessage = "";
  var createdMonitorName = "";
  var createdMonitorValue = "";
  var dropdownOpen = false;
  var content = document.getElementById("content");
  var accountArea = document.getElementById("account-area");
  var AUTH_TIMEOUT_MS = 12e4;
  var initRunning = false;
  async function init() {
    if (initRunning) {
      console.log(TAG, "init already running, skipping");
      return;
    }
    initRunning = true;
    console.log(TAG, "init start");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        currentTabUrl = tab.url || "";
        currentTabTitle = tab.title || "";
        currentTabId = tab.id || 0;
      }
      const valid = await isTokenValid();
      if (!valid) {
        console.log(TAG, "no valid token in storage");
        const stored = await chrome.storage.local.get(AUTH_STARTED_KEY);
        const startedAt = Number(stored[AUTH_STARTED_KEY]);
        const elapsed = Date.now() - startedAt;
        if (Number.isFinite(startedAt) && elapsed < AUTH_TIMEOUT_MS) {
          if (elapsed < 3e4) {
            console.log(TAG, "auth attempt in progress (", Math.round(elapsed / 1e3), "s ago)");
            state = "connecting";
          } else {
            console.warn(TAG, "recent auth attempt found but no token \u2014 showing failure state");
            state = "auth_failed";
          }
        } else {
          state = "unauthenticated";
        }
        render();
        return;
      }
      const token = await getToken();
      if (!token) {
        console.log(TAG, "getToken returned null despite isTokenValid");
        state = "unauthenticated";
        render();
        return;
      }
      console.log(TAG, "verifying token with backend...");
      try {
        const res = await fetch(`${BASE_URL}/api/extension/verify`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) {
          console.warn(TAG, "verify returned", res.status);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        userInfo = await res.json().catch(() => null);
        if (!userInfo || typeof userInfo.userId !== "string" || typeof userInfo.tier !== "string") {
          console.warn(TAG, "verify response malformed:", userInfo);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        await chrome.storage.local.set({ cachedUserInfo: userInfo });
        await chrome.storage.local.remove(AUTH_STARTED_KEY);
        state = "authenticated";
        console.log(TAG, "authenticated as", userInfo.email);
      } catch (err) {
        console.warn(TAG, "verify network error:", err);
        const cached = await chrome.storage.local.get("cachedUserInfo");
        const c = cached.cachedUserInfo;
        if (c && typeof c.userId === "string" && typeof c.tier === "string" && typeof c.email === "string") {
          userInfo = c;
          state = "authenticated";
        } else {
          state = "unauthenticated";
        }
      }
      render();
    } finally {
      initRunning = false;
    }
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === MSG.ELEMENT_SELECTED) {
      selection = {
        selector: message.selector,
        currentValue: message.currentValue,
        url: message.url,
        pageTitle: message.pageTitle
      };
      state = "confirm";
      render();
    }
    if (message.type === MSG.CANDIDATES_RESULT) {
      candidates = message.candidates || [];
      if (state === "authenticated" || state === "picking") {
        render();
      }
    }
    if (message.type === MSG.CANCEL_PICKER) {
      if (state === "picking") {
        state = "authenticated";
        render();
      }
    }
    if (message.type === "FTC_AUTH_COMPLETE") {
      init();
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[TOKEN_STORAGE_KEY]?.newValue && (state === "connecting" || state === "auth_failed")) {
      console.log(TAG, "token appeared in storage (direct write), re-initialising...");
      init();
    }
  });
  function render() {
    renderAccount();
    switch (state) {
      case "unauthenticated":
        renderUnauth();
        break;
      case "connecting":
        renderConnecting();
        break;
      case "auth_failed":
        renderAuthFailed();
        break;
      case "authenticated":
        renderAuthenticated();
        break;
      case "picking":
        renderPicking();
        break;
      case "confirm":
        renderConfirm();
        break;
      case "creating":
        renderCreating();
        break;
      case "success":
        renderSuccess();
        break;
      case "error":
        renderError();
        break;
    }
  }
  function renderAccount() {
    if (!userInfo) {
      accountArea.innerHTML = "";
      return;
    }
    accountArea.innerHTML = `
    <button class="account-btn" id="account-toggle">
      ${escapeHtml(userInfo.email || "Connected")} &#9662;
    </button>
    <div class="account-dropdown ${dropdownOpen ? "" : "hidden"}" id="account-dropdown">
      <div class="dropdown-email">
        ${escapeHtml(userInfo.email || userInfo.userId)}
        <span class="tier-badge tier-${sanitizeTier(userInfo.tier)}">${escapeHtml(userInfo.tier)}</span>
      </div>
      <a class="dropdown-item" href="${BASE_URL}/dashboard" target="_blank">Open dashboard</a>
      <div class="dropdown-divider"></div>
      <button class="dropdown-item" id="disconnect-btn">Disconnect</button>
    </div>
  `;
    document.getElementById("account-toggle")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdownOpen = !dropdownOpen;
      renderAccount();
    });
    document.getElementById("disconnect-btn")?.addEventListener("click", async () => {
      await clearToken();
      await chrome.storage.local.remove("cachedUserInfo");
      userInfo = null;
      dropdownOpen = false;
      state = "unauthenticated";
      render();
    });
    document.addEventListener("click", () => {
      if (dropdownOpen) {
        dropdownOpen = false;
        renderAccount();
      }
    }, { once: true });
  }
  function renderUnauth() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Track what matters on any webpage.</h2>
      <button class="btn btn-primary btn-full" id="connect-btn">Connect your account</button>
      <p>Already have an account? Sign in above.</p>
    </div>
  `;
    document.getElementById("connect-btn")?.addEventListener("click", startAuthFlow);
  }
  function renderAuthFailed() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Connection failed</h2>
      <p>We couldn't connect the extension to your account. This can happen if your browser blocked the connection.</p>
      <button class="btn btn-primary btn-full" id="retry-connect-btn">Try again</button>
      <p style="margin-top: 12px; font-size: 12px; opacity: 0.7;">
        Tip: when Chrome asks to allow access to ftc.bd73.com, click <strong>Allow</strong>.
      </p>
    </div>
  `;
    document.getElementById("retry-connect-btn")?.addEventListener("click", startAuthFlow);
  }
  async function startAuthFlow() {
    console.log(TAG, "starting auth flow");
    let permissionGranted = false;
    try {
      const origin = new URL(BASE_URL).origin;
      permissionGranted = await chrome.permissions.contains({ origins: [`${origin}/*`] });
      console.log(TAG, "host permission already granted:", permissionGranted);
      if (!permissionGranted) {
        permissionGranted = await chrome.permissions.request({ origins: [`${origin}/*`] });
        console.log(TAG, "host permission request result:", permissionGranted);
      }
    } catch (err) {
      console.warn(TAG, "permission request error:", err);
    }
    await chrome.storage.local.set({ [AUTH_STARTED_KEY]: Date.now() });
    let tab;
    try {
      tab = await chrome.tabs.create({ url: `${BASE_URL}/extension-auth` });
    } catch (err) {
      console.error(TAG, "failed to open auth tab:", err);
      state = "auth_failed";
      render();
      return;
    }
    console.log(TAG, "auth tab created:", tab.id);
    if (tab.id) {
      chrome.runtime.sendMessage({ type: MSG.AUTH_TAB_OPENED, tabId: tab.id }).catch(
        (err) => console.warn(TAG, "failed to notify service worker of auth tab:", err)
      );
    }
    state = "connecting";
    render();
  }
  function renderConnecting() {
    content.innerHTML = `
    <div class="connecting">
      <div class="spinner"></div>
      <p>Connecting...</p>
      <p>Waiting for you to sign in at FetchTheChange.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-connect" style="margin-top: 16px;">Cancel</button>
    </div>
  `;
    document.getElementById("cancel-connect")?.addEventListener("click", async () => {
      await chrome.storage.local.remove(AUTH_STARTED_KEY);
      state = "unauthenticated";
      render();
    });
  }
  function renderAuthenticated() {
    const truncatedUrl = currentTabUrl.length > 45 ? currentTabUrl.slice(0, 45) + "..." : currentTabUrl;
    let candidatesHtml = "";
    if (candidates.length > 0) {
      candidatesHtml = `
      <div class="section-header">Suggested elements</div>
      ${candidates.map(
        (c, i) => `
        <div class="candidate" data-idx="${i}">
          <span class="candidate-text">${escapeHtml(c.text)}</span>
          <span class="candidate-selector">${escapeHtml(c.selector)}</span>
          <button class="btn btn-primary btn-sm candidate-track" data-idx="${i}">Track this</button>
        </div>
      `
      ).join("")}
    `;
    }
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(truncatedUrl)}</div>
    ${candidatesHtml}
    <div class="section-header">Or pick manually</div>
    <button class="btn btn-primary btn-full" id="pick-btn">Pick an element on this page</button>
    <button class="advanced-toggle" id="advanced-toggle">&#9662; Advanced (CSS selector)</button>
    <div class="advanced-content" id="advanced-content">
      <div class="form-group">
        <input type="text" class="form-input" id="manual-selector" placeholder="e.g. .product-price">
      </div>
      <button class="btn btn-secondary btn-sm" id="manual-track-btn">Use this selector</button>
    </div>
  `;
    document.getElementById("pick-btn")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.querySelectorAll(".candidate-track").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const idx = parseInt(e.target.dataset.idx || "0");
        const c = candidates[idx];
        if (c) {
          selection = {
            selector: c.selector,
            currentValue: c.text,
            url: currentTabUrl,
            pageTitle: currentTabTitle
          };
          state = "confirm";
          render();
        }
      });
    });
    document.getElementById("advanced-toggle")?.addEventListener("click", () => {
      const el = document.getElementById("advanced-content");
      el?.classList.toggle("open");
    });
    document.getElementById("manual-track-btn")?.addEventListener("click", () => {
      const input = document.getElementById("manual-selector");
      const selector = input?.value.trim();
      if (selector) {
        selection = {
          selector,
          currentValue: "",
          url: currentTabUrl,
          pageTitle: ""
        };
        state = "confirm";
        render();
      }
    });
  }
  function renderPicking() {
    content.innerHTML = `
    <div class="picker-info">
      <div class="icon">&#127919;</div>
      <p><strong>Click any element on the page to track it.</strong></p>
      <p>Press Esc to cancel.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-pick" style="margin-top: 16px;">Cancel picking</button>
    </div>
  `;
    document.getElementById("cancel-pick")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.CANCEL_PICKER, tabId: currentTabId });
      state = "authenticated";
      render();
    });
  }
  function renderConfirm() {
    if (!selection) return;
    const tier = userInfo?.tier || "free";
    const hourlyDisabled = tier === "free";
    const defaultName = (selection.pageTitle || "").slice(0, 100);
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(
      selection.url.length > 45 ? selection.url.slice(0, 45) + "..." : selection.url
    )}</div>
    <div class="confirm-card">
      <div class="label">Element selected</div>
      ${selection.currentValue ? `<div class="value">Currently: ${escapeHtml(selection.currentValue.slice(0, 100))}</div>` : ""}
      <div class="selector">${escapeHtml(selection.selector)}</div>
    </div>
    <div class="form-group">
      <label class="form-label">Monitor name</label>
      <input type="text" class="form-input" id="monitor-name" value="${escapeAttr(defaultName)}" maxlength="100">
    </div>
    <div class="form-group">
      <label class="form-label">Check frequency</label>
      <div class="radio-group">
        <label class="radio-label">
          <input type="radio" name="frequency" value="daily" checked> Daily
        </label>
        <label class="radio-label ${hourlyDisabled ? "disabled" : ""}">
          <input type="radio" name="frequency" value="hourly" ${hourlyDisabled ? "disabled" : ""}>
          Hourly
          ${hourlyDisabled ? '<span class="tooltip-text">(Pro+)</span>' : ""}
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="pick-again-btn">Pick again</button>
      <button class="btn btn-primary" id="create-btn">Create monitor</button>
    </div>
  `;
    document.getElementById("pick-again-btn")?.addEventListener("click", () => {
      selection = null;
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.getElementById("create-btn")?.addEventListener("click", createMonitor);
  }
  async function createMonitor() {
    if (!selection || state === "creating") return;
    const nameInput = document.getElementById("monitor-name");
    const name = nameInput?.value.trim() || "Untitled monitor";
    const frequency = document.querySelector('input[name="frequency"]:checked')?.value || "daily";
    state = "creating";
    createdMonitorName = name;
    createdMonitorValue = selection.currentValue;
    render();
    try {
      const token = await getToken();
      if (!token) {
        errorMessage = "Not authenticated. Please reconnect.";
        state = "error";
        render();
        return;
      }
      const res = await fetch(`${BASE_URL}/api/extension/monitors`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name,
          url: selection.url,
          selector: selection.selector,
          frequency
        })
      });
      if (res.ok) {
        state = "success";
        render();
        return;
      }
      const data = await res.json().catch(() => null);
      if (data?.code === "TIER_LIMIT_REACHED") {
        errorMessage = `${data.message || data.error || "Monitor limit reached."}`;
        state = "error";
        render();
        const errContainer = content.querySelector(".error p");
        if (errContainer) {
          errContainer.appendChild(document.createElement("br"));
          const link = document.createElement("a");
          link.href = `${BASE_URL}/pricing`;
          link.target = "_blank";
          link.style.color = "#6366f1";
          link.textContent = "Upgrade your plan";
          errContainer.appendChild(link);
        }
        return;
      }
      errorMessage = data?.message || data?.error || `Failed (${res.status})`;
      state = "error";
      render();
    } catch {
      errorMessage = "Network error. Please try again.";
      state = "error";
      render();
    }
  }
  function renderCreating() {
    content.innerHTML = `
    <div class="connecting" style="padding-top: 64px;">
      <div class="spinner"></div>
      <p>Creating monitor...</p>
    </div>
  `;
  }
  function renderSuccess() {
    content.innerHTML = `
    <div class="success">
      <div class="icon">&#10003;</div>
      <h3>Monitor created!</h3>
      <p><strong>${escapeHtml(createdMonitorName)}</strong> is now being watched.</p>
      ${createdMonitorValue ? `<p>You'll be notified when <strong>${escapeHtml(createdMonitorValue.slice(0, 60))}</strong> changes.</p>` : ""}
      <div class="btn-row" style="margin-top: 24px; justify-content: center;">
        <a class="btn btn-primary btn-sm" href="${BASE_URL}/dashboard" target="_blank">View in dashboard</a>
        <button class="btn btn-secondary btn-sm" id="track-another-btn">Track another</button>
      </div>
    </div>
  `;
    document.getElementById("track-another-btn")?.addEventListener("click", () => {
      selection = null;
      candidates = [];
      state = "authenticated";
      render();
    });
  }
  function renderError() {
    content.innerHTML = `
    <div class="error">
      <div class="icon">&#10007;</div>
      <h3>Couldn't create monitor</h3>
      <p>${escapeHtml(errorMessage)}</p>
      <button class="btn btn-secondary" id="try-again-btn">Try again</button>
    </div>
  `;
    document.getElementById("try-again-btn")?.addEventListener("click", () => {
      state = selection ? "confirm" : "authenticated";
      render();
    });
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
  init();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL3NoYXJlZC9jb25zdGFudHMudHMiLCAiLi4vLi4vc3JjL2F1dGgvdG9rZW4udHMiLCAiLi4vLi4vc3JjL3BvcHVwL3V0aWxzLnRzIiwgIi4uLy4uL3NyYy9wb3B1cC9wb3B1cC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLy8gQkFTRV9VUkwgaXMgaW5qZWN0ZWQgYXQgYnVpbGQgdGltZSB2aWEgZXNidWlsZCBkZWZpbmUuXG4vLyBTZXQgQkFTRV9VUkwgZW52IHZhciB0byBvdmVycmlkZSAoZGVmYXVsdDogaHR0cHM6Ly9mdGMuYmQ3My5jb20pXG5kZWNsYXJlIGNvbnN0IEJBU0VfVVJMX0lOSkVDVEVEOiBzdHJpbmc7XG5leHBvcnQgY29uc3QgQkFTRV9VUkwgPSBCQVNFX1VSTF9JTkpFQ1RFRDtcbmV4cG9ydCBjb25zdCBUT0tFTl9TVE9SQUdFX0tFWSA9IFwiZnRjX2V4dGVuc2lvbl90b2tlblwiO1xuZXhwb3J0IGNvbnN0IFRPS0VOX0VYUElSWV9LRVkgPSBcImZ0Y19leHRlbnNpb25fdG9rZW5fZXhwaXJ5XCI7XG5leHBvcnQgY29uc3QgQVVUSF9TVEFSVEVEX0tFWSA9IFwiZnRjX2F1dGhfc3RhcnRlZF9hdFwiO1xuXG5leHBvcnQgY29uc3QgTVNHID0ge1xuICBTVEFSVF9QSUNLRVI6IFwiRlRDX1NUQVJUX1BJQ0tFUlwiLFxuICBDQU5DRUxfUElDS0VSOiBcIkZUQ19DQU5DRUxfUElDS0VSXCIsXG4gIEVMRU1FTlRfU0VMRUNURUQ6IFwiRlRDX0VMRU1FTlRfU0VMRUNURURcIixcbiAgR0VUX0NBTkRJREFURVM6IFwiRlRDX0dFVF9DQU5ESURBVEVTXCIsXG4gIENBTkRJREFURVNfUkVTVUxUOiBcIkZUQ19DQU5ESURBVEVTX1JFU1VMVFwiLFxuICBGVENfRVhURU5TSU9OX1RPS0VOOiBcIkZUQ19FWFRFTlNJT05fVE9LRU5cIixcbiAgQVVUSF9UQUJfT1BFTkVEOiBcIkZUQ19BVVRIX1RBQl9PUEVORURcIixcbn0gYXMgY29uc3Q7XG4iLCAiaW1wb3J0IHsgVE9LRU5fU1RPUkFHRV9LRVksIFRPS0VOX0VYUElSWV9LRVkgfSBmcm9tIFwiLi4vc2hhcmVkL2NvbnN0YW50c1wiO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VG9rZW4oKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbVE9LRU5fU1RPUkFHRV9LRVksIFRPS0VOX0VYUElSWV9LRVldKTtcbiAgY29uc3QgdG9rZW4gPSByZXN1bHRbVE9LRU5fU1RPUkFHRV9LRVldO1xuICBjb25zdCBleHBpcnkgPSByZXN1bHRbVE9LRU5fRVhQSVJZX0tFWV07XG5cbiAgaWYgKCF0b2tlbiB8fCAhZXhwaXJ5KSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBleHBpcnlNcyA9IG5ldyBEYXRlKGV4cGlyeSkuZ2V0VGltZSgpO1xuICBpZiAoIU51bWJlci5pc0Zpbml0ZShleHBpcnlNcykgfHwgZXhwaXJ5TXMgPCBEYXRlLm5vdygpKSB7XG4gICAgYXdhaXQgY2xlYXJUb2tlbigpO1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgcmV0dXJuIHRva2VuO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0VG9rZW4odG9rZW46IHN0cmluZywgZXhwaXJlc0F0OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHtcbiAgICBbVE9LRU5fU1RPUkFHRV9LRVldOiB0b2tlbixcbiAgICBbVE9LRU5fRVhQSVJZX0tFWV06IGV4cGlyZXNBdCxcbiAgfSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclRva2VuKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoW1RPS0VOX1NUT1JBR0VfS0VZLCBUT0tFTl9FWFBJUllfS0VZXSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpc1Rva2VuVmFsaWQoKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHRva2VuID0gYXdhaXQgZ2V0VG9rZW4oKTtcbiAgcmV0dXJuIHRva2VuICE9PSBudWxsO1xufVxuIiwgImV4cG9ydCBmdW5jdGlvbiBlc2NhcGVBdHRyKHN0cjogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHN0ci5yZXBsYWNlKC8mL2csIFwiJmFtcDtcIikucmVwbGFjZSgvXCIvZywgXCImcXVvdDtcIikucmVwbGFjZSgvJy9nLCBcIiYjMzk7XCIpLnJlcGxhY2UoLzwvZywgXCImbHQ7XCIpLnJlcGxhY2UoLz4vZywgXCImZ3Q7XCIpO1xufVxuXG4vLyBLZWVwIGluIHN5bmMgd2l0aCBzaGFyZWQvbW9kZWxzL2F1dGgudHMgVElFUl9MSU1JVFNcbmNvbnN0IEtOT1dOX1RJRVJTID0gW1wiZnJlZVwiLCBcInByb1wiLCBcInBvd2VyXCJdO1xuZXhwb3J0IGZ1bmN0aW9uIHNhbml0aXplVGllcih0aWVyOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gS05PV05fVElFUlMuaW5jbHVkZXModGllcikgPyB0aWVyIDogXCJmcmVlXCI7XG59XG4iLCAiaW1wb3J0IHsgQkFTRV9VUkwsIE1TRywgQVVUSF9TVEFSVEVEX0tFWSwgVE9LRU5fU1RPUkFHRV9LRVkgfSBmcm9tIFwiLi4vc2hhcmVkL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgZ2V0VG9rZW4sIGNsZWFyVG9rZW4sIGlzVG9rZW5WYWxpZCB9IGZyb20gXCIuLi9hdXRoL3Rva2VuXCI7XG5pbXBvcnQgeyBlc2NhcGVBdHRyLCBzYW5pdGl6ZVRpZXIgfSBmcm9tIFwiLi91dGlsc1wiO1xuXG5jb25zdCBUQUcgPSBcIltGVEM6cG9wdXBdXCI7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gU3RhdGVcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5pbnRlcmZhY2UgVXNlckluZm8ge1xuICB1c2VySWQ6IHN0cmluZztcbiAgdGllcjogc3RyaW5nO1xuICBlbWFpbDogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgU2VsZWN0aW9uIHtcbiAgc2VsZWN0b3I6IHN0cmluZztcbiAgY3VycmVudFZhbHVlOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xuICBwYWdlVGl0bGU6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIENhbmRpZGF0ZSB7XG4gIHNlbGVjdG9yOiBzdHJpbmc7XG4gIHRleHQ6IHN0cmluZztcbiAgc2NvcmU6IG51bWJlcjtcbn1cblxudHlwZSBQb3B1cFN0YXRlID1cbiAgfCBcInVuYXV0aGVudGljYXRlZFwiXG4gIHwgXCJjb25uZWN0aW5nXCJcbiAgfCBcImF1dGhfZmFpbGVkXCJcbiAgfCBcImF1dGhlbnRpY2F0ZWRcIlxuICB8IFwicGlja2luZ1wiXG4gIHwgXCJjb25maXJtXCJcbiAgfCBcImNyZWF0aW5nXCJcbiAgfCBcInN1Y2Nlc3NcIlxuICB8IFwiZXJyb3JcIjtcblxubGV0IHN0YXRlOiBQb3B1cFN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbmxldCB1c2VySW5mbzogVXNlckluZm8gfCBudWxsID0gbnVsbDtcbmxldCBzZWxlY3Rpb246IFNlbGVjdGlvbiB8IG51bGwgPSBudWxsO1xubGV0IGNhbmRpZGF0ZXM6IENhbmRpZGF0ZVtdID0gW107XG5sZXQgY3VycmVudFRhYlVybCA9IFwiXCI7XG5sZXQgY3VycmVudFRhYlRpdGxlID0gXCJcIjtcbmxldCBjdXJyZW50VGFiSWQgPSAwO1xubGV0IGVycm9yTWVzc2FnZSA9IFwiXCI7XG5sZXQgY3JlYXRlZE1vbml0b3JOYW1lID0gXCJcIjtcbmxldCBjcmVhdGVkTW9uaXRvclZhbHVlID0gXCJcIjtcbmxldCBkcm9wZG93bk9wZW4gPSBmYWxzZTtcblxuY29uc3QgY29udGVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29udGVudFwiKSE7XG5jb25zdCBhY2NvdW50QXJlYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWNjb3VudC1hcmVhXCIpITtcblxuLy8gSG93IGxvbmcgd2UgY29uc2lkZXIgYW4gYXV0aCBhdHRlbXB0IFwicmVjZW50XCIgXHUyMDE0IGlmIG5vIHRva2VuIHdhcyBzdG9yZWRcbi8vIHdpdGhpbiB0aGlzIHdpbmRvdywgd2Ugc2hvdyBhbiBlcnJvciBpbnN0ZWFkIG9mIHRoZSBkZWZhdWx0IGNvbm5lY3Qgc2NyZWVuLlxuLy8gTXVzdCBtYXRjaCB0aGUgU1cncyBmYWxsYmFjayB3aW5kb3cgKDEyMCBzIGluIHNlcnZpY2Utd29ya2VyLnRzIG9uVXBkYXRlZCkuXG5jb25zdCBBVVRIX1RJTUVPVVRfTVMgPSAxMjBfMDAwO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIEluaXRpYWxpc2Vcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5sZXQgaW5pdFJ1bm5pbmcgPSBmYWxzZTtcblxuYXN5bmMgZnVuY3Rpb24gaW5pdCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGluaXRSdW5uaW5nKSB7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImluaXQgYWxyZWFkeSBydW5uaW5nLCBza2lwcGluZ1wiKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaW5pdFJ1bm5pbmcgPSB0cnVlO1xuICBjb25zb2xlLmxvZyhUQUcsIFwiaW5pdCBzdGFydFwiKTtcbiAgdHJ5IHtcblxuICAvLyBHZXQgY3VycmVudCB0YWIgaW5mb1xuICBjb25zdCBbdGFiXSA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICBpZiAodGFiKSB7XG4gICAgY3VycmVudFRhYlVybCA9IHRhYi51cmwgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiVGl0bGUgPSB0YWIudGl0bGUgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiSWQgPSB0YWIuaWQgfHwgMDtcbiAgfVxuXG4gIGNvbnN0IHZhbGlkID0gYXdhaXQgaXNUb2tlblZhbGlkKCk7XG4gIGlmICghdmFsaWQpIHtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwibm8gdmFsaWQgdG9rZW4gaW4gc3RvcmFnZVwiKTtcblxuICAgIC8vIENoZWNrIGlmIGFuIGF1dGggYXR0ZW1wdCB3YXMgcmVjZW50bHkgc3RhcnRlZC5cbiAgICAvLyBTaG93IFwiY29ubmVjdGluZ1wiIGZvciB0aGUgZmlyc3QgMzAgcyAoYXV0aCBtYXkgc3RpbGwgYmUgaW4gcHJvZ3Jlc3MpLFxuICAgIC8vIHRoZW4gXCJhdXRoX2ZhaWxlZFwiIHVwIHRvIEFVVEhfVElNRU9VVF9NUy5cbiAgICBjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoQVVUSF9TVEFSVEVEX0tFWSk7XG4gICAgY29uc3Qgc3RhcnRlZEF0ID0gTnVtYmVyKHN0b3JlZFtBVVRIX1NUQVJURURfS0VZXSk7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBzdGFydGVkQXQ7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShzdGFydGVkQXQpICYmIGVsYXBzZWQgPCBBVVRIX1RJTUVPVVRfTVMpIHtcbiAgICAgIGlmIChlbGFwc2VkIDwgMzBfMDAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFRBRywgXCJhdXRoIGF0dGVtcHQgaW4gcHJvZ3Jlc3MgKFwiLCBNYXRoLnJvdW5kKGVsYXBzZWQgLyAxMDAwKSwgXCJzIGFnbylcIik7XG4gICAgICAgIHN0YXRlID0gXCJjb25uZWN0aW5nXCI7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLndhcm4oVEFHLCBcInJlY2VudCBhdXRoIGF0dGVtcHQgZm91bmQgYnV0IG5vIHRva2VuIFx1MjAxNCBzaG93aW5nIGZhaWx1cmUgc3RhdGVcIik7XG4gICAgICAgIHN0YXRlID0gXCJhdXRoX2ZhaWxlZFwiO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuXG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gVmVyaWZ5IHRva2VuIHdpdGggYmFja2VuZFxuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIGlmICghdG9rZW4pIHtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwiZ2V0VG9rZW4gcmV0dXJuZWQgbnVsbCBkZXNwaXRlIGlzVG9rZW5WYWxpZFwiKTtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc29sZS5sb2coVEFHLCBcInZlcmlmeWluZyB0b2tlbiB3aXRoIGJhY2tlbmQuLi5cIik7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L2FwaS9leHRlbnNpb24vdmVyaWZ5YCwge1xuICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICAgIH0pO1xuXG4gICAgaWYgKCFyZXMub2spIHtcbiAgICAgIGNvbnNvbGUud2FybihUQUcsIFwidmVyaWZ5IHJldHVybmVkXCIsIHJlcy5zdGF0dXMpO1xuICAgICAgYXdhaXQgY2xlYXJUb2tlbigpO1xuICAgICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdXNlckluZm8gPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgIGlmICghdXNlckluZm8gfHwgdHlwZW9mIHVzZXJJbmZvLnVzZXJJZCAhPT0gXCJzdHJpbmdcIiB8fCB0eXBlb2YgdXNlckluZm8udGllciAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgY29uc29sZS53YXJuKFRBRywgXCJ2ZXJpZnkgcmVzcG9uc2UgbWFsZm9ybWVkOlwiLCB1c2VySW5mbyk7XG4gICAgICBhd2FpdCBjbGVhclRva2VuKCk7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gQ2FjaGUgdXNlckluZm8gZm9yIG9mZmxpbmUgZmFsbGJhY2tcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBjYWNoZWRVc2VySW5mbzogdXNlckluZm8gfSk7XG4gICAgLy8gQ2xlYXIgYW55IHN0YWxlIGF1dGgtc3RhcnRlZCBmbGFnXG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKEFVVEhfU1RBUlRFRF9LRVkpO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImF1dGhlbnRpY2F0ZWQgYXNcIiwgdXNlckluZm8uZW1haWwpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oVEFHLCBcInZlcmlmeSBuZXR3b3JrIGVycm9yOlwiLCBlcnIpO1xuICAgIC8vIE5ldHdvcmsgZXJyb3IgXHUyMDE0IHRyeSB0byByZXN0b3JlIGNhY2hlZCB1c2VySW5mbyBzbyB0aWVyL2FjY291bnQgZGlzcGxheSBjb3JyZWN0bHlcbiAgICBjb25zdCBjYWNoZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICBjb25zdCBjID0gY2FjaGVkLmNhY2hlZFVzZXJJbmZvO1xuICAgIGlmIChjICYmIHR5cGVvZiBjLnVzZXJJZCA9PT0gXCJzdHJpbmdcIiAmJiB0eXBlb2YgYy50aWVyID09PSBcInN0cmluZ1wiICYmIHR5cGVvZiBjLmVtYWlsID09PSBcInN0cmluZ1wiKSB7XG4gICAgICB1c2VySW5mbyA9IGM7XG4gICAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuICB9XG5cbiAgcmVuZGVyKCk7XG4gIH0gZmluYWxseSB7XG4gICAgaW5pdFJ1bm5pbmcgPSBmYWxzZTtcbiAgfVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIExpc3RlbiBmb3IgbWVzc2FnZXMgZnJvbSBiYWNrZ3JvdW5kL2NvbnRlbnRcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UpID0+IHtcbiAgaWYgKG1lc3NhZ2UudHlwZSA9PT0gTVNHLkVMRU1FTlRfU0VMRUNURUQpIHtcbiAgICBzZWxlY3Rpb24gPSB7XG4gICAgICBzZWxlY3RvcjogbWVzc2FnZS5zZWxlY3RvcixcbiAgICAgIGN1cnJlbnRWYWx1ZTogbWVzc2FnZS5jdXJyZW50VmFsdWUsXG4gICAgICB1cmw6IG1lc3NhZ2UudXJsLFxuICAgICAgcGFnZVRpdGxlOiBtZXNzYWdlLnBhZ2VUaXRsZSxcbiAgICB9O1xuICAgIHN0YXRlID0gXCJjb25maXJtXCI7XG4gICAgcmVuZGVyKCk7XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuQ0FORElEQVRFU19SRVNVTFQpIHtcbiAgICBjYW5kaWRhdGVzID0gbWVzc2FnZS5jYW5kaWRhdGVzIHx8IFtdO1xuICAgIGlmIChzdGF0ZSA9PT0gXCJhdXRoZW50aWNhdGVkXCIgfHwgc3RhdGUgPT09IFwicGlja2luZ1wiKSB7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuQ0FOQ0VMX1BJQ0tFUikge1xuICAgIGlmIChzdGF0ZSA9PT0gXCJwaWNraW5nXCIpIHtcbiAgICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBcIkZUQ19BVVRIX0NPTVBMRVRFXCIpIHtcbiAgICAvLyBSZS1pbml0aWFsaXNlIGFmdGVyIGF1dGhcbiAgICBpbml0KCk7XG4gIH1cbn0pO1xuXG4vLyBBbHNvIGxpc3RlbiBmb3IgZGlyZWN0IHN0b3JhZ2Ugd3JpdGVzIChlLmcuIGZyb20gYXV0aC1yZWxheSBjb250ZW50IHNjcmlwdFxuLy8gd3JpdGluZyB0aGUgdG9rZW4gZGlyZWN0bHksIGJ5cGFzc2luZyB0aGUgc2VydmljZSB3b3JrZXIpLlxuY2hyb21lLnN0b3JhZ2Uub25DaGFuZ2VkLmFkZExpc3RlbmVyKChjaGFuZ2VzLCBhcmVhKSA9PiB7XG4gIGlmIChhcmVhICE9PSBcImxvY2FsXCIpIHJldHVybjtcbiAgaWYgKGNoYW5nZXNbVE9LRU5fU1RPUkFHRV9LRVldPy5uZXdWYWx1ZSAmJiAoc3RhdGUgPT09IFwiY29ubmVjdGluZ1wiIHx8IHN0YXRlID09PSBcImF1dGhfZmFpbGVkXCIpKSB7XG4gICAgY29uc29sZS5sb2coVEFHLCBcInRva2VuIGFwcGVhcmVkIGluIHN0b3JhZ2UgKGRpcmVjdCB3cml0ZSksIHJlLWluaXRpYWxpc2luZy4uLlwiKTtcbiAgICBpbml0KCk7XG4gIH1cbn0pO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIFJlbmRlclxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIHJlbmRlcigpOiB2b2lkIHtcbiAgcmVuZGVyQWNjb3VudCgpO1xuXG4gIHN3aXRjaCAoc3RhdGUpIHtcbiAgICBjYXNlIFwidW5hdXRoZW50aWNhdGVkXCI6XG4gICAgICByZW5kZXJVbmF1dGgoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJjb25uZWN0aW5nXCI6XG4gICAgICByZW5kZXJDb25uZWN0aW5nKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiYXV0aF9mYWlsZWRcIjpcbiAgICAgIHJlbmRlckF1dGhGYWlsZWQoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJhdXRoZW50aWNhdGVkXCI6XG4gICAgICByZW5kZXJBdXRoZW50aWNhdGVkKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwicGlja2luZ1wiOlxuICAgICAgcmVuZGVyUGlja2luZygpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImNvbmZpcm1cIjpcbiAgICAgIHJlbmRlckNvbmZpcm0oKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJjcmVhdGluZ1wiOlxuICAgICAgcmVuZGVyQ3JlYXRpbmcoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJzdWNjZXNzXCI6XG4gICAgICByZW5kZXJTdWNjZXNzKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZXJyb3JcIjpcbiAgICAgIHJlbmRlckVycm9yKCk7XG4gICAgICBicmVhaztcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50KCk6IHZvaWQge1xuICBpZiAoIXVzZXJJbmZvKSB7XG4gICAgYWNjb3VudEFyZWEuaW5uZXJIVE1MID0gXCJcIjtcbiAgICByZXR1cm47XG4gIH1cblxuICBhY2NvdW50QXJlYS5pbm5lckhUTUwgPSBgXG4gICAgPGJ1dHRvbiBjbGFzcz1cImFjY291bnQtYnRuXCIgaWQ9XCJhY2NvdW50LXRvZ2dsZVwiPlxuICAgICAgJHtlc2NhcGVIdG1sKHVzZXJJbmZvLmVtYWlsIHx8IFwiQ29ubmVjdGVkXCIpfSAmIzk2NjI7XG4gICAgPC9idXR0b24+XG4gICAgPGRpdiBjbGFzcz1cImFjY291bnQtZHJvcGRvd24gJHtkcm9wZG93bk9wZW4gPyBcIlwiIDogXCJoaWRkZW5cIn1cIiBpZD1cImFjY291bnQtZHJvcGRvd25cIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJkcm9wZG93bi1lbWFpbFwiPlxuICAgICAgICAke2VzY2FwZUh0bWwodXNlckluZm8uZW1haWwgfHwgdXNlckluZm8udXNlcklkKX1cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ0aWVyLWJhZGdlIHRpZXItJHtzYW5pdGl6ZVRpZXIodXNlckluZm8udGllcil9XCI+JHtlc2NhcGVIdG1sKHVzZXJJbmZvLnRpZXIpfTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGEgY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgaHJlZj1cIiR7QkFTRV9VUkx9L2Rhc2hib2FyZFwiIHRhcmdldD1cIl9ibGFua1wiPk9wZW4gZGFzaGJvYXJkPC9hPlxuICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLWRpdmlkZXJcIj48L2Rpdj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgaWQ9XCJkaXNjb25uZWN0LWJ0blwiPkRpc2Nvbm5lY3Q8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImFjY291bnQtdG9nZ2xlXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIGRyb3Bkb3duT3BlbiA9ICFkcm9wZG93bk9wZW47XG4gICAgcmVuZGVyQWNjb3VudCgpO1xuICB9KTtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRpc2Nvbm5lY3QtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGNsZWFyVG9rZW4oKTtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICB1c2VySW5mbyA9IG51bGw7XG4gICAgZHJvcGRvd25PcGVuID0gZmFsc2U7XG4gICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcblxuICAvLyBDbG9zZSBkcm9wZG93biBvbiBjbGljayBvdXRzaWRlXG4gIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgaWYgKGRyb3Bkb3duT3Blbikge1xuICAgICAgZHJvcGRvd25PcGVuID0gZmFsc2U7XG4gICAgICByZW5kZXJBY2NvdW50KCk7XG4gICAgfVxuICB9LCB7IG9uY2U6IHRydWUgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclVuYXV0aCgpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInVuYXV0aFwiPlxuICAgICAgPGgyPlRyYWNrIHdoYXQgbWF0dGVycyBvbiBhbnkgd2VicGFnZS48L2gyPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbFwiIGlkPVwiY29ubmVjdC1idG5cIj5Db25uZWN0IHlvdXIgYWNjb3VudDwvYnV0dG9uPlxuICAgICAgPHA+QWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/IFNpZ24gaW4gYWJvdmUuPC9wPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29ubmVjdC1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBzdGFydEF1dGhGbG93KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQXV0aEZhaWxlZCgpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInVuYXV0aFwiPlxuICAgICAgPGgyPkNvbm5lY3Rpb24gZmFpbGVkPC9oMj5cbiAgICAgIDxwPldlIGNvdWxkbid0IGNvbm5lY3QgdGhlIGV4dGVuc2lvbiB0byB5b3VyIGFjY291bnQuIFRoaXMgY2FuIGhhcHBlbiBpZiB5b3VyIGJyb3dzZXIgYmxvY2tlZCB0aGUgY29ubmVjdGlvbi48L3A+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1mdWxsXCIgaWQ9XCJyZXRyeS1jb25uZWN0LWJ0blwiPlRyeSBhZ2FpbjwvYnV0dG9uPlxuICAgICAgPHAgc3R5bGU9XCJtYXJnaW4tdG9wOiAxMnB4OyBmb250LXNpemU6IDEycHg7IG9wYWNpdHk6IDAuNztcIj5cbiAgICAgICAgVGlwOiB3aGVuIENocm9tZSBhc2tzIHRvIGFsbG93IGFjY2VzcyB0byBmdGMuYmQ3My5jb20sIGNsaWNrIDxzdHJvbmc+QWxsb3c8L3N0cm9uZz4uXG4gICAgICA8L3A+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyZXRyeS1jb25uZWN0LWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHN0YXJ0QXV0aEZsb3cpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzdGFydEF1dGhGbG93KCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zb2xlLmxvZyhUQUcsIFwic3RhcnRpbmcgYXV0aCBmbG93XCIpO1xuXG4gIC8vIENocm9tZSAxMjcrIHRyZWF0cyBob3N0X3Blcm1pc3Npb25zIGFzIG9wdGlvbmFsLlxuICAvLyBSZXF1ZXN0IHRoZSBwZXJtaXNzaW9uIHNvIHRoZSBhdXRoLXJlbGF5IGNvbnRlbnQgc2NyaXB0IGdldHMgaW5qZWN0ZWQuXG4gIGxldCBwZXJtaXNzaW9uR3JhbnRlZCA9IGZhbHNlO1xuICB0cnkge1xuICAgIGNvbnN0IG9yaWdpbiA9IG5ldyBVUkwoQkFTRV9VUkwpLm9yaWdpbjtcbiAgICBwZXJtaXNzaW9uR3JhbnRlZCA9IGF3YWl0IGNocm9tZS5wZXJtaXNzaW9ucy5jb250YWlucyh7IG9yaWdpbnM6IFtgJHtvcmlnaW59LypgXSB9KTtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwiaG9zdCBwZXJtaXNzaW9uIGFscmVhZHkgZ3JhbnRlZDpcIiwgcGVybWlzc2lvbkdyYW50ZWQpO1xuICAgIGlmICghcGVybWlzc2lvbkdyYW50ZWQpIHtcbiAgICAgIHBlcm1pc3Npb25HcmFudGVkID0gYXdhaXQgY2hyb21lLnBlcm1pc3Npb25zLnJlcXVlc3QoeyBvcmlnaW5zOiBbYCR7b3JpZ2lufS8qYF0gfSk7XG4gICAgICBjb25zb2xlLmxvZyhUQUcsIFwiaG9zdCBwZXJtaXNzaW9uIHJlcXVlc3QgcmVzdWx0OlwiLCBwZXJtaXNzaW9uR3JhbnRlZCk7XG4gICAgfVxuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oVEFHLCBcInBlcm1pc3Npb24gcmVxdWVzdCBlcnJvcjpcIiwgZXJyKTtcbiAgICAvLyBGYWxsYmFjayBhdXRoIHN0aWxsIHdvcmtzIHdpdGhvdXQgdGhlIHBlcm1pc3Npb25cbiAgfVxuXG4gIC8vIFJlY29yZCB0aGF0IHdlIHN0YXJ0ZWQgYW4gYXV0aCBhdHRlbXB0IHNvIGlmIHRoZSBwb3B1cFxuICAvLyByZS1vcGVucyB3aXRob3V0IGEgdG9rZW4sIHdlIGNhbiBzaG93IGFuIGVycm9yIGluc3RlYWQgb2ZcbiAgLy8gdGhlIGdlbmVyaWMgXCJDb25uZWN0IHlvdXIgYWNjb3VudFwiIHNjcmVlbi5cbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW0FVVEhfU1RBUlRFRF9LRVldOiBEYXRlLm5vdygpIH0pO1xuXG4gIGxldCB0YWI6IGNocm9tZS50YWJzLlRhYjtcbiAgdHJ5IHtcbiAgICB0YWIgPSBhd2FpdCBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6IGAke0JBU0VfVVJMfS9leHRlbnNpb24tYXV0aGAgfSk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUuZXJyb3IoVEFHLCBcImZhaWxlZCB0byBvcGVuIGF1dGggdGFiOlwiLCBlcnIpO1xuICAgIHN0YXRlID0gXCJhdXRoX2ZhaWxlZFwiO1xuICAgIHJlbmRlcigpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zb2xlLmxvZyhUQUcsIFwiYXV0aCB0YWIgY3JlYXRlZDpcIiwgdGFiLmlkKTtcblxuICAvLyBUZWxsIHRoZSBzZXJ2aWNlIHdvcmtlciB3aGljaCB0YWIgdG8gd2F0Y2hcbiAgaWYgKHRhYi5pZCkge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogTVNHLkFVVEhfVEFCX09QRU5FRCwgdGFiSWQ6IHRhYi5pZCB9KS5jYXRjaCgoZXJyKSA9PlxuICAgICAgY29uc29sZS53YXJuKFRBRywgXCJmYWlsZWQgdG8gbm90aWZ5IHNlcnZpY2Ugd29ya2VyIG9mIGF1dGggdGFiOlwiLCBlcnIpLFxuICAgICk7XG4gIH1cblxuICBzdGF0ZSA9IFwiY29ubmVjdGluZ1wiO1xuICByZW5kZXIoKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQ29ubmVjdGluZygpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImNvbm5lY3RpbmdcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyXCI+PC9kaXY+XG4gICAgICA8cD5Db25uZWN0aW5nLi4uPC9wPlxuICAgICAgPHA+V2FpdGluZyBmb3IgeW91IHRvIHNpZ24gaW4gYXQgRmV0Y2hUaGVDaGFuZ2UuPC9wPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGlkPVwiY2FuY2VsLWNvbm5lY3RcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDE2cHg7XCI+Q2FuY2VsPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYW5jZWwtY29ubmVjdFwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGFzeW5jICgpID0+IHtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoQVVUSF9TVEFSVEVEX0tFWSk7XG4gICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQXV0aGVudGljYXRlZCgpOiB2b2lkIHtcbiAgY29uc3QgdHJ1bmNhdGVkVXJsID0gY3VycmVudFRhYlVybC5sZW5ndGggPiA0NVxuICAgID8gY3VycmVudFRhYlVybC5zbGljZSgwLCA0NSkgKyBcIi4uLlwiXG4gICAgOiBjdXJyZW50VGFiVXJsO1xuXG4gIGxldCBjYW5kaWRhdGVzSHRtbCA9IFwiXCI7XG4gIGlmIChjYW5kaWRhdGVzLmxlbmd0aCA+IDApIHtcbiAgICBjYW5kaWRhdGVzSHRtbCA9IGBcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLWhlYWRlclwiPlN1Z2dlc3RlZCBlbGVtZW50czwvZGl2PlxuICAgICAgJHtjYW5kaWRhdGVzXG4gICAgICAgIC5tYXAoXG4gICAgICAgICAgKGMsIGkpID0+IGBcbiAgICAgICAgPGRpdiBjbGFzcz1cImNhbmRpZGF0ZVwiIGRhdGEtaWR4PVwiJHtpfVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY2FuZGlkYXRlLXRleHRcIj4ke2VzY2FwZUh0bWwoYy50ZXh0KX08L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJjYW5kaWRhdGUtc2VsZWN0b3JcIj4ke2VzY2FwZUh0bWwoYy5zZWxlY3Rvcil9PC9zcGFuPlxuICAgICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLXNtIGNhbmRpZGF0ZS10cmFja1wiIGRhdGEtaWR4PVwiJHtpfVwiPlRyYWNrIHRoaXM8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICBgXG4gICAgICAgIClcbiAgICAgICAgLmpvaW4oXCJcIil9XG4gICAgYDtcbiAgfVxuXG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjdXJyZW50LXVybFwiPjxzdHJvbmc+VHJhY2tpbmc6PC9zdHJvbmc+ICR7ZXNjYXBlSHRtbCh0cnVuY2F0ZWRVcmwpfTwvZGl2PlxuICAgICR7Y2FuZGlkYXRlc0h0bWx9XG4gICAgPGRpdiBjbGFzcz1cInNlY3Rpb24taGVhZGVyXCI+T3IgcGljayBtYW51YWxseTwvZGl2PlxuICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLWZ1bGxcIiBpZD1cInBpY2stYnRuXCI+UGljayBhbiBlbGVtZW50IG9uIHRoaXMgcGFnZTwvYnV0dG9uPlxuICAgIDxidXR0b24gY2xhc3M9XCJhZHZhbmNlZC10b2dnbGVcIiBpZD1cImFkdmFuY2VkLXRvZ2dsZVwiPiYjOTY2MjsgQWR2YW5jZWQgKENTUyBzZWxlY3Rvcik8L2J1dHRvbj5cbiAgICA8ZGl2IGNsYXNzPVwiYWR2YW5jZWQtY29udGVudFwiIGlkPVwiYWR2YW5jZWQtY29udGVudFwiPlxuICAgICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3M9XCJmb3JtLWlucHV0XCIgaWQ9XCJtYW51YWwtc2VsZWN0b3JcIiBwbGFjZWhvbGRlcj1cImUuZy4gLnByb2R1Y3QtcHJpY2VcIj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGlkPVwibWFudWFsLXRyYWNrLWJ0blwiPlVzZSB0aGlzIHNlbGVjdG9yPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgLy8gUGljayBlbGVtZW50IGJ1dHRvblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBpY2stYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogTVNHLlNUQVJUX1BJQ0tFUiwgdGFiSWQ6IGN1cnJlbnRUYWJJZCB9KTtcbiAgICBzdGF0ZSA9IFwicGlja2luZ1wiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcblxuICAvLyBDYW5kaWRhdGUgdHJhY2sgYnV0dG9uc1xuICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiLmNhbmRpZGF0ZS10cmFja1wiKS5mb3JFYWNoKChidG4pID0+IHtcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIChlKSA9PiB7XG4gICAgICBjb25zdCBpZHggPSBwYXJzZUludCgoZS50YXJnZXQgYXMgSFRNTEVsZW1lbnQpLmRhdGFzZXQuaWR4IHx8IFwiMFwiKTtcbiAgICAgIGNvbnN0IGMgPSBjYW5kaWRhdGVzW2lkeF07XG4gICAgICBpZiAoYykge1xuICAgICAgICBzZWxlY3Rpb24gPSB7XG4gICAgICAgICAgc2VsZWN0b3I6IGMuc2VsZWN0b3IsXG4gICAgICAgICAgY3VycmVudFZhbHVlOiBjLnRleHQsXG4gICAgICAgICAgdXJsOiBjdXJyZW50VGFiVXJsLFxuICAgICAgICAgIHBhZ2VUaXRsZTogY3VycmVudFRhYlRpdGxlLFxuICAgICAgICB9O1xuICAgICAgICBzdGF0ZSA9IFwiY29uZmlybVwiO1xuICAgICAgICByZW5kZXIoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gQWR2YW5jZWQgdG9nZ2xlXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWR2YW5jZWQtdG9nZ2xlXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhZHZhbmNlZC1jb250ZW50XCIpO1xuICAgIGVsPy5jbGFzc0xpc3QudG9nZ2xlKFwib3BlblwiKTtcbiAgfSk7XG5cbiAgLy8gTWFudWFsIHNlbGVjdG9yXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibWFudWFsLXRyYWNrLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjb25zdCBpbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibWFudWFsLXNlbGVjdG9yXCIpIGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gICAgY29uc3Qgc2VsZWN0b3IgPSBpbnB1dD8udmFsdWUudHJpbSgpO1xuICAgIGlmIChzZWxlY3Rvcikge1xuICAgICAgc2VsZWN0aW9uID0ge1xuICAgICAgICBzZWxlY3RvcixcbiAgICAgICAgY3VycmVudFZhbHVlOiBcIlwiLFxuICAgICAgICB1cmw6IGN1cnJlbnRUYWJVcmwsXG4gICAgICAgIHBhZ2VUaXRsZTogXCJcIixcbiAgICAgIH07XG4gICAgICBzdGF0ZSA9IFwiY29uZmlybVwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgfVxuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyUGlja2luZygpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInBpY2tlci1pbmZvXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiaWNvblwiPiYjMTI3OTE5OzwvZGl2PlxuICAgICAgPHA+PHN0cm9uZz5DbGljayBhbnkgZWxlbWVudCBvbiB0aGUgcGFnZSB0byB0cmFjayBpdC48L3N0cm9uZz48L3A+XG4gICAgICA8cD5QcmVzcyBFc2MgdG8gY2FuY2VsLjwvcD5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cImNhbmNlbC1waWNrXCIgc3R5bGU9XCJtYXJnaW4tdG9wOiAxNnB4O1wiPkNhbmNlbCBwaWNraW5nPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYW5jZWwtcGlja1wiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5DQU5DRUxfUElDS0VSLCB0YWJJZDogY3VycmVudFRhYklkIH0pO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJDb25maXJtKCk6IHZvaWQge1xuICBpZiAoIXNlbGVjdGlvbikgcmV0dXJuO1xuXG4gIGNvbnN0IHRpZXIgPSB1c2VySW5mbz8udGllciB8fCBcImZyZWVcIjtcbiAgY29uc3QgaG91cmx5RGlzYWJsZWQgPSB0aWVyID09PSBcImZyZWVcIjtcbiAgY29uc3QgZGVmYXVsdE5hbWUgPSAoc2VsZWN0aW9uLnBhZ2VUaXRsZSB8fCBcIlwiKS5zbGljZSgwLCAxMDApO1xuXG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjdXJyZW50LXVybFwiPjxzdHJvbmc+VHJhY2tpbmc6PC9zdHJvbmc+ICR7ZXNjYXBlSHRtbChcbiAgICAgIHNlbGVjdGlvbi51cmwubGVuZ3RoID4gNDUgPyBzZWxlY3Rpb24udXJsLnNsaWNlKDAsIDQ1KSArIFwiLi4uXCIgOiBzZWxlY3Rpb24udXJsXG4gICAgKX08L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiY29uZmlybS1jYXJkXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibGFiZWxcIj5FbGVtZW50IHNlbGVjdGVkPC9kaXY+XG4gICAgICAke1xuICAgICAgICBzZWxlY3Rpb24uY3VycmVudFZhbHVlXG4gICAgICAgICAgPyBgPGRpdiBjbGFzcz1cInZhbHVlXCI+Q3VycmVudGx5OiAke2VzY2FwZUh0bWwoc2VsZWN0aW9uLmN1cnJlbnRWYWx1ZS5zbGljZSgwLCAxMDApKX08L2Rpdj5gXG4gICAgICAgICAgOiBcIlwiXG4gICAgICB9XG4gICAgICA8ZGl2IGNsYXNzPVwic2VsZWN0b3JcIj4ke2VzY2FwZUh0bWwoc2VsZWN0aW9uLnNlbGVjdG9yKX08L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1sYWJlbFwiPk1vbml0b3IgbmFtZTwvbGFiZWw+XG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzcz1cImZvcm0taW5wdXRcIiBpZD1cIm1vbml0b3ItbmFtZVwiIHZhbHVlPVwiJHtlc2NhcGVBdHRyKGRlZmF1bHROYW1lKX1cIiBtYXhsZW5ndGg9XCIxMDBcIj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1sYWJlbFwiPkNoZWNrIGZyZXF1ZW5jeTwvbGFiZWw+XG4gICAgICA8ZGl2IGNsYXNzPVwicmFkaW8tZ3JvdXBcIj5cbiAgICAgICAgPGxhYmVsIGNsYXNzPVwicmFkaW8tbGFiZWxcIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT1cImZyZXF1ZW5jeVwiIHZhbHVlPVwiZGFpbHlcIiBjaGVja2VkPiBEYWlseVxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJyYWRpby1sYWJlbCAke2hvdXJseURpc2FibGVkID8gXCJkaXNhYmxlZFwiIDogXCJcIn1cIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT1cImZyZXF1ZW5jeVwiIHZhbHVlPVwiaG91cmx5XCIgJHtob3VybHlEaXNhYmxlZCA/IFwiZGlzYWJsZWRcIiA6IFwiXCJ9PlxuICAgICAgICAgIEhvdXJseVxuICAgICAgICAgICR7aG91cmx5RGlzYWJsZWQgPyAnPHNwYW4gY2xhc3M9XCJ0b29sdGlwLXRleHRcIj4oUHJvKyk8L3NwYW4+JyA6IFwiXCJ9XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiYnRuLXJvd1wiPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5XCIgaWQ9XCJwaWNrLWFnYWluLWJ0blwiPlBpY2sgYWdhaW48L2J1dHRvbj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiBpZD1cImNyZWF0ZS1idG5cIj5DcmVhdGUgbW9uaXRvcjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGljay1hZ2Fpbi1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgc2VsZWN0aW9uID0gbnVsbDtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5TVEFSVF9QSUNLRVIsIHRhYklkOiBjdXJyZW50VGFiSWQgfSk7XG4gICAgc3RhdGUgPSBcInBpY2tpbmdcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjcmVhdGUtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgY3JlYXRlTW9uaXRvcik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZU1vbml0b3IoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmICghc2VsZWN0aW9uIHx8IHN0YXRlID09PSBcImNyZWF0aW5nXCIpIHJldHVybjtcblxuICBjb25zdCBuYW1lSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1vbml0b3ItbmFtZVwiKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICBjb25zdCBuYW1lID0gbmFtZUlucHV0Py52YWx1ZS50cmltKCkgfHwgXCJVbnRpdGxlZCBtb25pdG9yXCI7XG4gIGNvbnN0IGZyZXF1ZW5jeSA9XG4gICAgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2lucHV0W25hbWU9XCJmcmVxdWVuY3lcIl06Y2hlY2tlZCcpIGFzIEhUTUxJbnB1dEVsZW1lbnQpPy52YWx1ZSB8fCBcImRhaWx5XCI7XG5cbiAgc3RhdGUgPSBcImNyZWF0aW5nXCI7XG4gIGNyZWF0ZWRNb25pdG9yTmFtZSA9IG5hbWU7XG4gIGNyZWF0ZWRNb25pdG9yVmFsdWUgPSBzZWxlY3Rpb24uY3VycmVudFZhbHVlO1xuICByZW5kZXIoKTtcblxuICB0cnkge1xuICAgIGNvbnN0IHRva2VuID0gYXdhaXQgZ2V0VG9rZW4oKTtcbiAgICBpZiAoIXRva2VuKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBcIk5vdCBhdXRoZW50aWNhdGVkLiBQbGVhc2UgcmVjb25uZWN0LlwiO1xuICAgICAgc3RhdGUgPSBcImVycm9yXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vYXBpL2V4dGVuc2lvbi9tb25pdG9yc2AsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIHVybDogc2VsZWN0aW9uLnVybCxcbiAgICAgICAgc2VsZWN0b3I6IHNlbGVjdGlvbi5zZWxlY3RvcixcbiAgICAgICAgZnJlcXVlbmN5LFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBpZiAocmVzLm9rKSB7XG4gICAgICBzdGF0ZSA9IFwic3VjY2Vzc1wiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbCk7XG5cbiAgICBpZiAoZGF0YT8uY29kZSA9PT0gXCJUSUVSX0xJTUlUX1JFQUNIRURcIikge1xuICAgICAgZXJyb3JNZXNzYWdlID0gYCR7ZGF0YS5tZXNzYWdlIHx8IGRhdGEuZXJyb3IgfHwgXCJNb25pdG9yIGxpbWl0IHJlYWNoZWQuXCJ9YDtcbiAgICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICAvLyBBZGQgdXBncmFkZSBsaW5rIGFmdGVyIHJlbmRlciB1c2luZyBET00gQVBJXG4gICAgICBjb25zdCBlcnJDb250YWluZXIgPSBjb250ZW50LnF1ZXJ5U2VsZWN0b3IoXCIuZXJyb3IgcFwiKTtcbiAgICAgIGlmIChlcnJDb250YWluZXIpIHtcbiAgICAgICAgZXJyQ29udGFpbmVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJiclwiKSk7XG4gICAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYVwiKTtcbiAgICAgICAgbGluay5ocmVmID0gYCR7QkFTRV9VUkx9L3ByaWNpbmdgO1xuICAgICAgICBsaW5rLnRhcmdldCA9IFwiX2JsYW5rXCI7XG4gICAgICAgIGxpbmsuc3R5bGUuY29sb3IgPSBcIiM2MzY2ZjFcIjtcbiAgICAgICAgbGluay50ZXh0Q29udGVudCA9IFwiVXBncmFkZSB5b3VyIHBsYW5cIjtcbiAgICAgICAgZXJyQ29udGFpbmVyLmFwcGVuZENoaWxkKGxpbmspO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGVycm9yTWVzc2FnZSA9IGRhdGE/Lm1lc3NhZ2UgfHwgZGF0YT8uZXJyb3IgfHwgYEZhaWxlZCAoJHtyZXMuc3RhdHVzfSlgO1xuICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgIHJlbmRlcigpO1xuICB9IGNhdGNoIHtcbiAgICBlcnJvck1lc3NhZ2UgPSBcIk5ldHdvcmsgZXJyb3IuIFBsZWFzZSB0cnkgYWdhaW4uXCI7XG4gICAgc3RhdGUgPSBcImVycm9yXCI7XG4gICAgcmVuZGVyKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyQ3JlYXRpbmcoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjb25uZWN0aW5nXCIgc3R5bGU9XCJwYWRkaW5nLXRvcDogNjRweDtcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyXCI+PC9kaXY+XG4gICAgICA8cD5DcmVhdGluZyBtb25pdG9yLi4uPC9wPlxuICAgIDwvZGl2PlxuICBgO1xufVxuXG5mdW5jdGlvbiByZW5kZXJTdWNjZXNzKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwic3VjY2Vzc1wiPlxuICAgICAgPGRpdiBjbGFzcz1cImljb25cIj4mIzEwMDAzOzwvZGl2PlxuICAgICAgPGgzPk1vbml0b3IgY3JlYXRlZCE8L2gzPlxuICAgICAgPHA+PHN0cm9uZz4ke2VzY2FwZUh0bWwoY3JlYXRlZE1vbml0b3JOYW1lKX08L3N0cm9uZz4gaXMgbm93IGJlaW5nIHdhdGNoZWQuPC9wPlxuICAgICAgJHtjcmVhdGVkTW9uaXRvclZhbHVlID8gYDxwPllvdSdsbCBiZSBub3RpZmllZCB3aGVuIDxzdHJvbmc+JHtlc2NhcGVIdG1sKGNyZWF0ZWRNb25pdG9yVmFsdWUuc2xpY2UoMCwgNjApKX08L3N0cm9uZz4gY2hhbmdlcy48L3A+YCA6IFwiXCJ9XG4gICAgICA8ZGl2IGNsYXNzPVwiYnRuLXJvd1wiIHN0eWxlPVwibWFyZ2luLXRvcDogMjRweDsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XCI+XG4gICAgICAgIDxhIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbVwiIGhyZWY9XCIke0JBU0VfVVJMfS9kYXNoYm9hcmRcIiB0YXJnZXQ9XCJfYmxhbmtcIj5WaWV3IGluIGRhc2hib2FyZDwvYT5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGlkPVwidHJhY2stYW5vdGhlci1idG5cIj5UcmFjayBhbm90aGVyPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRyYWNrLWFub3RoZXItYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHNlbGVjdGlvbiA9IG51bGw7XG4gICAgY2FuZGlkYXRlcyA9IFtdO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJFcnJvcigpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImVycm9yXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiaWNvblwiPiYjMTAwMDc7PC9kaXY+XG4gICAgICA8aDM+Q291bGRuJ3QgY3JlYXRlIG1vbml0b3I8L2gzPlxuICAgICAgPHA+JHtlc2NhcGVIdG1sKGVycm9yTWVzc2FnZSl9PC9wPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5XCIgaWQ9XCJ0cnktYWdhaW4tYnRuXCI+VHJ5IGFnYWluPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0cnktYWdhaW4tYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHN0YXRlID0gc2VsZWN0aW9uID8gXCJjb25maXJtXCIgOiBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gSGVscGVyc1xuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoc3RyOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICBkaXYudGV4dENvbnRlbnQgPSBzdHI7XG4gIHJldHVybiBkaXYuaW5uZXJIVE1MO1xufVxuXG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gU3RhcnRcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5pbml0KCk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFHTyxNQUFNLFdBQVc7QUFDakIsTUFBTSxvQkFBb0I7QUFDMUIsTUFBTSxtQkFBbUI7QUFDekIsTUFBTSxtQkFBbUI7QUFFekIsTUFBTSxNQUFNO0FBQUEsSUFDakIsY0FBYztBQUFBLElBQ2QsZUFBZTtBQUFBLElBQ2Ysa0JBQWtCO0FBQUEsSUFDbEIsZ0JBQWdCO0FBQUEsSUFDaEIsbUJBQW1CO0FBQUEsSUFDbkIscUJBQXFCO0FBQUEsSUFDckIsaUJBQWlCO0FBQUEsRUFDbkI7OztBQ2RBLGlCQUFzQixXQUFtQztBQUN2RCxVQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsbUJBQW1CLGdCQUFnQixDQUFDO0FBQ25GLFVBQU0sUUFBUSxPQUFPLGlCQUFpQjtBQUN0QyxVQUFNLFNBQVMsT0FBTyxnQkFBZ0I7QUFFdEMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFRLFFBQU87QUFFOUIsVUFBTSxXQUFXLElBQUksS0FBSyxNQUFNLEVBQUUsUUFBUTtBQUMxQyxRQUFJLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxXQUFXLEtBQUssSUFBSSxHQUFHO0FBQ3ZELFlBQU0sV0FBVztBQUNqQixhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU87QUFBQSxFQUNUO0FBU0EsaUJBQXNCLGFBQTRCO0FBQ2hELFVBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxDQUFDLG1CQUFtQixnQkFBZ0IsQ0FBQztBQUFBLEVBQ3pFO0FBRUEsaUJBQXNCLGVBQWlDO0FBQ3JELFVBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsV0FBTyxVQUFVO0FBQUEsRUFDbkI7OztBQ2hDTyxXQUFTLFdBQVcsS0FBcUI7QUFDOUMsV0FBTyxJQUFJLFFBQVEsTUFBTSxPQUFPLEVBQUUsUUFBUSxNQUFNLFFBQVEsRUFBRSxRQUFRLE1BQU0sT0FBTyxFQUFFLFFBQVEsTUFBTSxNQUFNLEVBQUUsUUFBUSxNQUFNLE1BQU07QUFBQSxFQUM3SDtBQUdBLE1BQU0sY0FBYyxDQUFDLFFBQVEsT0FBTyxPQUFPO0FBQ3BDLFdBQVMsYUFBYSxNQUFzQjtBQUNqRCxXQUFPLFlBQVksU0FBUyxJQUFJLElBQUksT0FBTztBQUFBLEVBQzdDOzs7QUNKQSxNQUFNLE1BQU07QUFvQ1osTUFBSSxRQUFvQjtBQUN4QixNQUFJLFdBQTRCO0FBQ2hDLE1BQUksWUFBOEI7QUFDbEMsTUFBSSxhQUEwQixDQUFDO0FBQy9CLE1BQUksZ0JBQWdCO0FBQ3BCLE1BQUksa0JBQWtCO0FBQ3RCLE1BQUksZUFBZTtBQUNuQixNQUFJLGVBQWU7QUFDbkIsTUFBSSxxQkFBcUI7QUFDekIsTUFBSSxzQkFBc0I7QUFDMUIsTUFBSSxlQUFlO0FBRW5CLE1BQU0sVUFBVSxTQUFTLGVBQWUsU0FBUztBQUNqRCxNQUFNLGNBQWMsU0FBUyxlQUFlLGNBQWM7QUFLMUQsTUFBTSxrQkFBa0I7QUFNeEIsTUFBSSxjQUFjO0FBRWxCLGlCQUFlLE9BQXNCO0FBQ25DLFFBQUksYUFBYTtBQUNmLGNBQVEsSUFBSSxLQUFLLGdDQUFnQztBQUNqRDtBQUFBLElBQ0Y7QUFDQSxrQkFBYztBQUNkLFlBQVEsSUFBSSxLQUFLLFlBQVk7QUFDN0IsUUFBSTtBQUdKLFlBQU0sQ0FBQyxHQUFHLElBQUksTUFBTSxPQUFPLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUMzRSxVQUFJLEtBQUs7QUFDUCx3QkFBZ0IsSUFBSSxPQUFPO0FBQzNCLDBCQUFrQixJQUFJLFNBQVM7QUFDL0IsdUJBQWUsSUFBSSxNQUFNO0FBQUEsTUFDM0I7QUFFQSxZQUFNLFFBQVEsTUFBTSxhQUFhO0FBQ2pDLFVBQUksQ0FBQyxPQUFPO0FBQ1YsZ0JBQVEsSUFBSSxLQUFLLDJCQUEyQjtBQUs1QyxjQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUM5RCxjQUFNLFlBQVksT0FBTyxPQUFPLGdCQUFnQixDQUFDO0FBQ2pELGNBQU0sVUFBVSxLQUFLLElBQUksSUFBSTtBQUM3QixZQUFJLE9BQU8sU0FBUyxTQUFTLEtBQUssVUFBVSxpQkFBaUI7QUFDM0QsY0FBSSxVQUFVLEtBQVE7QUFDcEIsb0JBQVEsSUFBSSxLQUFLLDhCQUE4QixLQUFLLE1BQU0sVUFBVSxHQUFJLEdBQUcsUUFBUTtBQUNuRixvQkFBUTtBQUFBLFVBQ1YsT0FBTztBQUNMLG9CQUFRLEtBQUssS0FBSyxxRUFBZ0U7QUFDbEYsb0JBQVE7QUFBQSxVQUNWO0FBQUEsUUFDRixPQUFPO0FBQ0wsa0JBQVE7QUFBQSxRQUNWO0FBRUEsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUdBLFlBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsVUFBSSxDQUFDLE9BQU87QUFDVixnQkFBUSxJQUFJLEtBQUssNkNBQTZDO0FBQzlELGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLGNBQVEsSUFBSSxLQUFLLGlDQUFpQztBQUNsRCxVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLFFBQVEseUJBQXlCO0FBQUEsVUFDMUQsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLEdBQUc7QUFBQSxRQUM5QyxDQUFDO0FBRUQsWUFBSSxDQUFDLElBQUksSUFBSTtBQUNYLGtCQUFRLEtBQUssS0FBSyxtQkFBbUIsSUFBSSxNQUFNO0FBQy9DLGdCQUFNLFdBQVc7QUFDakIsa0JBQVE7QUFDUixpQkFBTztBQUNQO0FBQUEsUUFDRjtBQUVBLG1CQUFXLE1BQU0sSUFBSSxLQUFLLEVBQUUsTUFBTSxNQUFNLElBQUk7QUFDNUMsWUFBSSxDQUFDLFlBQVksT0FBTyxTQUFTLFdBQVcsWUFBWSxPQUFPLFNBQVMsU0FBUyxVQUFVO0FBQ3pGLGtCQUFRLEtBQUssS0FBSyw4QkFBOEIsUUFBUTtBQUN4RCxnQkFBTSxXQUFXO0FBQ2pCLGtCQUFRO0FBQ1IsaUJBQU87QUFDUDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxnQkFBZ0IsU0FBUyxDQUFDO0FBRTNELGNBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxnQkFBZ0I7QUFDbEQsZ0JBQVE7QUFDUixnQkFBUSxJQUFJLEtBQUssb0JBQW9CLFNBQVMsS0FBSztBQUFBLE1BQ3JELFNBQVMsS0FBSztBQUNaLGdCQUFRLEtBQUssS0FBSyx5QkFBeUIsR0FBRztBQUU5QyxjQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUM5RCxjQUFNLElBQUksT0FBTztBQUNqQixZQUFJLEtBQUssT0FBTyxFQUFFLFdBQVcsWUFBWSxPQUFPLEVBQUUsU0FBUyxZQUFZLE9BQU8sRUFBRSxVQUFVLFVBQVU7QUFDbEcscUJBQVc7QUFDWCxrQkFBUTtBQUFBLFFBQ1YsT0FBTztBQUNMLGtCQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDUCxVQUFFO0FBQ0Esb0JBQWM7QUFBQSxJQUNoQjtBQUFBLEVBQ0Y7QUFNQSxTQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsWUFBWTtBQUNoRCxRQUFJLFFBQVEsU0FBUyxJQUFJLGtCQUFrQjtBQUN6QyxrQkFBWTtBQUFBLFFBQ1YsVUFBVSxRQUFRO0FBQUEsUUFDbEIsY0FBYyxRQUFRO0FBQUEsUUFDdEIsS0FBSyxRQUFRO0FBQUEsUUFDYixXQUFXLFFBQVE7QUFBQSxNQUNyQjtBQUNBLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVDtBQUVBLFFBQUksUUFBUSxTQUFTLElBQUksbUJBQW1CO0FBQzFDLG1CQUFhLFFBQVEsY0FBYyxDQUFDO0FBQ3BDLFVBQUksVUFBVSxtQkFBbUIsVUFBVSxXQUFXO0FBQ3BELGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFFBQUksUUFBUSxTQUFTLElBQUksZUFBZTtBQUN0QyxVQUFJLFVBQVUsV0FBVztBQUN2QixnQkFBUTtBQUNSLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFFBQUksUUFBUSxTQUFTLHFCQUFxQjtBQUV4QyxXQUFLO0FBQUEsSUFDUDtBQUFBLEVBQ0YsQ0FBQztBQUlELFNBQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxTQUFTLFNBQVM7QUFDdEQsUUFBSSxTQUFTLFFBQVM7QUFDdEIsUUFBSSxRQUFRLGlCQUFpQixHQUFHLGFBQWEsVUFBVSxnQkFBZ0IsVUFBVSxnQkFBZ0I7QUFDL0YsY0FBUSxJQUFJLEtBQUssOERBQThEO0FBQy9FLFdBQUs7QUFBQSxJQUNQO0FBQUEsRUFDRixDQUFDO0FBTUQsV0FBUyxTQUFlO0FBQ3RCLGtCQUFjO0FBRWQsWUFBUSxPQUFPO0FBQUEsTUFDYixLQUFLO0FBQ0gscUJBQWE7QUFDYjtBQUFBLE1BQ0YsS0FBSztBQUNILHlCQUFpQjtBQUNqQjtBQUFBLE1BQ0YsS0FBSztBQUNILHlCQUFpQjtBQUNqQjtBQUFBLE1BQ0YsS0FBSztBQUNILDRCQUFvQjtBQUNwQjtBQUFBLE1BQ0YsS0FBSztBQUNILHNCQUFjO0FBQ2Q7QUFBQSxNQUNGLEtBQUs7QUFDSCxzQkFBYztBQUNkO0FBQUEsTUFDRixLQUFLO0FBQ0gsdUJBQWU7QUFDZjtBQUFBLE1BQ0YsS0FBSztBQUNILHNCQUFjO0FBQ2Q7QUFBQSxNQUNGLEtBQUs7QUFDSCxvQkFBWTtBQUNaO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixRQUFJLENBQUMsVUFBVTtBQUNiLGtCQUFZLFlBQVk7QUFDeEI7QUFBQSxJQUNGO0FBRUEsZ0JBQVksWUFBWTtBQUFBO0FBQUEsUUFFbEIsV0FBVyxTQUFTLFNBQVMsV0FBVyxDQUFDO0FBQUE7QUFBQSxtQ0FFZCxlQUFlLEtBQUssUUFBUTtBQUFBO0FBQUEsVUFFckQsV0FBVyxTQUFTLFNBQVMsU0FBUyxNQUFNLENBQUM7QUFBQSx1Q0FDaEIsYUFBYSxTQUFTLElBQUksQ0FBQyxLQUFLLFdBQVcsU0FBUyxJQUFJLENBQUM7QUFBQTtBQUFBLHVDQUV6RCxRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFNN0MsYUFBUyxlQUFlLGdCQUFnQixHQUFHLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUMxRSxRQUFFLGdCQUFnQjtBQUNsQixxQkFBZSxDQUFDO0FBQ2hCLG9CQUFjO0FBQUEsSUFDaEIsQ0FBQztBQUVELGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9FLFlBQU0sV0FBVztBQUNqQixZQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8sZ0JBQWdCO0FBQ2xELGlCQUFXO0FBQ1gscUJBQWU7QUFDZixjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUdELGFBQVMsaUJBQWlCLFNBQVMsTUFBTTtBQUN2QyxVQUFJLGNBQWM7QUFDaEIsdUJBQWU7QUFDZixzQkFBYztBQUFBLE1BQ2hCO0FBQUEsSUFDRixHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFBQSxFQUNuQjtBQUVBLFdBQVMsZUFBcUI7QUFDNUIsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUXBCLGFBQVMsZUFBZSxhQUFhLEdBQUcsaUJBQWlCLFNBQVMsYUFBYTtBQUFBLEVBQ2pGO0FBRUEsV0FBUyxtQkFBeUI7QUFDaEMsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBV3BCLGFBQVMsZUFBZSxtQkFBbUIsR0FBRyxpQkFBaUIsU0FBUyxhQUFhO0FBQUEsRUFDdkY7QUFFQSxpQkFBZSxnQkFBK0I7QUFDNUMsWUFBUSxJQUFJLEtBQUssb0JBQW9CO0FBSXJDLFFBQUksb0JBQW9CO0FBQ3hCLFFBQUk7QUFDRixZQUFNLFNBQVMsSUFBSSxJQUFJLFFBQVEsRUFBRTtBQUNqQywwQkFBb0IsTUFBTSxPQUFPLFlBQVksU0FBUyxFQUFFLFNBQVMsQ0FBQyxHQUFHLE1BQU0sSUFBSSxFQUFFLENBQUM7QUFDbEYsY0FBUSxJQUFJLEtBQUssb0NBQW9DLGlCQUFpQjtBQUN0RSxVQUFJLENBQUMsbUJBQW1CO0FBQ3RCLDRCQUFvQixNQUFNLE9BQU8sWUFBWSxRQUFRLEVBQUUsU0FBUyxDQUFDLEdBQUcsTUFBTSxJQUFJLEVBQUUsQ0FBQztBQUNqRixnQkFBUSxJQUFJLEtBQUssbUNBQW1DLGlCQUFpQjtBQUFBLE1BQ3ZFO0FBQUEsSUFDRixTQUFTLEtBQUs7QUFDWixjQUFRLEtBQUssS0FBSyw2QkFBNkIsR0FBRztBQUFBLElBRXBEO0FBS0EsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLElBQUksRUFBRSxDQUFDO0FBRWpFLFFBQUk7QUFDSixRQUFJO0FBQ0YsWUFBTSxNQUFNLE9BQU8sS0FBSyxPQUFPLEVBQUUsS0FBSyxHQUFHLFFBQVEsa0JBQWtCLENBQUM7QUFBQSxJQUN0RSxTQUFTLEtBQUs7QUFDWixjQUFRLE1BQU0sS0FBSyw0QkFBNEIsR0FBRztBQUNsRCxjQUFRO0FBQ1IsYUFBTztBQUNQO0FBQUEsSUFDRjtBQUNBLFlBQVEsSUFBSSxLQUFLLHFCQUFxQixJQUFJLEVBQUU7QUFHNUMsUUFBSSxJQUFJLElBQUk7QUFDVixhQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sSUFBSSxpQkFBaUIsT0FBTyxJQUFJLEdBQUcsQ0FBQyxFQUFFO0FBQUEsUUFBTSxDQUFDLFFBQzlFLFFBQVEsS0FBSyxLQUFLLGdEQUFnRCxHQUFHO0FBQUEsTUFDdkU7QUFBQSxJQUNGO0FBRUEsWUFBUTtBQUNSLFdBQU87QUFBQSxFQUNUO0FBRUEsV0FBUyxtQkFBeUI7QUFDaEMsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFTcEIsYUFBUyxlQUFlLGdCQUFnQixHQUFHLGlCQUFpQixTQUFTLFlBQVk7QUFDL0UsWUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLGdCQUFnQjtBQUNsRCxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTLHNCQUE0QjtBQUNuQyxVQUFNLGVBQWUsY0FBYyxTQUFTLEtBQ3hDLGNBQWMsTUFBTSxHQUFHLEVBQUUsSUFBSSxRQUM3QjtBQUVKLFFBQUksaUJBQWlCO0FBQ3JCLFFBQUksV0FBVyxTQUFTLEdBQUc7QUFDekIsdUJBQWlCO0FBQUE7QUFBQSxRQUViLFdBQ0M7QUFBQSxRQUNDLENBQUMsR0FBRyxNQUFNO0FBQUEsMkNBQ3VCLENBQUM7QUFBQSx5Q0FDSCxXQUFXLEVBQUUsSUFBSSxDQUFDO0FBQUEsNkNBQ2QsV0FBVyxFQUFFLFFBQVEsQ0FBQztBQUFBLDZFQUNVLENBQUM7QUFBQTtBQUFBO0FBQUEsTUFHdEUsRUFDQyxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUEsSUFFZjtBQUVBLFlBQVEsWUFBWTtBQUFBLDBEQUNvQyxXQUFXLFlBQVksQ0FBQztBQUFBLE1BQzVFLGNBQWM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWFsQixhQUFTLGVBQWUsVUFBVSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDbkUsYUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLElBQUksY0FBYyxPQUFPLGFBQWEsQ0FBQztBQUMxRSxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUdELGFBQVMsaUJBQWlCLGtCQUFrQixFQUFFLFFBQVEsQ0FBQyxRQUFRO0FBQzdELFVBQUksaUJBQWlCLFNBQVMsQ0FBQyxNQUFNO0FBQ25DLGNBQU0sTUFBTSxTQUFVLEVBQUUsT0FBdUIsUUFBUSxPQUFPLEdBQUc7QUFDakUsY0FBTSxJQUFJLFdBQVcsR0FBRztBQUN4QixZQUFJLEdBQUc7QUFDTCxzQkFBWTtBQUFBLFlBQ1YsVUFBVSxFQUFFO0FBQUEsWUFDWixjQUFjLEVBQUU7QUFBQSxZQUNoQixLQUFLO0FBQUEsWUFDTCxXQUFXO0FBQUEsVUFDYjtBQUNBLGtCQUFRO0FBQ1IsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBR0QsYUFBUyxlQUFlLGlCQUFpQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDMUUsWUFBTSxLQUFLLFNBQVMsZUFBZSxrQkFBa0I7QUFDckQsVUFBSSxVQUFVLE9BQU8sTUFBTTtBQUFBLElBQzdCLENBQUM7QUFHRCxhQUFTLGVBQWUsa0JBQWtCLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUMzRSxZQUFNLFFBQVEsU0FBUyxlQUFlLGlCQUFpQjtBQUN2RCxZQUFNLFdBQVcsT0FBTyxNQUFNLEtBQUs7QUFDbkMsVUFBSSxVQUFVO0FBQ1osb0JBQVk7QUFBQSxVQUNWO0FBQUEsVUFDQSxjQUFjO0FBQUEsVUFDZCxLQUFLO0FBQUEsVUFDTCxXQUFXO0FBQUEsUUFDYjtBQUNBLGdCQUFRO0FBQ1IsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBUyxnQkFBc0I7QUFDN0IsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFTcEIsYUFBUyxlQUFlLGFBQWEsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3RFLGFBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxJQUFJLGVBQWUsT0FBTyxhQUFhLENBQUM7QUFDM0UsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBUyxnQkFBc0I7QUFDN0IsUUFBSSxDQUFDLFVBQVc7QUFFaEIsVUFBTSxPQUFPLFVBQVUsUUFBUTtBQUMvQixVQUFNLGlCQUFpQixTQUFTO0FBQ2hDLFVBQU0sZUFBZSxVQUFVLGFBQWEsSUFBSSxNQUFNLEdBQUcsR0FBRztBQUU1RCxZQUFRLFlBQVk7QUFBQSwwREFDb0M7QUFBQSxNQUNwRCxVQUFVLElBQUksU0FBUyxLQUFLLFVBQVUsSUFBSSxNQUFNLEdBQUcsRUFBRSxJQUFJLFFBQVEsVUFBVTtBQUFBLElBQzdFLENBQUM7QUFBQTtBQUFBO0FBQUEsUUFJRyxVQUFVLGVBQ04saUNBQWlDLFdBQVcsVUFBVSxhQUFhLE1BQU0sR0FBRyxHQUFHLENBQUMsQ0FBQyxXQUNqRixFQUNOO0FBQUEsOEJBQ3dCLFdBQVcsVUFBVSxRQUFRLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1RUFJVyxXQUFXLFdBQVcsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0NBUTFELGlCQUFpQixhQUFhLEVBQUU7QUFBQSxnRUFDSixpQkFBaUIsYUFBYSxFQUFFO0FBQUE7QUFBQSxZQUVwRixpQkFBaUIsNkNBQTZDLEVBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVTFFLGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3pFLGtCQUFZO0FBQ1osYUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLElBQUksY0FBYyxPQUFPLGFBQWEsQ0FBQztBQUMxRSxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUVELGFBQVMsZUFBZSxZQUFZLEdBQUcsaUJBQWlCLFNBQVMsYUFBYTtBQUFBLEVBQ2hGO0FBRUEsaUJBQWUsZ0JBQStCO0FBQzVDLFFBQUksQ0FBQyxhQUFhLFVBQVUsV0FBWTtBQUV4QyxVQUFNLFlBQVksU0FBUyxlQUFlLGNBQWM7QUFDeEQsVUFBTSxPQUFPLFdBQVcsTUFBTSxLQUFLLEtBQUs7QUFDeEMsVUFBTSxZQUNILFNBQVMsY0FBYyxpQ0FBaUMsR0FBd0IsU0FBUztBQUU1RixZQUFRO0FBQ1IseUJBQXFCO0FBQ3JCLDBCQUFzQixVQUFVO0FBQ2hDLFdBQU87QUFFUCxRQUFJO0FBQ0YsWUFBTSxRQUFRLE1BQU0sU0FBUztBQUM3QixVQUFJLENBQUMsT0FBTztBQUNWLHVCQUFlO0FBQ2YsZ0JBQVE7QUFDUixlQUFPO0FBQ1A7QUFBQSxNQUNGO0FBRUEsWUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLFFBQVEsMkJBQTJCO0FBQUEsUUFDNUQsUUFBUTtBQUFBLFFBQ1IsU0FBUztBQUFBLFVBQ1AsZ0JBQWdCO0FBQUEsVUFDaEIsZUFBZSxVQUFVLEtBQUs7QUFBQSxRQUNoQztBQUFBLFFBQ0EsTUFBTSxLQUFLLFVBQVU7QUFBQSxVQUNuQjtBQUFBLFVBQ0EsS0FBSyxVQUFVO0FBQUEsVUFDZixVQUFVLFVBQVU7QUFBQSxVQUNwQjtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUVELFVBQUksSUFBSSxJQUFJO0FBQ1YsZ0JBQVE7QUFDUixlQUFPO0FBQ1A7QUFBQSxNQUNGO0FBRUEsWUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLLEVBQUUsTUFBTSxNQUFNLElBQUk7QUFFOUMsVUFBSSxNQUFNLFNBQVMsc0JBQXNCO0FBQ3ZDLHVCQUFlLEdBQUcsS0FBSyxXQUFXLEtBQUssU0FBUyx3QkFBd0I7QUFDeEUsZ0JBQVE7QUFDUixlQUFPO0FBRVAsY0FBTSxlQUFlLFFBQVEsY0FBYyxVQUFVO0FBQ3JELFlBQUksY0FBYztBQUNoQix1QkFBYSxZQUFZLFNBQVMsY0FBYyxJQUFJLENBQUM7QUFDckQsZ0JBQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztBQUN2QyxlQUFLLE9BQU8sR0FBRyxRQUFRO0FBQ3ZCLGVBQUssU0FBUztBQUNkLGVBQUssTUFBTSxRQUFRO0FBQ25CLGVBQUssY0FBYztBQUNuQix1QkFBYSxZQUFZLElBQUk7QUFBQSxRQUMvQjtBQUNBO0FBQUEsTUFDRjtBQUVBLHFCQUFlLE1BQU0sV0FBVyxNQUFNLFNBQVMsV0FBVyxJQUFJLE1BQU07QUFDcEUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULFFBQVE7QUFDTixxQkFBZTtBQUNmLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGlCQUF1QjtBQUM5QixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNdEI7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFJSCxXQUFXLGtCQUFrQixDQUFDO0FBQUEsUUFDekMsc0JBQXNCLHNDQUFzQyxXQUFXLG9CQUFvQixNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsMkJBQTJCLEVBQUU7QUFBQTtBQUFBLGtEQUUzRixRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFNeEQsYUFBUyxlQUFlLG1CQUFtQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDNUUsa0JBQVk7QUFDWixtQkFBYSxDQUFDO0FBQ2QsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBUyxjQUFvQjtBQUMzQixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlYLFdBQVcsWUFBWSxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBS2pDLGFBQVMsZUFBZSxlQUFlLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN4RSxjQUFRLFlBQVksWUFBWTtBQUNoQyxhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQU1BLFdBQVMsV0FBVyxLQUFxQjtBQUN2QyxVQUFNLE1BQU0sU0FBUyxjQUFjLEtBQUs7QUFDeEMsUUFBSSxjQUFjO0FBQ2xCLFdBQU8sSUFBSTtBQUFBLEVBQ2I7QUFPQSxPQUFLOyIsCiAgIm5hbWVzIjogW10KfQo=
