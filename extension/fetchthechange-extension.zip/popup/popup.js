"use strict";
(() => {
  // src/shared/constants.ts
  var BASE_URL = "https://ftc.bd73.com";
  var TOKEN_STORAGE_KEY = "ftc_extension_token";
  var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
  var AUTH_STARTED_KEY = "ftc_auth_started_at";
  var PENDING_SELECTION_KEY = "ftc_pending_selection";
  var MSG = {
    START_PICKER: "FTC_START_PICKER",
    CANCEL_PICKER: "FTC_CANCEL_PICKER",
    ELEMENT_SELECTED: "FTC_ELEMENT_SELECTED",
    GET_CANDIDATES: "FTC_GET_CANDIDATES",
    CANDIDATES_RESULT: "FTC_CANDIDATES_RESULT",
    FTC_EXTENSION_TOKEN: "FTC_EXTENSION_TOKEN",
    AUTH_TAB_OPENED: "FTC_AUTH_TAB_OPENED"
  };

  // src/auth/token.ts
  async function getToken() {
    const result = await chrome.storage.local.get([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
    const token = result[TOKEN_STORAGE_KEY];
    const expiry = result[TOKEN_EXPIRY_KEY];
    if (!token || !expiry) return null;
    const expiryMs = new Date(expiry).getTime();
    if (!Number.isFinite(expiryMs) || expiryMs < Date.now()) {
      await clearToken();
      return null;
    }
    return token;
  }
  async function clearToken() {
    await chrome.storage.local.remove([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
  }
  async function isTokenValid() {
    const token = await getToken();
    return token !== null;
  }

  // src/popup/utils.ts
  function escapeAttr(str) {
    return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  var KNOWN_TIERS = ["free", "pro", "power"];
  function sanitizeTier(tier) {
    return KNOWN_TIERS.includes(tier) ? tier : "free";
  }

  // src/popup/popup.ts
  var TAG = "[FTC:popup]";
  var state = "unauthenticated";
  var userInfo = null;
  var selection = null;
  var candidates = [];
  var currentTabUrl = "";
  var currentTabTitle = "";
  var currentTabId = 0;
  var errorMessage = "";
  var createdMonitorName = "";
  var createdMonitorValue = "";
  var dropdownOpen = false;
  var content = document.getElementById("content");
  var accountArea = document.getElementById("account-area");
  var AUTH_TIMEOUT_MS = 12e4;
  var initRunning = false;
  var initPending = false;
  async function init() {
    if (initRunning) {
      initPending = true;
      console.log(TAG, "init already running, queueing rerun");
      return;
    }
    initRunning = true;
    console.log(TAG, "init start");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab) {
        currentTabUrl = tab.url || "";
        currentTabTitle = tab.title || "";
        currentTabId = tab.id || 0;
      }
      const valid = await isTokenValid();
      if (!valid) {
        console.log(TAG, "no valid token in storage");
        const stored = await chrome.storage.local.get(AUTH_STARTED_KEY);
        const startedAt = Number(stored[AUTH_STARTED_KEY]);
        const elapsed = Date.now() - startedAt;
        if (Number.isFinite(startedAt) && elapsed < AUTH_TIMEOUT_MS) {
          if (elapsed < 3e4) {
            console.log(TAG, "auth attempt in progress (", Math.round(elapsed / 1e3), "s ago)");
            state = "connecting";
          } else {
            console.warn(TAG, "recent auth attempt found but no token \u2014 showing failure state");
            state = "auth_failed";
          }
        } else {
          state = "unauthenticated";
        }
        render();
        return;
      }
      const token = await getToken();
      if (!token) {
        console.log(TAG, "getToken returned null despite isTokenValid");
        state = "unauthenticated";
        render();
        return;
      }
      console.log(TAG, "verifying token with backend...");
      try {
        const res = await fetch(`${BASE_URL}/api/extension/verify`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) {
          console.warn(TAG, "verify returned", res.status);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        userInfo = await res.json().catch(() => null);
        if (!userInfo || typeof userInfo.userId !== "string" || typeof userInfo.tier !== "string") {
          console.warn(TAG, "verify response malformed:", userInfo);
          await clearToken();
          state = "unauthenticated";
          render();
          return;
        }
        await chrome.storage.local.set({ cachedUserInfo: userInfo });
        await chrome.storage.local.remove(AUTH_STARTED_KEY);
        state = "authenticated";
        console.log(TAG, "authenticated as", userInfo.email);
      } catch (err) {
        console.warn(TAG, "verify network error:", err);
        const cached = await chrome.storage.local.get("cachedUserInfo");
        const c = cached.cachedUserInfo;
        if (c && typeof c.userId === "string" && typeof c.tier === "string" && typeof c.email === "string") {
          userInfo = c;
          state = "authenticated";
        } else {
          state = "unauthenticated";
        }
      }
      if (state === "authenticated") {
        const pending = await chrome.storage.local.get(PENDING_SELECTION_KEY);
        const stored = pending[PENDING_SELECTION_KEY];
        if (stored && typeof stored.selector === "string") {
          const age = stored.timestamp ? Date.now() - stored.timestamp : Infinity;
          await chrome.storage.local.remove(PENDING_SELECTION_KEY);
          if (age < 6e5) {
            console.log(TAG, "pending selection found in storage, jumping to confirm");
            selection = {
              selector: stored.selector,
              currentValue: typeof stored.currentValue === "string" ? stored.currentValue : "",
              url: typeof stored.url === "string" ? stored.url : currentTabUrl,
              pageTitle: typeof stored.pageTitle === "string" ? stored.pageTitle : currentTabTitle
            };
            state = "confirm";
            render();
            return;
          } else {
            console.log(TAG, "pending selection too old (", Math.round(age / 1e3), "s), discarding");
          }
        }
      }
      render();
    } finally {
      initRunning = false;
      if (initPending) {
        initPending = false;
        if (state !== "confirm") {
          void init();
        }
      }
    }
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === MSG.ELEMENT_SELECTED) {
      const sel = typeof message.selector === "string" ? message.selector.trim().slice(0, 500) : "";
      if (!sel) return;
      selection = {
        selector: sel,
        currentValue: typeof message.currentValue === "string" ? message.currentValue.slice(0, 500) : "",
        url: typeof message.url === "string" ? message.url.slice(0, 2e3) : currentTabUrl,
        pageTitle: typeof message.pageTitle === "string" ? message.pageTitle.slice(0, 200) : currentTabTitle
      };
      state = "confirm";
      render();
    }
    if (message.type === MSG.CANDIDATES_RESULT) {
      candidates = message.candidates || [];
      if (state === "authenticated" || state === "picking") {
        render();
      }
    }
    if (message.type === MSG.CANCEL_PICKER) {
      if (state === "picking") {
        state = "authenticated";
        render();
      }
    }
    if (message.type === "FTC_AUTH_COMPLETE") {
      init();
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[TOKEN_STORAGE_KEY]?.newValue) {
      console.log(TAG, "token appeared in storage (direct write), re-initialising...");
      void init();
    }
    if (changes[PENDING_SELECTION_KEY]?.newValue && state !== "confirm") {
      console.log(TAG, "pending selection appeared in storage, re-initialising...");
      void init();
    }
  });
  function render() {
    renderAccount();
    switch (state) {
      case "unauthenticated":
        renderUnauth();
        break;
      case "connecting":
        renderConnecting();
        break;
      case "auth_failed":
        renderAuthFailed();
        break;
      case "authenticated":
        renderAuthenticated();
        break;
      case "picking":
        renderPicking();
        break;
      case "confirm":
        renderConfirm();
        break;
      case "creating":
        renderCreating();
        break;
      case "success":
        renderSuccess();
        break;
      case "error":
        renderError();
        break;
    }
  }
  function renderAccount() {
    if (!userInfo) {
      accountArea.innerHTML = "";
      return;
    }
    accountArea.innerHTML = `
    <button class="account-btn" id="account-toggle">
      ${escapeHtml(userInfo.email || "Connected")} &#9662;
    </button>
    <div class="account-dropdown ${dropdownOpen ? "" : "hidden"}" id="account-dropdown">
      <div class="dropdown-email">
        ${escapeHtml(userInfo.email || userInfo.userId)}
        <span class="tier-badge tier-${sanitizeTier(userInfo.tier)}">${escapeHtml(userInfo.tier)}</span>
      </div>
      <a class="dropdown-item" href="${BASE_URL}/dashboard" target="_blank">Open dashboard</a>
      <div class="dropdown-divider"></div>
      <button class="dropdown-item" id="disconnect-btn">Disconnect</button>
    </div>
  `;
    document.getElementById("account-toggle")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdownOpen = !dropdownOpen;
      renderAccount();
    });
    document.getElementById("disconnect-btn")?.addEventListener("click", async () => {
      await clearToken();
      await chrome.storage.local.remove("cachedUserInfo");
      userInfo = null;
      dropdownOpen = false;
      state = "unauthenticated";
      render();
    });
    document.addEventListener("click", () => {
      if (dropdownOpen) {
        dropdownOpen = false;
        renderAccount();
      }
    }, { once: true });
  }
  function renderUnauth() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Track what matters on any webpage.</h2>
      <button class="btn btn-primary btn-full" id="connect-btn">Connect your account</button>
      <p>Already have an account? Sign in above.</p>
    </div>
  `;
    document.getElementById("connect-btn")?.addEventListener("click", startAuthFlow);
  }
  function renderAuthFailed() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Connection failed</h2>
      <p>We couldn't connect the extension to your account. This can happen if your browser blocked the connection.</p>
      <button class="btn btn-primary btn-full" id="retry-connect-btn">Try again</button>
      <p style="margin-top: 12px; font-size: 12px; opacity: 0.7;">
        Tip: when Chrome asks to allow access to ftc.bd73.com, click <strong>Allow</strong>.
      </p>
    </div>
  `;
    document.getElementById("retry-connect-btn")?.addEventListener("click", startAuthFlow);
  }
  async function startAuthFlow() {
    console.log(TAG, "starting auth flow");
    let permissionGranted = false;
    try {
      const origin = new URL(BASE_URL).origin;
      permissionGranted = await chrome.permissions.contains({ origins: [`${origin}/*`] });
      console.log(TAG, "host permission already granted:", permissionGranted);
      if (!permissionGranted) {
        permissionGranted = await chrome.permissions.request({ origins: [`${origin}/*`] });
        console.log(TAG, "host permission request result:", permissionGranted);
      }
    } catch (err) {
      console.warn(TAG, "permission request error:", err);
    }
    await chrome.storage.local.set({ [AUTH_STARTED_KEY]: Date.now() });
    let tab;
    try {
      tab = await chrome.tabs.create({ url: `${BASE_URL}/extension-auth` });
    } catch (err) {
      console.error(TAG, "failed to open auth tab:", err);
      state = "auth_failed";
      render();
      return;
    }
    console.log(TAG, "auth tab created:", tab.id);
    if (tab.id) {
      chrome.runtime.sendMessage({ type: MSG.AUTH_TAB_OPENED, tabId: tab.id }).catch(
        (err) => console.warn(TAG, "failed to notify service worker of auth tab:", err)
      );
    }
    state = "connecting";
    render();
  }
  function renderConnecting() {
    content.innerHTML = `
    <div class="connecting">
      <div class="spinner"></div>
      <p>Connecting...</p>
      <p>Waiting for you to sign in at FetchTheChange.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-connect" style="margin-top: 16px;">Cancel</button>
    </div>
  `;
    document.getElementById("cancel-connect")?.addEventListener("click", async () => {
      await chrome.storage.local.remove(AUTH_STARTED_KEY);
      state = "unauthenticated";
      render();
    });
  }
  function renderAuthenticated() {
    const truncatedUrl = currentTabUrl.length > 45 ? currentTabUrl.slice(0, 45) + "..." : currentTabUrl;
    let candidatesHtml = "";
    if (candidates.length > 0) {
      candidatesHtml = `
      <div class="section-header">Suggested elements</div>
      ${candidates.map(
        (c, i) => `
        <div class="candidate" data-idx="${i}">
          <span class="candidate-text">${escapeHtml(c.text)}</span>
          <span class="candidate-selector">${escapeHtml(c.selector)}</span>
          <button class="btn btn-primary btn-sm candidate-track" data-idx="${i}">Track this</button>
        </div>
      `
      ).join("")}
    `;
    }
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(truncatedUrl)}</div>
    ${candidatesHtml}
    <div class="section-header">Or pick manually</div>
    <button class="btn btn-primary btn-full" id="pick-btn">Pick an element on this page</button>
    <button class="advanced-toggle" id="advanced-toggle">&#9662; Advanced (CSS selector)</button>
    <div class="advanced-content" id="advanced-content">
      <div class="form-group">
        <input type="text" class="form-input" id="manual-selector" placeholder="e.g. .product-price">
      </div>
      <button class="btn btn-secondary btn-sm" id="manual-track-btn">Use this selector</button>
    </div>
  `;
    document.getElementById("pick-btn")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.querySelectorAll(".candidate-track").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const idx = parseInt(e.target.dataset.idx || "0");
        const c = candidates[idx];
        if (c) {
          selection = {
            selector: c.selector,
            currentValue: c.text,
            url: currentTabUrl,
            pageTitle: currentTabTitle
          };
          state = "confirm";
          render();
        }
      });
    });
    document.getElementById("advanced-toggle")?.addEventListener("click", () => {
      const el = document.getElementById("advanced-content");
      el?.classList.toggle("open");
    });
    document.getElementById("manual-track-btn")?.addEventListener("click", () => {
      const input = document.getElementById("manual-selector");
      const selector = input?.value.trim();
      if (selector) {
        selection = {
          selector,
          currentValue: "",
          url: currentTabUrl,
          pageTitle: ""
        };
        state = "confirm";
        render();
      }
    });
  }
  function renderPicking() {
    content.innerHTML = `
    <div class="picker-info">
      <div class="icon">&#127919;</div>
      <p><strong>Click any element on the page to track it.</strong></p>
      <p>Press Esc to cancel.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-pick" style="margin-top: 16px;">Cancel picking</button>
    </div>
  `;
    document.getElementById("cancel-pick")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.CANCEL_PICKER, tabId: currentTabId });
      state = "authenticated";
      render();
    });
  }
  function renderConfirm() {
    if (!selection) return;
    const tier = userInfo?.tier || "free";
    const hourlyDisabled = tier === "free";
    const defaultName = (selection.pageTitle || "").slice(0, 100);
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(
      selection.url.length > 45 ? selection.url.slice(0, 45) + "..." : selection.url
    )}</div>
    <div class="confirm-card">
      <div class="label">Element selected</div>
      ${selection.currentValue ? `<div class="value">Currently: ${escapeHtml(selection.currentValue.slice(0, 100))}</div>` : ""}
      <div class="selector">${escapeHtml(selection.selector)}</div>
    </div>
    <div class="form-group">
      <label class="form-label">Monitor name</label>
      <input type="text" class="form-input" id="monitor-name" value="${escapeAttr(defaultName)}" maxlength="100">
    </div>
    <div class="form-group">
      <label class="form-label">Check frequency</label>
      <div class="radio-group">
        <label class="radio-label">
          <input type="radio" name="frequency" value="daily" checked> Daily
        </label>
        <label class="radio-label ${hourlyDisabled ? "disabled" : ""}">
          <input type="radio" name="frequency" value="hourly" ${hourlyDisabled ? "disabled" : ""}>
          Hourly
          ${hourlyDisabled ? '<span class="tooltip-text">(Pro+)</span>' : ""}
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="pick-again-btn"
        ${selection.url && selection.url !== currentTabUrl ? 'disabled title="Switch to the original tab to pick again"' : ""}>Pick again</button>
      <button class="btn btn-primary" id="create-btn">Create monitor</button>
    </div>
  `;
    document.getElementById("pick-again-btn")?.addEventListener("click", () => {
      selection = null;
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.getElementById("create-btn")?.addEventListener("click", createMonitor);
  }
  async function createMonitor() {
    if (!selection || state === "creating") return;
    const nameInput = document.getElementById("monitor-name");
    const name = nameInput?.value.trim() || "Untitled monitor";
    const frequency = document.querySelector('input[name="frequency"]:checked')?.value || "daily";
    state = "creating";
    createdMonitorName = name;
    createdMonitorValue = selection.currentValue;
    render();
    try {
      const token = await getToken();
      if (!token) {
        errorMessage = "Not authenticated. Please reconnect.";
        state = "error";
        render();
        return;
      }
      const res = await fetch(`${BASE_URL}/api/extension/monitors`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name,
          url: selection.url,
          selector: selection.selector,
          frequency
        })
      });
      if (res.ok) {
        state = "success";
        render();
        return;
      }
      const data = await res.json().catch(() => null);
      if (data?.code === "TIER_LIMIT_REACHED") {
        errorMessage = `${data.message || data.error || "Monitor limit reached."}`;
        state = "error";
        render();
        const errContainer = content.querySelector(".error p");
        if (errContainer) {
          errContainer.appendChild(document.createElement("br"));
          const link = document.createElement("a");
          link.href = `${BASE_URL}/pricing`;
          link.target = "_blank";
          link.style.color = "#6366f1";
          link.textContent = "Upgrade your plan";
          errContainer.appendChild(link);
        }
        return;
      }
      errorMessage = data?.message || data?.error || `Failed (${res.status})`;
      state = "error";
      render();
    } catch {
      errorMessage = "Network error. Please try again.";
      state = "error";
      render();
    }
  }
  function renderCreating() {
    content.innerHTML = `
    <div class="connecting" style="padding-top: 64px;">
      <div class="spinner"></div>
      <p>Creating monitor...</p>
    </div>
  `;
  }
  function renderSuccess() {
    content.innerHTML = `
    <div class="success">
      <div class="icon">&#10003;</div>
      <h3>Monitor created!</h3>
      <p><strong>${escapeHtml(createdMonitorName)}</strong> is now being watched.</p>
      ${createdMonitorValue ? `<p>You'll be notified when <strong>${escapeHtml(createdMonitorValue.slice(0, 60))}</strong> changes.</p>` : ""}
      <div class="btn-row" style="margin-top: 24px; justify-content: center;">
        <a class="btn btn-primary btn-sm" href="${BASE_URL}/dashboard" target="_blank">View in dashboard</a>
        <button class="btn btn-secondary btn-sm" id="track-another-btn">Track another</button>
      </div>
    </div>
  `;
    document.getElementById("track-another-btn")?.addEventListener("click", () => {
      selection = null;
      candidates = [];
      state = "authenticated";
      render();
    });
  }
  function renderError() {
    content.innerHTML = `
    <div class="error">
      <div class="icon">&#10007;</div>
      <h3>Couldn't create monitor</h3>
      <p>${escapeHtml(errorMessage)}</p>
      <button class="btn btn-secondary" id="try-again-btn">Try again</button>
    </div>
  `;
    document.getElementById("try-again-btn")?.addEventListener("click", () => {
      state = selection ? "confirm" : "authenticated";
      render();
    });
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
  init();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL3NoYXJlZC9jb25zdGFudHMudHMiLCAiLi4vLi4vc3JjL2F1dGgvdG9rZW4udHMiLCAiLi4vLi4vc3JjL3BvcHVwL3V0aWxzLnRzIiwgIi4uLy4uL3NyYy9wb3B1cC9wb3B1cC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLy8gQkFTRV9VUkwgaXMgaW5qZWN0ZWQgYXQgYnVpbGQgdGltZSB2aWEgZXNidWlsZCBkZWZpbmUuXG4vLyBTZXQgQkFTRV9VUkwgZW52IHZhciB0byBvdmVycmlkZSAoZGVmYXVsdDogaHR0cHM6Ly9mdGMuYmQ3My5jb20pXG5kZWNsYXJlIGNvbnN0IEJBU0VfVVJMX0lOSkVDVEVEOiBzdHJpbmc7XG5leHBvcnQgY29uc3QgQkFTRV9VUkwgPSBCQVNFX1VSTF9JTkpFQ1RFRDtcbmV4cG9ydCBjb25zdCBUT0tFTl9TVE9SQUdFX0tFWSA9IFwiZnRjX2V4dGVuc2lvbl90b2tlblwiO1xuZXhwb3J0IGNvbnN0IFRPS0VOX0VYUElSWV9LRVkgPSBcImZ0Y19leHRlbnNpb25fdG9rZW5fZXhwaXJ5XCI7XG5leHBvcnQgY29uc3QgQVVUSF9TVEFSVEVEX0tFWSA9IFwiZnRjX2F1dGhfc3RhcnRlZF9hdFwiO1xuZXhwb3J0IGNvbnN0IEFVVEhfVEFCX0lEX0tFWSA9IFwiZnRjX2F1dGhfdGFiX2lkXCI7XG5leHBvcnQgY29uc3QgUEVORElOR19TRUxFQ1RJT05fS0VZID0gXCJmdGNfcGVuZGluZ19zZWxlY3Rpb25cIjtcblxuZXhwb3J0IGNvbnN0IE1TRyA9IHtcbiAgU1RBUlRfUElDS0VSOiBcIkZUQ19TVEFSVF9QSUNLRVJcIixcbiAgQ0FOQ0VMX1BJQ0tFUjogXCJGVENfQ0FOQ0VMX1BJQ0tFUlwiLFxuICBFTEVNRU5UX1NFTEVDVEVEOiBcIkZUQ19FTEVNRU5UX1NFTEVDVEVEXCIsXG4gIEdFVF9DQU5ESURBVEVTOiBcIkZUQ19HRVRfQ0FORElEQVRFU1wiLFxuICBDQU5ESURBVEVTX1JFU1VMVDogXCJGVENfQ0FORElEQVRFU19SRVNVTFRcIixcbiAgRlRDX0VYVEVOU0lPTl9UT0tFTjogXCJGVENfRVhURU5TSU9OX1RPS0VOXCIsXG4gIEFVVEhfVEFCX09QRU5FRDogXCJGVENfQVVUSF9UQUJfT1BFTkVEXCIsXG59IGFzIGNvbnN0O1xuIiwgImltcG9ydCB7IFRPS0VOX1NUT1JBR0VfS0VZLCBUT0tFTl9FWFBJUllfS0VZIH0gZnJvbSBcIi4uL3NoYXJlZC9jb25zdGFudHNcIjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRva2VuKCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1RPS0VOX1NUT1JBR0VfS0VZLCBUT0tFTl9FWFBJUllfS0VZXSk7XG4gIGNvbnN0IHRva2VuID0gcmVzdWx0W1RPS0VOX1NUT1JBR0VfS0VZXTtcbiAgY29uc3QgZXhwaXJ5ID0gcmVzdWx0W1RPS0VOX0VYUElSWV9LRVldO1xuXG4gIGlmICghdG9rZW4gfHwgIWV4cGlyeSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgZXhwaXJ5TXMgPSBuZXcgRGF0ZShleHBpcnkpLmdldFRpbWUoKTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoZXhwaXJ5TXMpIHx8IGV4cGlyeU1zIDwgRGF0ZS5ub3coKSkge1xuICAgIGF3YWl0IGNsZWFyVG9rZW4oKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiB0b2tlbjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFRva2VuKHRva2VuOiBzdHJpbmcsIGV4cGlyZXNBdDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgW1RPS0VOX1NUT1JBR0VfS0VZXTogdG9rZW4sXG4gICAgW1RPS0VOX0VYUElSWV9LRVldOiBleHBpcmVzQXQsXG4gIH0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJUb2tlbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFtUT0tFTl9TVE9SQUdFX0tFWSwgVE9LRU5fRVhQSVJZX0tFWV0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNUb2tlblZhbGlkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIHJldHVybiB0b2tlbiAhPT0gbnVsbDtcbn1cbiIsICJleHBvcnQgZnVuY3Rpb24gZXNjYXBlQXR0cihzdHI6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzdHIucmVwbGFjZSgvJi9nLCBcIiZhbXA7XCIpLnJlcGxhY2UoL1wiL2csIFwiJnF1b3Q7XCIpLnJlcGxhY2UoLycvZywgXCImIzM5O1wiKS5yZXBsYWNlKC88L2csIFwiJmx0O1wiKS5yZXBsYWNlKC8+L2csIFwiJmd0O1wiKTtcbn1cblxuLy8gS2VlcCBpbiBzeW5jIHdpdGggc2hhcmVkL21vZGVscy9hdXRoLnRzIFRJRVJfTElNSVRTXG5jb25zdCBLTk9XTl9USUVSUyA9IFtcImZyZWVcIiwgXCJwcm9cIiwgXCJwb3dlclwiXTtcbmV4cG9ydCBmdW5jdGlvbiBzYW5pdGl6ZVRpZXIodGllcjogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIEtOT1dOX1RJRVJTLmluY2x1ZGVzKHRpZXIpID8gdGllciA6IFwiZnJlZVwiO1xufVxuIiwgImltcG9ydCB7IEJBU0VfVVJMLCBNU0csIEFVVEhfU1RBUlRFRF9LRVksIFRPS0VOX1NUT1JBR0VfS0VZLCBQRU5ESU5HX1NFTEVDVElPTl9LRVkgfSBmcm9tIFwiLi4vc2hhcmVkL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgZ2V0VG9rZW4sIGNsZWFyVG9rZW4sIGlzVG9rZW5WYWxpZCB9IGZyb20gXCIuLi9hdXRoL3Rva2VuXCI7XG5pbXBvcnQgeyBlc2NhcGVBdHRyLCBzYW5pdGl6ZVRpZXIgfSBmcm9tIFwiLi91dGlsc1wiO1xuXG5jb25zdCBUQUcgPSBcIltGVEM6cG9wdXBdXCI7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gU3RhdGVcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5pbnRlcmZhY2UgVXNlckluZm8ge1xuICB1c2VySWQ6IHN0cmluZztcbiAgdGllcjogc3RyaW5nO1xuICBlbWFpbDogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgU2VsZWN0aW9uIHtcbiAgc2VsZWN0b3I6IHN0cmluZztcbiAgY3VycmVudFZhbHVlOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xuICBwYWdlVGl0bGU6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIENhbmRpZGF0ZSB7XG4gIHNlbGVjdG9yOiBzdHJpbmc7XG4gIHRleHQ6IHN0cmluZztcbiAgc2NvcmU6IG51bWJlcjtcbn1cblxudHlwZSBQb3B1cFN0YXRlID1cbiAgfCBcInVuYXV0aGVudGljYXRlZFwiXG4gIHwgXCJjb25uZWN0aW5nXCJcbiAgfCBcImF1dGhfZmFpbGVkXCJcbiAgfCBcImF1dGhlbnRpY2F0ZWRcIlxuICB8IFwicGlja2luZ1wiXG4gIHwgXCJjb25maXJtXCJcbiAgfCBcImNyZWF0aW5nXCJcbiAgfCBcInN1Y2Nlc3NcIlxuICB8IFwiZXJyb3JcIjtcblxubGV0IHN0YXRlOiBQb3B1cFN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbmxldCB1c2VySW5mbzogVXNlckluZm8gfCBudWxsID0gbnVsbDtcbmxldCBzZWxlY3Rpb246IFNlbGVjdGlvbiB8IG51bGwgPSBudWxsO1xubGV0IGNhbmRpZGF0ZXM6IENhbmRpZGF0ZVtdID0gW107XG5sZXQgY3VycmVudFRhYlVybCA9IFwiXCI7XG5sZXQgY3VycmVudFRhYlRpdGxlID0gXCJcIjtcbmxldCBjdXJyZW50VGFiSWQgPSAwO1xubGV0IGVycm9yTWVzc2FnZSA9IFwiXCI7XG5sZXQgY3JlYXRlZE1vbml0b3JOYW1lID0gXCJcIjtcbmxldCBjcmVhdGVkTW9uaXRvclZhbHVlID0gXCJcIjtcbmxldCBkcm9wZG93bk9wZW4gPSBmYWxzZTtcblxuY29uc3QgY29udGVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29udGVudFwiKSE7XG5jb25zdCBhY2NvdW50QXJlYSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWNjb3VudC1hcmVhXCIpITtcblxuLy8gSG93IGxvbmcgd2UgY29uc2lkZXIgYW4gYXV0aCBhdHRlbXB0IFwicmVjZW50XCIgXHUyMDE0IGlmIG5vIHRva2VuIHdhcyBzdG9yZWRcbi8vIHdpdGhpbiB0aGlzIHdpbmRvdywgd2Ugc2hvdyBhbiBlcnJvciBpbnN0ZWFkIG9mIHRoZSBkZWZhdWx0IGNvbm5lY3Qgc2NyZWVuLlxuLy8gTXVzdCBtYXRjaCB0aGUgU1cncyBmYWxsYmFjayB3aW5kb3cgKDEyMCBzIGluIHNlcnZpY2Utd29ya2VyLnRzIG9uVXBkYXRlZCkuXG5jb25zdCBBVVRIX1RJTUVPVVRfTVMgPSAxMjBfMDAwO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIEluaXRpYWxpc2Vcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5sZXQgaW5pdFJ1bm5pbmcgPSBmYWxzZTtcbmxldCBpbml0UGVuZGluZyA9IGZhbHNlO1xuXG5hc3luYyBmdW5jdGlvbiBpbml0KCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoaW5pdFJ1bm5pbmcpIHtcbiAgICBpbml0UGVuZGluZyA9IHRydWU7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImluaXQgYWxyZWFkeSBydW5uaW5nLCBxdWV1ZWluZyByZXJ1blwiKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaW5pdFJ1bm5pbmcgPSB0cnVlO1xuICBjb25zb2xlLmxvZyhUQUcsIFwiaW5pdCBzdGFydFwiKTtcbiAgdHJ5IHtcblxuICAvLyBHZXQgY3VycmVudCB0YWIgaW5mb1xuICBjb25zdCBbdGFiXSA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICBpZiAodGFiKSB7XG4gICAgY3VycmVudFRhYlVybCA9IHRhYi51cmwgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiVGl0bGUgPSB0YWIudGl0bGUgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiSWQgPSB0YWIuaWQgfHwgMDtcbiAgfVxuXG4gIGNvbnN0IHZhbGlkID0gYXdhaXQgaXNUb2tlblZhbGlkKCk7XG4gIGlmICghdmFsaWQpIHtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwibm8gdmFsaWQgdG9rZW4gaW4gc3RvcmFnZVwiKTtcblxuICAgIC8vIENoZWNrIGlmIGFuIGF1dGggYXR0ZW1wdCB3YXMgcmVjZW50bHkgc3RhcnRlZC5cbiAgICAvLyBTaG93IFwiY29ubmVjdGluZ1wiIGZvciB0aGUgZmlyc3QgMzAgcyAoYXV0aCBtYXkgc3RpbGwgYmUgaW4gcHJvZ3Jlc3MpLFxuICAgIC8vIHRoZW4gXCJhdXRoX2ZhaWxlZFwiIHVwIHRvIEFVVEhfVElNRU9VVF9NUy5cbiAgICBjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoQVVUSF9TVEFSVEVEX0tFWSk7XG4gICAgY29uc3Qgc3RhcnRlZEF0ID0gTnVtYmVyKHN0b3JlZFtBVVRIX1NUQVJURURfS0VZXSk7XG4gICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBzdGFydGVkQXQ7XG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShzdGFydGVkQXQpICYmIGVsYXBzZWQgPCBBVVRIX1RJTUVPVVRfTVMpIHtcbiAgICAgIGlmIChlbGFwc2VkIDwgMzBfMDAwKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFRBRywgXCJhdXRoIGF0dGVtcHQgaW4gcHJvZ3Jlc3MgKFwiLCBNYXRoLnJvdW5kKGVsYXBzZWQgLyAxMDAwKSwgXCJzIGFnbylcIik7XG4gICAgICAgIHN0YXRlID0gXCJjb25uZWN0aW5nXCI7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLndhcm4oVEFHLCBcInJlY2VudCBhdXRoIGF0dGVtcHQgZm91bmQgYnV0IG5vIHRva2VuIFx1MjAxNCBzaG93aW5nIGZhaWx1cmUgc3RhdGVcIik7XG4gICAgICAgIHN0YXRlID0gXCJhdXRoX2ZhaWxlZFwiO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuXG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gVmVyaWZ5IHRva2VuIHdpdGggYmFja2VuZFxuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIGlmICghdG9rZW4pIHtcbiAgICBjb25zb2xlLmxvZyhUQUcsIFwiZ2V0VG9rZW4gcmV0dXJuZWQgbnVsbCBkZXNwaXRlIGlzVG9rZW5WYWxpZFwiKTtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgY29uc29sZS5sb2coVEFHLCBcInZlcmlmeWluZyB0b2tlbiB3aXRoIGJhY2tlbmQuLi5cIik7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L2FwaS9leHRlbnNpb24vdmVyaWZ5YCwge1xuICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICAgIH0pO1xuXG4gICAgaWYgKCFyZXMub2spIHtcbiAgICAgIGNvbnNvbGUud2FybihUQUcsIFwidmVyaWZ5IHJldHVybmVkXCIsIHJlcy5zdGF0dXMpO1xuICAgICAgYXdhaXQgY2xlYXJUb2tlbigpO1xuICAgICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdXNlckluZm8gPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgIGlmICghdXNlckluZm8gfHwgdHlwZW9mIHVzZXJJbmZvLnVzZXJJZCAhPT0gXCJzdHJpbmdcIiB8fCB0eXBlb2YgdXNlckluZm8udGllciAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgY29uc29sZS53YXJuKFRBRywgXCJ2ZXJpZnkgcmVzcG9uc2UgbWFsZm9ybWVkOlwiLCB1c2VySW5mbyk7XG4gICAgICBhd2FpdCBjbGVhclRva2VuKCk7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgLy8gQ2FjaGUgdXNlckluZm8gZm9yIG9mZmxpbmUgZmFsbGJhY2tcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBjYWNoZWRVc2VySW5mbzogdXNlckluZm8gfSk7XG4gICAgLy8gQ2xlYXIgYW55IHN0YWxlIGF1dGgtc3RhcnRlZCBmbGFnXG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKEFVVEhfU1RBUlRFRF9LRVkpO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgY29uc29sZS5sb2coVEFHLCBcImF1dGhlbnRpY2F0ZWQgYXNcIiwgdXNlckluZm8uZW1haWwpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLndhcm4oVEFHLCBcInZlcmlmeSBuZXR3b3JrIGVycm9yOlwiLCBlcnIpO1xuICAgIC8vIE5ldHdvcmsgZXJyb3IgXHUyMDE0IHRyeSB0byByZXN0b3JlIGNhY2hlZCB1c2VySW5mbyBzbyB0aWVyL2FjY291bnQgZGlzcGxheSBjb3JyZWN0bHlcbiAgICBjb25zdCBjYWNoZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICBjb25zdCBjID0gY2FjaGVkLmNhY2hlZFVzZXJJbmZvO1xuICAgIGlmIChjICYmIHR5cGVvZiBjLnVzZXJJZCA9PT0gXCJzdHJpbmdcIiAmJiB0eXBlb2YgYy50aWVyID09PSBcInN0cmluZ1wiICYmIHR5cGVvZiBjLmVtYWlsID09PSBcInN0cmluZ1wiKSB7XG4gICAgICB1c2VySW5mbyA9IGM7XG4gICAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuICB9XG5cbiAgLy8gQ2hlY2sgZm9yIGEgcGVuZGluZyBlbGVtZW50IHNlbGVjdGlvbiBsZWZ0IGJ5IHRoZSBzZXJ2aWNlIHdvcmtlclxuICAvLyAodGhlIHBvcHVwIHdhcyBjbG9zZWQgd2hlbiB0aGUgdXNlciBjbGlja2VkIGFuIGVsZW1lbnQgb24gdGhlIHBhZ2UpLlxuICAvLyBEaXNjYXJkIHNlbGVjdGlvbnMgb2xkZXIgdGhhbiAxMCBtaW51dGVzIHRvIGF2b2lkIGNvbmZ1c2luZyBzdGFsZSBzdGF0ZS5cbiAgaWYgKHN0YXRlID09PSBcImF1dGhlbnRpY2F0ZWRcIikge1xuICAgIGNvbnN0IHBlbmRpbmcgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoUEVORElOR19TRUxFQ1RJT05fS0VZKTtcbiAgICBjb25zdCBzdG9yZWQgPSBwZW5kaW5nW1BFTkRJTkdfU0VMRUNUSU9OX0tFWV07XG4gICAgaWYgKHN0b3JlZCAmJiB0eXBlb2Ygc3RvcmVkLnNlbGVjdG9yID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zdCBhZ2UgPSBzdG9yZWQudGltZXN0YW1wID8gRGF0ZS5ub3coKSAtIHN0b3JlZC50aW1lc3RhbXAgOiBJbmZpbml0eTtcbiAgICAgIC8vIENsZWFyIGltbWVkaWF0ZWx5IHNvIHN0YWxlIHNlbGVjdGlvbnMgZG9uJ3QgcGVyc2lzdFxuICAgICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFBFTkRJTkdfU0VMRUNUSU9OX0tFWSk7XG4gICAgICBpZiAoYWdlIDwgNjAwXzAwMCkge1xuICAgICAgICBjb25zb2xlLmxvZyhUQUcsIFwicGVuZGluZyBzZWxlY3Rpb24gZm91bmQgaW4gc3RvcmFnZSwganVtcGluZyB0byBjb25maXJtXCIpO1xuICAgICAgICBzZWxlY3Rpb24gPSB7XG4gICAgICAgICAgc2VsZWN0b3I6IHN0b3JlZC5zZWxlY3RvcixcbiAgICAgICAgICBjdXJyZW50VmFsdWU6IHR5cGVvZiBzdG9yZWQuY3VycmVudFZhbHVlID09PSBcInN0cmluZ1wiID8gc3RvcmVkLmN1cnJlbnRWYWx1ZSA6IFwiXCIsXG4gICAgICAgICAgdXJsOiB0eXBlb2Ygc3RvcmVkLnVybCA9PT0gXCJzdHJpbmdcIiA/IHN0b3JlZC51cmwgOiBjdXJyZW50VGFiVXJsLFxuICAgICAgICAgIHBhZ2VUaXRsZTogdHlwZW9mIHN0b3JlZC5wYWdlVGl0bGUgPT09IFwic3RyaW5nXCIgPyBzdG9yZWQucGFnZVRpdGxlIDogY3VycmVudFRhYlRpdGxlLFxuICAgICAgICB9O1xuICAgICAgICBzdGF0ZSA9IFwiY29uZmlybVwiO1xuICAgICAgICByZW5kZXIoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc29sZS5sb2coVEFHLCBcInBlbmRpbmcgc2VsZWN0aW9uIHRvbyBvbGQgKFwiLCBNYXRoLnJvdW5kKGFnZSAvIDEwMDApLCBcInMpLCBkaXNjYXJkaW5nXCIpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJlbmRlcigpO1xuICB9IGZpbmFsbHkge1xuICAgIGluaXRSdW5uaW5nID0gZmFsc2U7XG4gICAgaWYgKGluaXRQZW5kaW5nKSB7XG4gICAgICBpbml0UGVuZGluZyA9IGZhbHNlO1xuICAgICAgLy8gRG9uJ3QgcmUtcnVuIGluaXQgaWYgd2UgYWxyZWFkeSByZWFjaGVkIGNvbmZpcm0gXHUyMDE0IHRoZSB1c2VyIGlzXG4gICAgICAvLyBsb29raW5nIGF0IHRoZSBjb25maXJtIHNjcmVlbiBhbmQgYSByZS1pbml0IHdvdWxkIGNsb2JiZXIgaXQuXG4gICAgICBpZiAoc3RhdGUgIT09IFwiY29uZmlybVwiKSB7XG4gICAgICAgIHZvaWQgaW5pdCgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIExpc3RlbiBmb3IgbWVzc2FnZXMgZnJvbSBiYWNrZ3JvdW5kL2NvbnRlbnRcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UpID0+IHtcbiAgaWYgKG1lc3NhZ2UudHlwZSA9PT0gTVNHLkVMRU1FTlRfU0VMRUNURUQpIHtcbiAgICBjb25zdCBzZWwgPSB0eXBlb2YgbWVzc2FnZS5zZWxlY3RvciA9PT0gXCJzdHJpbmdcIiA/IG1lc3NhZ2Uuc2VsZWN0b3IudHJpbSgpLnNsaWNlKDAsIDUwMCkgOiBcIlwiO1xuICAgIGlmICghc2VsKSByZXR1cm47XG4gICAgc2VsZWN0aW9uID0ge1xuICAgICAgc2VsZWN0b3I6IHNlbCxcbiAgICAgIGN1cnJlbnRWYWx1ZTogdHlwZW9mIG1lc3NhZ2UuY3VycmVudFZhbHVlID09PSBcInN0cmluZ1wiID8gbWVzc2FnZS5jdXJyZW50VmFsdWUuc2xpY2UoMCwgNTAwKSA6IFwiXCIsXG4gICAgICB1cmw6IHR5cGVvZiBtZXNzYWdlLnVybCA9PT0gXCJzdHJpbmdcIiA/IG1lc3NhZ2UudXJsLnNsaWNlKDAsIDIwMDApIDogY3VycmVudFRhYlVybCxcbiAgICAgIHBhZ2VUaXRsZTogdHlwZW9mIG1lc3NhZ2UucGFnZVRpdGxlID09PSBcInN0cmluZ1wiID8gbWVzc2FnZS5wYWdlVGl0bGUuc2xpY2UoMCwgMjAwKSA6IGN1cnJlbnRUYWJUaXRsZSxcbiAgICB9O1xuICAgIHN0YXRlID0gXCJjb25maXJtXCI7XG4gICAgcmVuZGVyKCk7XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuQ0FORElEQVRFU19SRVNVTFQpIHtcbiAgICBjYW5kaWRhdGVzID0gbWVzc2FnZS5jYW5kaWRhdGVzIHx8IFtdO1xuICAgIGlmIChzdGF0ZSA9PT0gXCJhdXRoZW50aWNhdGVkXCIgfHwgc3RhdGUgPT09IFwicGlja2luZ1wiKSB7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuQ0FOQ0VMX1BJQ0tFUikge1xuICAgIGlmIChzdGF0ZSA9PT0gXCJwaWNraW5nXCIpIHtcbiAgICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH1cblxuICBpZiAobWVzc2FnZS50eXBlID09PSBcIkZUQ19BVVRIX0NPTVBMRVRFXCIpIHtcbiAgICAvLyBSZS1pbml0aWFsaXNlIGFmdGVyIGF1dGhcbiAgICBpbml0KCk7XG4gIH1cbn0pO1xuXG4vLyBBbHNvIGxpc3RlbiBmb3IgZGlyZWN0IHN0b3JhZ2Ugd3JpdGVzIChlLmcuIGZyb20gYXV0aC1yZWxheSBjb250ZW50IHNjcmlwdFxuLy8gd3JpdGluZyB0aGUgdG9rZW4gZGlyZWN0bHksIGJ5cGFzc2luZyB0aGUgc2VydmljZSB3b3JrZXIpLlxuY2hyb21lLnN0b3JhZ2Uub25DaGFuZ2VkLmFkZExpc3RlbmVyKChjaGFuZ2VzLCBhcmVhKSA9PiB7XG4gIGlmIChhcmVhICE9PSBcImxvY2FsXCIpIHJldHVybjtcbiAgaWYgKGNoYW5nZXNbVE9LRU5fU1RPUkFHRV9LRVldPy5uZXdWYWx1ZSkge1xuICAgIGNvbnNvbGUubG9nKFRBRywgXCJ0b2tlbiBhcHBlYXJlZCBpbiBzdG9yYWdlIChkaXJlY3Qgd3JpdGUpLCByZS1pbml0aWFsaXNpbmcuLi5cIik7XG4gICAgdm9pZCBpbml0KCk7XG4gIH1cbiAgaWYgKGNoYW5nZXNbUEVORElOR19TRUxFQ1RJT05fS0VZXT8ubmV3VmFsdWUgJiYgc3RhdGUgIT09IFwiY29uZmlybVwiKSB7XG4gICAgY29uc29sZS5sb2coVEFHLCBcInBlbmRpbmcgc2VsZWN0aW9uIGFwcGVhcmVkIGluIHN0b3JhZ2UsIHJlLWluaXRpYWxpc2luZy4uLlwiKTtcbiAgICB2b2lkIGluaXQoKTtcbiAgfVxufSk7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gUmVuZGVyXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZnVuY3Rpb24gcmVuZGVyKCk6IHZvaWQge1xuICByZW5kZXJBY2NvdW50KCk7XG5cbiAgc3dpdGNoIChzdGF0ZSkge1xuICAgIGNhc2UgXCJ1bmF1dGhlbnRpY2F0ZWRcIjpcbiAgICAgIHJlbmRlclVuYXV0aCgpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImNvbm5lY3RpbmdcIjpcbiAgICAgIHJlbmRlckNvbm5lY3RpbmcoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJhdXRoX2ZhaWxlZFwiOlxuICAgICAgcmVuZGVyQXV0aEZhaWxlZCgpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImF1dGhlbnRpY2F0ZWRcIjpcbiAgICAgIHJlbmRlckF1dGhlbnRpY2F0ZWQoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJwaWNraW5nXCI6XG4gICAgICByZW5kZXJQaWNraW5nKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiY29uZmlybVwiOlxuICAgICAgcmVuZGVyQ29uZmlybSgpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImNyZWF0aW5nXCI6XG4gICAgICByZW5kZXJDcmVhdGluZygpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcInN1Y2Nlc3NcIjpcbiAgICAgIHJlbmRlclN1Y2Nlc3MoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJlcnJvclwiOlxuICAgICAgcmVuZGVyRXJyb3IoKTtcbiAgICAgIGJyZWFrO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlckFjY291bnQoKTogdm9pZCB7XG4gIGlmICghdXNlckluZm8pIHtcbiAgICBhY2NvdW50QXJlYS5pbm5lckhUTUwgPSBcIlwiO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGFjY291bnRBcmVhLmlubmVySFRNTCA9IGBcbiAgICA8YnV0dG9uIGNsYXNzPVwiYWNjb3VudC1idG5cIiBpZD1cImFjY291bnQtdG9nZ2xlXCI+XG4gICAgICAke2VzY2FwZUh0bWwodXNlckluZm8uZW1haWwgfHwgXCJDb25uZWN0ZWRcIil9ICYjOTY2MjtcbiAgICA8L2J1dHRvbj5cbiAgICA8ZGl2IGNsYXNzPVwiYWNjb3VudC1kcm9wZG93biAke2Ryb3Bkb3duT3BlbiA/IFwiXCIgOiBcImhpZGRlblwifVwiIGlkPVwiYWNjb3VudC1kcm9wZG93blwiPlxuICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLWVtYWlsXCI+XG4gICAgICAgICR7ZXNjYXBlSHRtbCh1c2VySW5mby5lbWFpbCB8fCB1c2VySW5mby51c2VySWQpfVxuICAgICAgICA8c3BhbiBjbGFzcz1cInRpZXItYmFkZ2UgdGllci0ke3Nhbml0aXplVGllcih1c2VySW5mby50aWVyKX1cIj4ke2VzY2FwZUh0bWwodXNlckluZm8udGllcil9PC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgICA8YSBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiBocmVmPVwiJHtCQVNFX1VSTH0vZGFzaGJvYXJkXCIgdGFyZ2V0PVwiX2JsYW5rXCI+T3BlbiBkYXNoYm9hcmQ8L2E+XG4gICAgICA8ZGl2IGNsYXNzPVwiZHJvcGRvd24tZGl2aWRlclwiPjwvZGl2PlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIiBpZD1cImRpc2Nvbm5lY3QtYnRuXCI+RGlzY29ubmVjdDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWNjb3VudC10b2dnbGVcIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZSkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgZHJvcGRvd25PcGVuID0gIWRyb3Bkb3duT3BlbjtcbiAgICByZW5kZXJBY2NvdW50KCk7XG4gIH0pO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiZGlzY29ubmVjdC1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBhc3luYyAoKSA9PiB7XG4gICAgYXdhaXQgY2xlYXJUb2tlbigpO1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnJlbW92ZShcImNhY2hlZFVzZXJJbmZvXCIpO1xuICAgIHVzZXJJbmZvID0gbnVsbDtcbiAgICBkcm9wZG93bk9wZW4gPSBmYWxzZTtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xuXG4gIC8vIENsb3NlIGRyb3Bkb3duIG9uIGNsaWNrIG91dHNpZGVcbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBpZiAoZHJvcGRvd25PcGVuKSB7XG4gICAgICBkcm9wZG93bk9wZW4gPSBmYWxzZTtcbiAgICAgIHJlbmRlckFjY291bnQoKTtcbiAgICB9XG4gIH0sIHsgb25jZTogdHJ1ZSB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyVW5hdXRoKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwidW5hdXRoXCI+XG4gICAgICA8aDI+VHJhY2sgd2hhdCBtYXR0ZXJzIG9uIGFueSB3ZWJwYWdlLjwvaDI+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1mdWxsXCIgaWQ9XCJjb25uZWN0LWJ0blwiPkNvbm5lY3QgeW91ciBhY2NvdW50PC9idXR0b24+XG4gICAgICA8cD5BbHJlYWR5IGhhdmUgYW4gYWNjb3VudD8gU2lnbiBpbiBhYm92ZS48L3A+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjb25uZWN0LWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIHN0YXJ0QXV0aEZsb3cpO1xufVxuXG5mdW5jdGlvbiByZW5kZXJBdXRoRmFpbGVkKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwidW5hdXRoXCI+XG4gICAgICA8aDI+Q29ubmVjdGlvbiBmYWlsZWQ8L2gyPlxuICAgICAgPHA+V2UgY291bGRuJ3QgY29ubmVjdCB0aGUgZXh0ZW5zaW9uIHRvIHlvdXIgYWNjb3VudC4gVGhpcyBjYW4gaGFwcGVuIGlmIHlvdXIgYnJvd3NlciBibG9ja2VkIHRoZSBjb25uZWN0aW9uLjwvcD5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLWZ1bGxcIiBpZD1cInJldHJ5LWNvbm5lY3QtYnRuXCI+VHJ5IGFnYWluPC9idXR0b24+XG4gICAgICA8cCBzdHlsZT1cIm1hcmdpbi10b3A6IDEycHg7IGZvbnQtc2l6ZTogMTJweDsgb3BhY2l0eTogMC43O1wiPlxuICAgICAgICBUaXA6IHdoZW4gQ2hyb21lIGFza3MgdG8gYWxsb3cgYWNjZXNzIHRvIGZ0Yy5iZDczLmNvbSwgY2xpY2sgPHN0cm9uZz5BbGxvdzwvc3Ryb25nPi5cbiAgICAgIDwvcD5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJldHJ5LWNvbm5lY3QtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgc3RhcnRBdXRoRmxvdyk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN0YXJ0QXV0aEZsb3coKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnNvbGUubG9nKFRBRywgXCJzdGFydGluZyBhdXRoIGZsb3dcIik7XG5cbiAgLy8gQ2hyb21lIDEyNysgdHJlYXRzIGhvc3RfcGVybWlzc2lvbnMgYXMgb3B0aW9uYWwuXG4gIC8vIFJlcXVlc3QgdGhlIHBlcm1pc3Npb24gc28gdGhlIGF1dGgtcmVsYXkgY29udGVudCBzY3JpcHQgZ2V0cyBpbmplY3RlZC5cbiAgbGV0IHBlcm1pc3Npb25HcmFudGVkID0gZmFsc2U7XG4gIHRyeSB7XG4gICAgY29uc3Qgb3JpZ2luID0gbmV3IFVSTChCQVNFX1VSTCkub3JpZ2luO1xuICAgIHBlcm1pc3Npb25HcmFudGVkID0gYXdhaXQgY2hyb21lLnBlcm1pc3Npb25zLmNvbnRhaW5zKHsgb3JpZ2luczogW2Ake29yaWdpbn0vKmBdIH0pO1xuICAgIGNvbnNvbGUubG9nKFRBRywgXCJob3N0IHBlcm1pc3Npb24gYWxyZWFkeSBncmFudGVkOlwiLCBwZXJtaXNzaW9uR3JhbnRlZCk7XG4gICAgaWYgKCFwZXJtaXNzaW9uR3JhbnRlZCkge1xuICAgICAgcGVybWlzc2lvbkdyYW50ZWQgPSBhd2FpdCBjaHJvbWUucGVybWlzc2lvbnMucmVxdWVzdCh7IG9yaWdpbnM6IFtgJHtvcmlnaW59LypgXSB9KTtcbiAgICAgIGNvbnNvbGUubG9nKFRBRywgXCJob3N0IHBlcm1pc3Npb24gcmVxdWVzdCByZXN1bHQ6XCIsIHBlcm1pc3Npb25HcmFudGVkKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGNvbnNvbGUud2FybihUQUcsIFwicGVybWlzc2lvbiByZXF1ZXN0IGVycm9yOlwiLCBlcnIpO1xuICAgIC8vIEZhbGxiYWNrIGF1dGggc3RpbGwgd29ya3Mgd2l0aG91dCB0aGUgcGVybWlzc2lvblxuICB9XG5cbiAgLy8gUmVjb3JkIHRoYXQgd2Ugc3RhcnRlZCBhbiBhdXRoIGF0dGVtcHQgc28gaWYgdGhlIHBvcHVwXG4gIC8vIHJlLW9wZW5zIHdpdGhvdXQgYSB0b2tlbiwgd2UgY2FuIHNob3cgYW4gZXJyb3IgaW5zdGVhZCBvZlxuICAvLyB0aGUgZ2VuZXJpYyBcIkNvbm5lY3QgeW91ciBhY2NvdW50XCIgc2NyZWVuLlxuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbQVVUSF9TVEFSVEVEX0tFWV06IERhdGUubm93KCkgfSk7XG5cbiAgbGV0IHRhYjogY2hyb21lLnRhYnMuVGFiO1xuICB0cnkge1xuICAgIHRhYiA9IGF3YWl0IGNocm9tZS50YWJzLmNyZWF0ZSh7IHVybDogYCR7QkFTRV9VUkx9L2V4dGVuc2lvbi1hdXRoYCB9KTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgY29uc29sZS5lcnJvcihUQUcsIFwiZmFpbGVkIHRvIG9wZW4gYXV0aCB0YWI6XCIsIGVycik7XG4gICAgc3RhdGUgPSBcImF1dGhfZmFpbGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnNvbGUubG9nKFRBRywgXCJhdXRoIHRhYiBjcmVhdGVkOlwiLCB0YWIuaWQpO1xuXG4gIC8vIFRlbGwgdGhlIHNlcnZpY2Ugd29ya2VyIHdoaWNoIHRhYiB0byB3YXRjaFxuICBpZiAodGFiLmlkKSB7XG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiBNU0cuQVVUSF9UQUJfT1BFTkVELCB0YWJJZDogdGFiLmlkIH0pLmNhdGNoKChlcnIpID0+XG4gICAgICBjb25zb2xlLndhcm4oVEFHLCBcImZhaWxlZCB0byBub3RpZnkgc2VydmljZSB3b3JrZXIgb2YgYXV0aCB0YWI6XCIsIGVyciksXG4gICAgKTtcbiAgfVxuXG4gIHN0YXRlID0gXCJjb25uZWN0aW5nXCI7XG4gIHJlbmRlcigpO1xufVxuXG5mdW5jdGlvbiByZW5kZXJDb25uZWN0aW5nKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY29ubmVjdGluZ1wiPlxuICAgICAgPGRpdiBjbGFzcz1cInNwaW5uZXJcIj48L2Rpdj5cbiAgICAgIDxwPkNvbm5lY3RpbmcuLi48L3A+XG4gICAgICA8cD5XYWl0aW5nIGZvciB5b3UgdG8gc2lnbiBpbiBhdCBGZXRjaFRoZUNoYW5nZS48L3A+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnkgYnRuLXNtXCIgaWQ9XCJjYW5jZWwtY29ubmVjdFwiIHN0eWxlPVwibWFyZ2luLXRvcDogMTZweDtcIj5DYW5jZWw8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNhbmNlbC1jb25uZWN0XCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnJlbW92ZShBVVRIX1NUQVJURURfS0VZKTtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJBdXRoZW50aWNhdGVkKCk6IHZvaWQge1xuICBjb25zdCB0cnVuY2F0ZWRVcmwgPSBjdXJyZW50VGFiVXJsLmxlbmd0aCA+IDQ1XG4gICAgPyBjdXJyZW50VGFiVXJsLnNsaWNlKDAsIDQ1KSArIFwiLi4uXCJcbiAgICA6IGN1cnJlbnRUYWJVcmw7XG5cbiAgbGV0IGNhbmRpZGF0ZXNIdG1sID0gXCJcIjtcbiAgaWYgKGNhbmRpZGF0ZXMubGVuZ3RoID4gMCkge1xuICAgIGNhbmRpZGF0ZXNIdG1sID0gYFxuICAgICAgPGRpdiBjbGFzcz1cInNlY3Rpb24taGVhZGVyXCI+U3VnZ2VzdGVkIGVsZW1lbnRzPC9kaXY+XG4gICAgICAke2NhbmRpZGF0ZXNcbiAgICAgICAgLm1hcChcbiAgICAgICAgICAoYywgaSkgPT4gYFxuICAgICAgICA8ZGl2IGNsYXNzPVwiY2FuZGlkYXRlXCIgZGF0YS1pZHg9XCIke2l9XCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJjYW5kaWRhdGUtdGV4dFwiPiR7ZXNjYXBlSHRtbChjLnRleHQpfTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImNhbmRpZGF0ZS1zZWxlY3RvclwiPiR7ZXNjYXBlSHRtbChjLnNlbGVjdG9yKX08L3NwYW4+XG4gICAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tc20gY2FuZGlkYXRlLXRyYWNrXCIgZGF0YS1pZHg9XCIke2l9XCI+VHJhY2sgdGhpczwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIGBcbiAgICAgICAgKVxuICAgICAgICAuam9pbihcIlwiKX1cbiAgICBgO1xuICB9XG5cbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImN1cnJlbnQtdXJsXCI+PHN0cm9uZz5UcmFja2luZzo8L3N0cm9uZz4gJHtlc2NhcGVIdG1sKHRydW5jYXRlZFVybCl9PC9kaXY+XG4gICAgJHtjYW5kaWRhdGVzSHRtbH1cbiAgICA8ZGl2IGNsYXNzPVwic2VjdGlvbi1oZWFkZXJcIj5PciBwaWNrIG1hbnVhbGx5PC9kaXY+XG4gICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbFwiIGlkPVwicGljay1idG5cIj5QaWNrIGFuIGVsZW1lbnQgb24gdGhpcyBwYWdlPC9idXR0b24+XG4gICAgPGJ1dHRvbiBjbGFzcz1cImFkdmFuY2VkLXRvZ2dsZVwiIGlkPVwiYWR2YW5jZWQtdG9nZ2xlXCI+JiM5NjYyOyBBZHZhbmNlZCAoQ1NTIHNlbGVjdG9yKTwvYnV0dG9uPlxuICAgIDxkaXYgY2xhc3M9XCJhZHZhbmNlZC1jb250ZW50XCIgaWQ9XCJhZHZhbmNlZC1jb250ZW50XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzcz1cImZvcm0taW5wdXRcIiBpZD1cIm1hbnVhbC1zZWxlY3RvclwiIHBsYWNlaG9sZGVyPVwiZS5nLiAucHJvZHVjdC1wcmljZVwiPlxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnkgYnRuLXNtXCIgaWQ9XCJtYW51YWwtdHJhY2stYnRuXCI+VXNlIHRoaXMgc2VsZWN0b3I8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICAvLyBQaWNrIGVsZW1lbnQgYnV0dG9uXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGljay1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiBNU0cuU1RBUlRfUElDS0VSLCB0YWJJZDogY3VycmVudFRhYklkIH0pO1xuICAgIHN0YXRlID0gXCJwaWNraW5nXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xuXG4gIC8vIENhbmRpZGF0ZSB0cmFjayBidXR0b25zXG4gIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCIuY2FuZGlkYXRlLXRyYWNrXCIpLmZvckVhY2goKGJ0bikgPT4ge1xuICAgIGJ0bi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgICAgIGNvbnN0IGlkeCA9IHBhcnNlSW50KChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkuZGF0YXNldC5pZHggfHwgXCIwXCIpO1xuICAgICAgY29uc3QgYyA9IGNhbmRpZGF0ZXNbaWR4XTtcbiAgICAgIGlmIChjKSB7XG4gICAgICAgIHNlbGVjdGlvbiA9IHtcbiAgICAgICAgICBzZWxlY3RvcjogYy5zZWxlY3RvcixcbiAgICAgICAgICBjdXJyZW50VmFsdWU6IGMudGV4dCxcbiAgICAgICAgICB1cmw6IGN1cnJlbnRUYWJVcmwsXG4gICAgICAgICAgcGFnZVRpdGxlOiBjdXJyZW50VGFiVGl0bGUsXG4gICAgICAgIH07XG4gICAgICAgIHN0YXRlID0gXCJjb25maXJtXCI7XG4gICAgICAgIHJlbmRlcigpO1xuICAgICAgfVxuICAgIH0pO1xuICB9KTtcblxuICAvLyBBZHZhbmNlZCB0b2dnbGVcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhZHZhbmNlZC10b2dnbGVcIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgY29uc3QgZWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImFkdmFuY2VkLWNvbnRlbnRcIik7XG4gICAgZWw/LmNsYXNzTGlzdC50b2dnbGUoXCJvcGVuXCIpO1xuICB9KTtcblxuICAvLyBNYW51YWwgc2VsZWN0b3JcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtYW51YWwtdHJhY2stYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGNvbnN0IGlucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtYW51YWwtc2VsZWN0b3JcIikgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICBjb25zdCBzZWxlY3RvciA9IGlucHV0Py52YWx1ZS50cmltKCk7XG4gICAgaWYgKHNlbGVjdG9yKSB7XG4gICAgICBzZWxlY3Rpb24gPSB7XG4gICAgICAgIHNlbGVjdG9yLFxuICAgICAgICBjdXJyZW50VmFsdWU6IFwiXCIsXG4gICAgICAgIHVybDogY3VycmVudFRhYlVybCxcbiAgICAgICAgcGFnZVRpdGxlOiBcIlwiLFxuICAgICAgfTtcbiAgICAgIHN0YXRlID0gXCJjb25maXJtXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICB9XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJQaWNraW5nKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwicGlja2VyLWluZm9cIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJpY29uXCI+JiMxMjc5MTk7PC9kaXY+XG4gICAgICA8cD48c3Ryb25nPkNsaWNrIGFueSBlbGVtZW50IG9uIHRoZSBwYWdlIHRvIHRyYWNrIGl0Ljwvc3Ryb25nPjwvcD5cbiAgICAgIDxwPlByZXNzIEVzYyB0byBjYW5jZWwuPC9wPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGlkPVwiY2FuY2VsLXBpY2tcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDE2cHg7XCI+Q2FuY2VsIHBpY2tpbmc8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNhbmNlbC1waWNrXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogTVNHLkNBTkNFTF9QSUNLRVIsIHRhYklkOiBjdXJyZW50VGFiSWQgfSk7XG4gICAgc3RhdGUgPSBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckNvbmZpcm0oKTogdm9pZCB7XG4gIGlmICghc2VsZWN0aW9uKSByZXR1cm47XG5cbiAgY29uc3QgdGllciA9IHVzZXJJbmZvPy50aWVyIHx8IFwiZnJlZVwiO1xuICBjb25zdCBob3VybHlEaXNhYmxlZCA9IHRpZXIgPT09IFwiZnJlZVwiO1xuICBjb25zdCBkZWZhdWx0TmFtZSA9IChzZWxlY3Rpb24ucGFnZVRpdGxlIHx8IFwiXCIpLnNsaWNlKDAsIDEwMCk7XG5cbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImN1cnJlbnQtdXJsXCI+PHN0cm9uZz5UcmFja2luZzo8L3N0cm9uZz4gJHtlc2NhcGVIdG1sKFxuICAgICAgc2VsZWN0aW9uLnVybC5sZW5ndGggPiA0NSA/IHNlbGVjdGlvbi51cmwuc2xpY2UoMCwgNDUpICsgXCIuLi5cIiA6IHNlbGVjdGlvbi51cmxcbiAgICApfTwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJjb25maXJtLWNhcmRcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJsYWJlbFwiPkVsZW1lbnQgc2VsZWN0ZWQ8L2Rpdj5cbiAgICAgICR7XG4gICAgICAgIHNlbGVjdGlvbi5jdXJyZW50VmFsdWVcbiAgICAgICAgICA/IGA8ZGl2IGNsYXNzPVwidmFsdWVcIj5DdXJyZW50bHk6ICR7ZXNjYXBlSHRtbChzZWxlY3Rpb24uY3VycmVudFZhbHVlLnNsaWNlKDAsIDEwMCkpfTwvZGl2PmBcbiAgICAgICAgICA6IFwiXCJcbiAgICAgIH1cbiAgICAgIDxkaXYgY2xhc3M9XCJzZWxlY3RvclwiPiR7ZXNjYXBlSHRtbChzZWxlY3Rpb24uc2VsZWN0b3IpfTwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWxhYmVsXCI+TW9uaXRvciBuYW1lPC9sYWJlbD5cbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzPVwiZm9ybS1pbnB1dFwiIGlkPVwibW9uaXRvci1uYW1lXCIgdmFsdWU9XCIke2VzY2FwZUF0dHIoZGVmYXVsdE5hbWUpfVwiIG1heGxlbmd0aD1cIjEwMFwiPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICA8bGFiZWwgY2xhc3M9XCJmb3JtLWxhYmVsXCI+Q2hlY2sgZnJlcXVlbmN5PC9sYWJlbD5cbiAgICAgIDxkaXYgY2xhc3M9XCJyYWRpby1ncm91cFwiPlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJyYWRpby1sYWJlbFwiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwicmFkaW9cIiBuYW1lPVwiZnJlcXVlbmN5XCIgdmFsdWU9XCJkYWlseVwiIGNoZWNrZWQ+IERhaWx5XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDxsYWJlbCBjbGFzcz1cInJhZGlvLWxhYmVsICR7aG91cmx5RGlzYWJsZWQgPyBcImRpc2FibGVkXCIgOiBcIlwifVwiPlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwicmFkaW9cIiBuYW1lPVwiZnJlcXVlbmN5XCIgdmFsdWU9XCJob3VybHlcIiAke2hvdXJseURpc2FibGVkID8gXCJkaXNhYmxlZFwiIDogXCJcIn0+XG4gICAgICAgICAgSG91cmx5XG4gICAgICAgICAgJHtob3VybHlEaXNhYmxlZCA/ICc8c3BhbiBjbGFzcz1cInRvb2x0aXAtdGV4dFwiPihQcm8rKTwvc3Bhbj4nIDogXCJcIn1cbiAgICAgICAgPC9sYWJlbD5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJidG4tcm93XCI+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnlcIiBpZD1cInBpY2stYWdhaW4tYnRuXCJcbiAgICAgICAgJHtzZWxlY3Rpb24udXJsICYmIHNlbGVjdGlvbi51cmwgIT09IGN1cnJlbnRUYWJVcmwgPyBcImRpc2FibGVkIHRpdGxlPVxcXCJTd2l0Y2ggdG8gdGhlIG9yaWdpbmFsIHRhYiB0byBwaWNrIGFnYWluXFxcIlwiIDogXCJcIn0+UGljayBhZ2FpbjwvYnV0dG9uPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeVwiIGlkPVwiY3JlYXRlLWJ0blwiPkNyZWF0ZSBtb25pdG9yPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwaWNrLWFnYWluLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBzZWxlY3Rpb24gPSBudWxsO1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogTVNHLlNUQVJUX1BJQ0tFUiwgdGFiSWQ6IGN1cnJlbnRUYWJJZCB9KTtcbiAgICBzdGF0ZSA9IFwicGlja2luZ1wiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNyZWF0ZS1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBjcmVhdGVNb25pdG9yKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY3JlYXRlTW9uaXRvcigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKCFzZWxlY3Rpb24gfHwgc3RhdGUgPT09IFwiY3JlYXRpbmdcIikgcmV0dXJuO1xuXG4gIGNvbnN0IG5hbWVJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibW9uaXRvci1uYW1lXCIpIGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gIGNvbnN0IG5hbWUgPSBuYW1lSW5wdXQ/LnZhbHVlLnRyaW0oKSB8fCBcIlVudGl0bGVkIG1vbml0b3JcIjtcbiAgY29uc3QgZnJlcXVlbmN5ID1cbiAgICAoZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaW5wdXRbbmFtZT1cImZyZXF1ZW5jeVwiXTpjaGVja2VkJykgYXMgSFRNTElucHV0RWxlbWVudCk/LnZhbHVlIHx8IFwiZGFpbHlcIjtcblxuICBzdGF0ZSA9IFwiY3JlYXRpbmdcIjtcbiAgY3JlYXRlZE1vbml0b3JOYW1lID0gbmFtZTtcbiAgY3JlYXRlZE1vbml0b3JWYWx1ZSA9IHNlbGVjdGlvbi5jdXJyZW50VmFsdWU7XG4gIHJlbmRlcigpO1xuXG4gIHRyeSB7XG4gICAgY29uc3QgdG9rZW4gPSBhd2FpdCBnZXRUb2tlbigpO1xuICAgIGlmICghdG9rZW4pIHtcbiAgICAgIGVycm9yTWVzc2FnZSA9IFwiTm90IGF1dGhlbnRpY2F0ZWQuIFBsZWFzZSByZWNvbm5lY3QuXCI7XG4gICAgICBzdGF0ZSA9IFwiZXJyb3JcIjtcbiAgICAgIHJlbmRlcigpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke0JBU0VfVVJMfS9hcGkvZXh0ZW5zaW9uL21vbml0b3JzYCwge1xuICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0b2tlbn1gLFxuICAgICAgfSxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbmFtZSxcbiAgICAgICAgdXJsOiBzZWxlY3Rpb24udXJsLFxuICAgICAgICBzZWxlY3Rvcjogc2VsZWN0aW9uLnNlbGVjdG9yLFxuICAgICAgICBmcmVxdWVuY3ksXG4gICAgICB9KSxcbiAgICB9KTtcblxuICAgIGlmIChyZXMub2spIHtcbiAgICAgIHN0YXRlID0gXCJzdWNjZXNzXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKS5jYXRjaCgoKSA9PiBudWxsKTtcblxuICAgIGlmIChkYXRhPy5jb2RlID09PSBcIlRJRVJfTElNSVRfUkVBQ0hFRFwiKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBgJHtkYXRhLm1lc3NhZ2UgfHwgZGF0YS5lcnJvciB8fCBcIk1vbml0b3IgbGltaXQgcmVhY2hlZC5cIn1gO1xuICAgICAgc3RhdGUgPSBcImVycm9yXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIC8vIEFkZCB1cGdyYWRlIGxpbmsgYWZ0ZXIgcmVuZGVyIHVzaW5nIERPTSBBUElcbiAgICAgIGNvbnN0IGVyckNvbnRhaW5lciA9IGNvbnRlbnQucXVlcnlTZWxlY3RvcihcIi5lcnJvciBwXCIpO1xuICAgICAgaWYgKGVyckNvbnRhaW5lcikge1xuICAgICAgICBlcnJDb250YWluZXIuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJyXCIpKTtcbiAgICAgICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xuICAgICAgICBsaW5rLmhyZWYgPSBgJHtCQVNFX1VSTH0vcHJpY2luZ2A7XG4gICAgICAgIGxpbmsudGFyZ2V0ID0gXCJfYmxhbmtcIjtcbiAgICAgICAgbGluay5zdHlsZS5jb2xvciA9IFwiIzYzNjZmMVwiO1xuICAgICAgICBsaW5rLnRleHRDb250ZW50ID0gXCJVcGdyYWRlIHlvdXIgcGxhblwiO1xuICAgICAgICBlcnJDb250YWluZXIuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgZXJyb3JNZXNzYWdlID0gZGF0YT8ubWVzc2FnZSB8fCBkYXRhPy5lcnJvciB8fCBgRmFpbGVkICgke3Jlcy5zdGF0dXN9KWA7XG4gICAgc3RhdGUgPSBcImVycm9yXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0gY2F0Y2gge1xuICAgIGVycm9yTWVzc2FnZSA9IFwiTmV0d29yayBlcnJvci4gUGxlYXNlIHRyeSBhZ2Fpbi5cIjtcbiAgICBzdGF0ZSA9IFwiZXJyb3JcIjtcbiAgICByZW5kZXIoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJDcmVhdGluZygpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImNvbm5lY3RpbmdcIiBzdHlsZT1cInBhZGRpbmctdG9wOiA2NHB4O1wiPlxuICAgICAgPGRpdiBjbGFzcz1cInNwaW5uZXJcIj48L2Rpdj5cbiAgICAgIDxwPkNyZWF0aW5nIG1vbml0b3IuLi48L3A+XG4gICAgPC9kaXY+XG4gIGA7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclN1Y2Nlc3MoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJzdWNjZXNzXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiaWNvblwiPiYjMTAwMDM7PC9kaXY+XG4gICAgICA8aDM+TW9uaXRvciBjcmVhdGVkITwvaDM+XG4gICAgICA8cD48c3Ryb25nPiR7ZXNjYXBlSHRtbChjcmVhdGVkTW9uaXRvck5hbWUpfTwvc3Ryb25nPiBpcyBub3cgYmVpbmcgd2F0Y2hlZC48L3A+XG4gICAgICAke2NyZWF0ZWRNb25pdG9yVmFsdWUgPyBgPHA+WW91J2xsIGJlIG5vdGlmaWVkIHdoZW4gPHN0cm9uZz4ke2VzY2FwZUh0bWwoY3JlYXRlZE1vbml0b3JWYWx1ZS5zbGljZSgwLCA2MCkpfTwvc3Ryb25nPiBjaGFuZ2VzLjwvcD5gIDogXCJcIn1cbiAgICAgIDxkaXYgY2xhc3M9XCJidG4tcm93XCIgc3R5bGU9XCJtYXJnaW4tdG9wOiAyNHB4OyBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcIj5cbiAgICAgICAgPGEgY2xhc3M9XCJidG4gYnRuLXByaW1hcnkgYnRuLXNtXCIgaHJlZj1cIiR7QkFTRV9VUkx9L2Rhc2hib2FyZFwiIHRhcmdldD1cIl9ibGFua1wiPlZpZXcgaW4gZGFzaGJvYXJkPC9hPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnkgYnRuLXNtXCIgaWQ9XCJ0cmFjay1hbm90aGVyLWJ0blwiPlRyYWNrIGFub3RoZXI8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidHJhY2stYW5vdGhlci1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgc2VsZWN0aW9uID0gbnVsbDtcbiAgICBjYW5kaWRhdGVzID0gW107XG4gICAgc3RhdGUgPSBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckVycm9yKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiZXJyb3JcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJpY29uXCI+JiMxMDAwNzs8L2Rpdj5cbiAgICAgIDxoMz5Db3VsZG4ndCBjcmVhdGUgbW9uaXRvcjwvaDM+XG4gICAgICA8cD4ke2VzY2FwZUh0bWwoZXJyb3JNZXNzYWdlKX08L3A+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnlcIiBpZD1cInRyeS1hZ2Fpbi1idG5cIj5UcnkgYWdhaW48L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRyeS1hZ2Fpbi1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgc3RhdGUgPSBzZWxlY3Rpb24gPyBcImNvbmZpcm1cIiA6IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vLyBIZWxwZXJzXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZnVuY3Rpb24gZXNjYXBlSHRtbChzdHI6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gIGRpdi50ZXh0Q29udGVudCA9IHN0cjtcbiAgcmV0dXJuIGRpdi5pbm5lckhUTUw7XG59XG5cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vLyBTdGFydFxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmluaXQoKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7OztBQUdPLE1BQU0sV0FBVztBQUNqQixNQUFNLG9CQUFvQjtBQUMxQixNQUFNLG1CQUFtQjtBQUN6QixNQUFNLG1CQUFtQjtBQUV6QixNQUFNLHdCQUF3QjtBQUU5QixNQUFNLE1BQU07QUFBQSxJQUNqQixjQUFjO0FBQUEsSUFDZCxlQUFlO0FBQUEsSUFDZixrQkFBa0I7QUFBQSxJQUNsQixnQkFBZ0I7QUFBQSxJQUNoQixtQkFBbUI7QUFBQSxJQUNuQixxQkFBcUI7QUFBQSxJQUNyQixpQkFBaUI7QUFBQSxFQUNuQjs7O0FDaEJBLGlCQUFzQixXQUFtQztBQUN2RCxVQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsbUJBQW1CLGdCQUFnQixDQUFDO0FBQ25GLFVBQU0sUUFBUSxPQUFPLGlCQUFpQjtBQUN0QyxVQUFNLFNBQVMsT0FBTyxnQkFBZ0I7QUFFdEMsUUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFRLFFBQU87QUFFOUIsVUFBTSxXQUFXLElBQUksS0FBSyxNQUFNLEVBQUUsUUFBUTtBQUMxQyxRQUFJLENBQUMsT0FBTyxTQUFTLFFBQVEsS0FBSyxXQUFXLEtBQUssSUFBSSxHQUFHO0FBQ3ZELFlBQU0sV0FBVztBQUNqQixhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU87QUFBQSxFQUNUO0FBU0EsaUJBQXNCLGFBQTRCO0FBQ2hELFVBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxDQUFDLG1CQUFtQixnQkFBZ0IsQ0FBQztBQUFBLEVBQ3pFO0FBRUEsaUJBQXNCLGVBQWlDO0FBQ3JELFVBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsV0FBTyxVQUFVO0FBQUEsRUFDbkI7OztBQ2hDTyxXQUFTLFdBQVcsS0FBcUI7QUFDOUMsV0FBTyxJQUFJLFFBQVEsTUFBTSxPQUFPLEVBQUUsUUFBUSxNQUFNLFFBQVEsRUFBRSxRQUFRLE1BQU0sT0FBTyxFQUFFLFFBQVEsTUFBTSxNQUFNLEVBQUUsUUFBUSxNQUFNLE1BQU07QUFBQSxFQUM3SDtBQUdBLE1BQU0sY0FBYyxDQUFDLFFBQVEsT0FBTyxPQUFPO0FBQ3BDLFdBQVMsYUFBYSxNQUFzQjtBQUNqRCxXQUFPLFlBQVksU0FBUyxJQUFJLElBQUksT0FBTztBQUFBLEVBQzdDOzs7QUNKQSxNQUFNLE1BQU07QUFvQ1osTUFBSSxRQUFvQjtBQUN4QixNQUFJLFdBQTRCO0FBQ2hDLE1BQUksWUFBOEI7QUFDbEMsTUFBSSxhQUEwQixDQUFDO0FBQy9CLE1BQUksZ0JBQWdCO0FBQ3BCLE1BQUksa0JBQWtCO0FBQ3RCLE1BQUksZUFBZTtBQUNuQixNQUFJLGVBQWU7QUFDbkIsTUFBSSxxQkFBcUI7QUFDekIsTUFBSSxzQkFBc0I7QUFDMUIsTUFBSSxlQUFlO0FBRW5CLE1BQU0sVUFBVSxTQUFTLGVBQWUsU0FBUztBQUNqRCxNQUFNLGNBQWMsU0FBUyxlQUFlLGNBQWM7QUFLMUQsTUFBTSxrQkFBa0I7QUFNeEIsTUFBSSxjQUFjO0FBQ2xCLE1BQUksY0FBYztBQUVsQixpQkFBZSxPQUFzQjtBQUNuQyxRQUFJLGFBQWE7QUFDZixvQkFBYztBQUNkLGNBQVEsSUFBSSxLQUFLLHNDQUFzQztBQUN2RDtBQUFBLElBQ0Y7QUFDQSxrQkFBYztBQUNkLFlBQVEsSUFBSSxLQUFLLFlBQVk7QUFDN0IsUUFBSTtBQUdKLFlBQU0sQ0FBQyxHQUFHLElBQUksTUFBTSxPQUFPLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUMzRSxVQUFJLEtBQUs7QUFDUCx3QkFBZ0IsSUFBSSxPQUFPO0FBQzNCLDBCQUFrQixJQUFJLFNBQVM7QUFDL0IsdUJBQWUsSUFBSSxNQUFNO0FBQUEsTUFDM0I7QUFFQSxZQUFNLFFBQVEsTUFBTSxhQUFhO0FBQ2pDLFVBQUksQ0FBQyxPQUFPO0FBQ1YsZ0JBQVEsSUFBSSxLQUFLLDJCQUEyQjtBQUs1QyxjQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUM5RCxjQUFNLFlBQVksT0FBTyxPQUFPLGdCQUFnQixDQUFDO0FBQ2pELGNBQU0sVUFBVSxLQUFLLElBQUksSUFBSTtBQUM3QixZQUFJLE9BQU8sU0FBUyxTQUFTLEtBQUssVUFBVSxpQkFBaUI7QUFDM0QsY0FBSSxVQUFVLEtBQVE7QUFDcEIsb0JBQVEsSUFBSSxLQUFLLDhCQUE4QixLQUFLLE1BQU0sVUFBVSxHQUFJLEdBQUcsUUFBUTtBQUNuRixvQkFBUTtBQUFBLFVBQ1YsT0FBTztBQUNMLG9CQUFRLEtBQUssS0FBSyxxRUFBZ0U7QUFDbEYsb0JBQVE7QUFBQSxVQUNWO0FBQUEsUUFDRixPQUFPO0FBQ0wsa0JBQVE7QUFBQSxRQUNWO0FBRUEsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUdBLFlBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsVUFBSSxDQUFDLE9BQU87QUFDVixnQkFBUSxJQUFJLEtBQUssNkNBQTZDO0FBQzlELGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLGNBQVEsSUFBSSxLQUFLLGlDQUFpQztBQUNsRCxVQUFJO0FBQ0YsY0FBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLFFBQVEseUJBQXlCO0FBQUEsVUFDMUQsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLEdBQUc7QUFBQSxRQUM5QyxDQUFDO0FBRUQsWUFBSSxDQUFDLElBQUksSUFBSTtBQUNYLGtCQUFRLEtBQUssS0FBSyxtQkFBbUIsSUFBSSxNQUFNO0FBQy9DLGdCQUFNLFdBQVc7QUFDakIsa0JBQVE7QUFDUixpQkFBTztBQUNQO0FBQUEsUUFDRjtBQUVBLG1CQUFXLE1BQU0sSUFBSSxLQUFLLEVBQUUsTUFBTSxNQUFNLElBQUk7QUFDNUMsWUFBSSxDQUFDLFlBQVksT0FBTyxTQUFTLFdBQVcsWUFBWSxPQUFPLFNBQVMsU0FBUyxVQUFVO0FBQ3pGLGtCQUFRLEtBQUssS0FBSyw4QkFBOEIsUUFBUTtBQUN4RCxnQkFBTSxXQUFXO0FBQ2pCLGtCQUFRO0FBQ1IsaUJBQU87QUFDUDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxnQkFBZ0IsU0FBUyxDQUFDO0FBRTNELGNBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxnQkFBZ0I7QUFDbEQsZ0JBQVE7QUFDUixnQkFBUSxJQUFJLEtBQUssb0JBQW9CLFNBQVMsS0FBSztBQUFBLE1BQ3JELFNBQVMsS0FBSztBQUNaLGdCQUFRLEtBQUssS0FBSyx5QkFBeUIsR0FBRztBQUU5QyxjQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUM5RCxjQUFNLElBQUksT0FBTztBQUNqQixZQUFJLEtBQUssT0FBTyxFQUFFLFdBQVcsWUFBWSxPQUFPLEVBQUUsU0FBUyxZQUFZLE9BQU8sRUFBRSxVQUFVLFVBQVU7QUFDbEcscUJBQVc7QUFDWCxrQkFBUTtBQUFBLFFBQ1YsT0FBTztBQUNMLGtCQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFLQSxVQUFJLFVBQVUsaUJBQWlCO0FBQzdCLGNBQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUkscUJBQXFCO0FBQ3BFLGNBQU0sU0FBUyxRQUFRLHFCQUFxQjtBQUM1QyxZQUFJLFVBQVUsT0FBTyxPQUFPLGFBQWEsVUFBVTtBQUNqRCxnQkFBTSxNQUFNLE9BQU8sWUFBWSxLQUFLLElBQUksSUFBSSxPQUFPLFlBQVk7QUFFL0QsZ0JBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxxQkFBcUI7QUFDdkQsY0FBSSxNQUFNLEtBQVM7QUFDakIsb0JBQVEsSUFBSSxLQUFLLHdEQUF3RDtBQUN6RSx3QkFBWTtBQUFBLGNBQ1YsVUFBVSxPQUFPO0FBQUEsY0FDakIsY0FBYyxPQUFPLE9BQU8saUJBQWlCLFdBQVcsT0FBTyxlQUFlO0FBQUEsY0FDOUUsS0FBSyxPQUFPLE9BQU8sUUFBUSxXQUFXLE9BQU8sTUFBTTtBQUFBLGNBQ25ELFdBQVcsT0FBTyxPQUFPLGNBQWMsV0FBVyxPQUFPLFlBQVk7QUFBQSxZQUN2RTtBQUNBLG9CQUFRO0FBQ1IsbUJBQU87QUFDUDtBQUFBLFVBQ0YsT0FBTztBQUNMLG9CQUFRLElBQUksS0FBSywrQkFBK0IsS0FBSyxNQUFNLE1BQU0sR0FBSSxHQUFHLGdCQUFnQjtBQUFBLFVBQzFGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDUCxVQUFFO0FBQ0Esb0JBQWM7QUFDZCxVQUFJLGFBQWE7QUFDZixzQkFBYztBQUdkLFlBQUksVUFBVSxXQUFXO0FBQ3ZCLGVBQUssS0FBSztBQUFBLFFBQ1o7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFNQSxTQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsWUFBWTtBQUNoRCxRQUFJLFFBQVEsU0FBUyxJQUFJLGtCQUFrQjtBQUN6QyxZQUFNLE1BQU0sT0FBTyxRQUFRLGFBQWEsV0FBVyxRQUFRLFNBQVMsS0FBSyxFQUFFLE1BQU0sR0FBRyxHQUFHLElBQUk7QUFDM0YsVUFBSSxDQUFDLElBQUs7QUFDVixrQkFBWTtBQUFBLFFBQ1YsVUFBVTtBQUFBLFFBQ1YsY0FBYyxPQUFPLFFBQVEsaUJBQWlCLFdBQVcsUUFBUSxhQUFhLE1BQU0sR0FBRyxHQUFHLElBQUk7QUFBQSxRQUM5RixLQUFLLE9BQU8sUUFBUSxRQUFRLFdBQVcsUUFBUSxJQUFJLE1BQU0sR0FBRyxHQUFJLElBQUk7QUFBQSxRQUNwRSxXQUFXLE9BQU8sUUFBUSxjQUFjLFdBQVcsUUFBUSxVQUFVLE1BQU0sR0FBRyxHQUFHLElBQUk7QUFBQSxNQUN2RjtBQUNBLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVDtBQUVBLFFBQUksUUFBUSxTQUFTLElBQUksbUJBQW1CO0FBQzFDLG1CQUFhLFFBQVEsY0FBYyxDQUFDO0FBQ3BDLFVBQUksVUFBVSxtQkFBbUIsVUFBVSxXQUFXO0FBQ3BELGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFFBQUksUUFBUSxTQUFTLElBQUksZUFBZTtBQUN0QyxVQUFJLFVBQVUsV0FBVztBQUN2QixnQkFBUTtBQUNSLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFFBQUksUUFBUSxTQUFTLHFCQUFxQjtBQUV4QyxXQUFLO0FBQUEsSUFDUDtBQUFBLEVBQ0YsQ0FBQztBQUlELFNBQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxTQUFTLFNBQVM7QUFDdEQsUUFBSSxTQUFTLFFBQVM7QUFDdEIsUUFBSSxRQUFRLGlCQUFpQixHQUFHLFVBQVU7QUFDeEMsY0FBUSxJQUFJLEtBQUssOERBQThEO0FBQy9FLFdBQUssS0FBSztBQUFBLElBQ1o7QUFDQSxRQUFJLFFBQVEscUJBQXFCLEdBQUcsWUFBWSxVQUFVLFdBQVc7QUFDbkUsY0FBUSxJQUFJLEtBQUssMkRBQTJEO0FBQzVFLFdBQUssS0FBSztBQUFBLElBQ1o7QUFBQSxFQUNGLENBQUM7QUFNRCxXQUFTLFNBQWU7QUFDdEIsa0JBQWM7QUFFZCxZQUFRLE9BQU87QUFBQSxNQUNiLEtBQUs7QUFDSCxxQkFBYTtBQUNiO0FBQUEsTUFDRixLQUFLO0FBQ0gseUJBQWlCO0FBQ2pCO0FBQUEsTUFDRixLQUFLO0FBQ0gseUJBQWlCO0FBQ2pCO0FBQUEsTUFDRixLQUFLO0FBQ0gsNEJBQW9CO0FBQ3BCO0FBQUEsTUFDRixLQUFLO0FBQ0gsc0JBQWM7QUFDZDtBQUFBLE1BQ0YsS0FBSztBQUNILHNCQUFjO0FBQ2Q7QUFBQSxNQUNGLEtBQUs7QUFDSCx1QkFBZTtBQUNmO0FBQUEsTUFDRixLQUFLO0FBQ0gsc0JBQWM7QUFDZDtBQUFBLE1BQ0YsS0FBSztBQUNILG9CQUFZO0FBQ1o7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUVBLFdBQVMsZ0JBQXNCO0FBQzdCLFFBQUksQ0FBQyxVQUFVO0FBQ2Isa0JBQVksWUFBWTtBQUN4QjtBQUFBLElBQ0Y7QUFFQSxnQkFBWSxZQUFZO0FBQUE7QUFBQSxRQUVsQixXQUFXLFNBQVMsU0FBUyxXQUFXLENBQUM7QUFBQTtBQUFBLG1DQUVkLGVBQWUsS0FBSyxRQUFRO0FBQUE7QUFBQSxVQUVyRCxXQUFXLFNBQVMsU0FBUyxTQUFTLE1BQU0sQ0FBQztBQUFBLHVDQUNoQixhQUFhLFNBQVMsSUFBSSxDQUFDLEtBQUssV0FBVyxTQUFTLElBQUksQ0FBQztBQUFBO0FBQUEsdUNBRXpELFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU03QyxhQUFTLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxNQUFNO0FBQzFFLFFBQUUsZ0JBQWdCO0FBQ2xCLHFCQUFlLENBQUM7QUFDaEIsb0JBQWM7QUFBQSxJQUNoQixDQUFDO0FBRUQsYUFBUyxlQUFlLGdCQUFnQixHQUFHLGlCQUFpQixTQUFTLFlBQVk7QUFDL0UsWUFBTSxXQUFXO0FBQ2pCLFlBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxnQkFBZ0I7QUFDbEQsaUJBQVc7QUFDWCxxQkFBZTtBQUNmLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBR0QsYUFBUyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3ZDLFVBQUksY0FBYztBQUNoQix1QkFBZTtBQUNmLHNCQUFjO0FBQUEsTUFDaEI7QUFBQSxJQUNGLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztBQUFBLEVBQ25CO0FBRUEsV0FBUyxlQUFxQjtBQUM1QixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFRcEIsYUFBUyxlQUFlLGFBQWEsR0FBRyxpQkFBaUIsU0FBUyxhQUFhO0FBQUEsRUFDakY7QUFFQSxXQUFTLG1CQUF5QjtBQUNoQyxZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFXcEIsYUFBUyxlQUFlLG1CQUFtQixHQUFHLGlCQUFpQixTQUFTLGFBQWE7QUFBQSxFQUN2RjtBQUVBLGlCQUFlLGdCQUErQjtBQUM1QyxZQUFRLElBQUksS0FBSyxvQkFBb0I7QUFJckMsUUFBSSxvQkFBb0I7QUFDeEIsUUFBSTtBQUNGLFlBQU0sU0FBUyxJQUFJLElBQUksUUFBUSxFQUFFO0FBQ2pDLDBCQUFvQixNQUFNLE9BQU8sWUFBWSxTQUFTLEVBQUUsU0FBUyxDQUFDLEdBQUcsTUFBTSxJQUFJLEVBQUUsQ0FBQztBQUNsRixjQUFRLElBQUksS0FBSyxvQ0FBb0MsaUJBQWlCO0FBQ3RFLFVBQUksQ0FBQyxtQkFBbUI7QUFDdEIsNEJBQW9CLE1BQU0sT0FBTyxZQUFZLFFBQVEsRUFBRSxTQUFTLENBQUMsR0FBRyxNQUFNLElBQUksRUFBRSxDQUFDO0FBQ2pGLGdCQUFRLElBQUksS0FBSyxtQ0FBbUMsaUJBQWlCO0FBQUEsTUFDdkU7QUFBQSxJQUNGLFNBQVMsS0FBSztBQUNaLGNBQVEsS0FBSyxLQUFLLDZCQUE2QixHQUFHO0FBQUEsSUFFcEQ7QUFLQSxVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGdCQUFnQixHQUFHLEtBQUssSUFBSSxFQUFFLENBQUM7QUFFakUsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLE1BQU0sT0FBTyxLQUFLLE9BQU8sRUFBRSxLQUFLLEdBQUcsUUFBUSxrQkFBa0IsQ0FBQztBQUFBLElBQ3RFLFNBQVMsS0FBSztBQUNaLGNBQVEsTUFBTSxLQUFLLDRCQUE0QixHQUFHO0FBQ2xELGNBQVE7QUFDUixhQUFPO0FBQ1A7QUFBQSxJQUNGO0FBQ0EsWUFBUSxJQUFJLEtBQUsscUJBQXFCLElBQUksRUFBRTtBQUc1QyxRQUFJLElBQUksSUFBSTtBQUNWLGFBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxJQUFJLGlCQUFpQixPQUFPLElBQUksR0FBRyxDQUFDLEVBQUU7QUFBQSxRQUFNLENBQUMsUUFDOUUsUUFBUSxLQUFLLEtBQUssZ0RBQWdELEdBQUc7QUFBQSxNQUN2RTtBQUFBLElBQ0Y7QUFFQSxZQUFRO0FBQ1IsV0FBTztBQUFBLEVBQ1Q7QUFFQSxXQUFTLG1CQUF5QjtBQUNoQyxZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVNwQixhQUFTLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLFNBQVMsWUFBWTtBQUMvRSxZQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8sZ0JBQWdCO0FBQ2xELGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsc0JBQTRCO0FBQ25DLFVBQU0sZUFBZSxjQUFjLFNBQVMsS0FDeEMsY0FBYyxNQUFNLEdBQUcsRUFBRSxJQUFJLFFBQzdCO0FBRUosUUFBSSxpQkFBaUI7QUFDckIsUUFBSSxXQUFXLFNBQVMsR0FBRztBQUN6Qix1QkFBaUI7QUFBQTtBQUFBLFFBRWIsV0FDQztBQUFBLFFBQ0MsQ0FBQyxHQUFHLE1BQU07QUFBQSwyQ0FDdUIsQ0FBQztBQUFBLHlDQUNILFdBQVcsRUFBRSxJQUFJLENBQUM7QUFBQSw2Q0FDZCxXQUFXLEVBQUUsUUFBUSxDQUFDO0FBQUEsNkVBQ1UsQ0FBQztBQUFBO0FBQUE7QUFBQSxNQUd0RSxFQUNDLEtBQUssRUFBRSxDQUFDO0FBQUE7QUFBQSxJQUVmO0FBRUEsWUFBUSxZQUFZO0FBQUEsMERBQ29DLFdBQVcsWUFBWSxDQUFDO0FBQUEsTUFDNUUsY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBYWxCLGFBQVMsZUFBZSxVQUFVLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUNuRSxhQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sSUFBSSxjQUFjLE9BQU8sYUFBYSxDQUFDO0FBQzFFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBR0QsYUFBUyxpQkFBaUIsa0JBQWtCLEVBQUUsUUFBUSxDQUFDLFFBQVE7QUFDN0QsVUFBSSxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDbkMsY0FBTSxNQUFNLFNBQVUsRUFBRSxPQUF1QixRQUFRLE9BQU8sR0FBRztBQUNqRSxjQUFNLElBQUksV0FBVyxHQUFHO0FBQ3hCLFlBQUksR0FBRztBQUNMLHNCQUFZO0FBQUEsWUFDVixVQUFVLEVBQUU7QUFBQSxZQUNaLGNBQWMsRUFBRTtBQUFBLFlBQ2hCLEtBQUs7QUFBQSxZQUNMLFdBQVc7QUFBQSxVQUNiO0FBQ0Esa0JBQVE7QUFDUixpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxhQUFTLGVBQWUsaUJBQWlCLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUMxRSxZQUFNLEtBQUssU0FBUyxlQUFlLGtCQUFrQjtBQUNyRCxVQUFJLFVBQVUsT0FBTyxNQUFNO0FBQUEsSUFDN0IsQ0FBQztBQUdELGFBQVMsZUFBZSxrQkFBa0IsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQzNFLFlBQU0sUUFBUSxTQUFTLGVBQWUsaUJBQWlCO0FBQ3ZELFlBQU0sV0FBVyxPQUFPLE1BQU0sS0FBSztBQUNuQyxVQUFJLFVBQVU7QUFDWixvQkFBWTtBQUFBLFVBQ1Y7QUFBQSxVQUNBLGNBQWM7QUFBQSxVQUNkLEtBQUs7QUFBQSxVQUNMLFdBQVc7QUFBQSxRQUNiO0FBQ0EsZ0JBQVE7QUFDUixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVNwQixhQUFTLGVBQWUsYUFBYSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDdEUsYUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLElBQUksZUFBZSxPQUFPLGFBQWEsQ0FBQztBQUMzRSxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixRQUFJLENBQUMsVUFBVztBQUVoQixVQUFNLE9BQU8sVUFBVSxRQUFRO0FBQy9CLFVBQU0saUJBQWlCLFNBQVM7QUFDaEMsVUFBTSxlQUFlLFVBQVUsYUFBYSxJQUFJLE1BQU0sR0FBRyxHQUFHO0FBRTVELFlBQVEsWUFBWTtBQUFBLDBEQUNvQztBQUFBLE1BQ3BELFVBQVUsSUFBSSxTQUFTLEtBQUssVUFBVSxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksUUFBUSxVQUFVO0FBQUEsSUFDN0UsQ0FBQztBQUFBO0FBQUE7QUFBQSxRQUlHLFVBQVUsZUFDTixpQ0FBaUMsV0FBVyxVQUFVLGFBQWEsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLFdBQ2pGLEVBQ047QUFBQSw4QkFDd0IsV0FBVyxVQUFVLFFBQVEsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVFQUlXLFdBQVcsV0FBVyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FRMUQsaUJBQWlCLGFBQWEsRUFBRTtBQUFBLGdFQUNKLGlCQUFpQixhQUFhLEVBQUU7QUFBQTtBQUFBLFlBRXBGLGlCQUFpQiw2Q0FBNkMsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQU1sRSxVQUFVLE9BQU8sVUFBVSxRQUFRLGdCQUFnQiw4REFBZ0UsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUs3SCxhQUFTLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN6RSxrQkFBWTtBQUNaLGFBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxJQUFJLGNBQWMsT0FBTyxhQUFhLENBQUM7QUFDMUUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFFRCxhQUFTLGVBQWUsWUFBWSxHQUFHLGlCQUFpQixTQUFTLGFBQWE7QUFBQSxFQUNoRjtBQUVBLGlCQUFlLGdCQUErQjtBQUM1QyxRQUFJLENBQUMsYUFBYSxVQUFVLFdBQVk7QUFFeEMsVUFBTSxZQUFZLFNBQVMsZUFBZSxjQUFjO0FBQ3hELFVBQU0sT0FBTyxXQUFXLE1BQU0sS0FBSyxLQUFLO0FBQ3hDLFVBQU0sWUFDSCxTQUFTLGNBQWMsaUNBQWlDLEdBQXdCLFNBQVM7QUFFNUYsWUFBUTtBQUNSLHlCQUFxQjtBQUNyQiwwQkFBc0IsVUFBVTtBQUNoQyxXQUFPO0FBRVAsUUFBSTtBQUNGLFlBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsVUFBSSxDQUFDLE9BQU87QUFDVix1QkFBZTtBQUNmLGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLFlBQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxRQUFRLDJCQUEyQjtBQUFBLFFBQzVELFFBQVE7QUFBQSxRQUNSLFNBQVM7QUFBQSxVQUNQLGdCQUFnQjtBQUFBLFVBQ2hCLGVBQWUsVUFBVSxLQUFLO0FBQUEsUUFDaEM7QUFBQSxRQUNBLE1BQU0sS0FBSyxVQUFVO0FBQUEsVUFDbkI7QUFBQSxVQUNBLEtBQUssVUFBVTtBQUFBLFVBQ2YsVUFBVSxVQUFVO0FBQUEsVUFDcEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILENBQUM7QUFFRCxVQUFJLElBQUksSUFBSTtBQUNWLGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLFlBQU0sT0FBTyxNQUFNLElBQUksS0FBSyxFQUFFLE1BQU0sTUFBTSxJQUFJO0FBRTlDLFVBQUksTUFBTSxTQUFTLHNCQUFzQjtBQUN2Qyx1QkFBZSxHQUFHLEtBQUssV0FBVyxLQUFLLFNBQVMsd0JBQXdCO0FBQ3hFLGdCQUFRO0FBQ1IsZUFBTztBQUVQLGNBQU0sZUFBZSxRQUFRLGNBQWMsVUFBVTtBQUNyRCxZQUFJLGNBQWM7QUFDaEIsdUJBQWEsWUFBWSxTQUFTLGNBQWMsSUFBSSxDQUFDO0FBQ3JELGdCQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7QUFDdkMsZUFBSyxPQUFPLEdBQUcsUUFBUTtBQUN2QixlQUFLLFNBQVM7QUFDZCxlQUFLLE1BQU0sUUFBUTtBQUNuQixlQUFLLGNBQWM7QUFDbkIsdUJBQWEsWUFBWSxJQUFJO0FBQUEsUUFDL0I7QUFDQTtBQUFBLE1BQ0Y7QUFFQSxxQkFBZSxNQUFNLFdBQVcsTUFBTSxTQUFTLFdBQVcsSUFBSSxNQUFNO0FBQ3BFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxRQUFRO0FBQ04scUJBQWU7QUFDZixjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsV0FBUyxpQkFBdUI7QUFDOUIsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTXRCO0FBRUEsV0FBUyxnQkFBc0I7QUFDN0IsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUgsV0FBVyxrQkFBa0IsQ0FBQztBQUFBLFFBQ3pDLHNCQUFzQixzQ0FBc0MsV0FBVyxvQkFBb0IsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLDJCQUEyQixFQUFFO0FBQUE7QUFBQSxrREFFM0YsUUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTXhELGFBQVMsZUFBZSxtQkFBbUIsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQzVFLGtCQUFZO0FBQ1osbUJBQWEsQ0FBQztBQUNkLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsY0FBb0I7QUFDM0IsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJWCxXQUFXLFlBQVksQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUtqQyxhQUFTLGVBQWUsZUFBZSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDeEUsY0FBUSxZQUFZLFlBQVk7QUFDaEMsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFNQSxXQUFTLFdBQVcsS0FBcUI7QUFDdkMsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksY0FBYztBQUNsQixXQUFPLElBQUk7QUFBQSxFQUNiO0FBT0EsT0FBSzsiLAogICJuYW1lcyI6IFtdCn0K
