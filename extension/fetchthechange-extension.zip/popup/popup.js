"use strict";
(() => {
  // src/shared/constants.ts
  var BASE_URL = "https://ftc.bd73.com";
  var TOKEN_STORAGE_KEY = "ftc_extension_token";
  var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
  var MSG = {
    START_PICKER: "FTC_START_PICKER",
    CANCEL_PICKER: "FTC_CANCEL_PICKER",
    ELEMENT_SELECTED: "FTC_ELEMENT_SELECTED",
    GET_CANDIDATES: "FTC_GET_CANDIDATES",
    CANDIDATES_RESULT: "FTC_CANDIDATES_RESULT",
    FTC_EXTENSION_TOKEN: "FTC_EXTENSION_TOKEN"
  };

  // src/auth/token.ts
  async function getToken() {
    const result = await chrome.storage.local.get([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
    const token = result[TOKEN_STORAGE_KEY];
    const expiry = result[TOKEN_EXPIRY_KEY];
    if (!token || !expiry) return null;
    const expiryMs = new Date(expiry).getTime();
    if (!Number.isFinite(expiryMs) || expiryMs < Date.now()) {
      await clearToken();
      return null;
    }
    return token;
  }
  async function clearToken() {
    await chrome.storage.local.remove([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
  }
  async function isTokenValid() {
    const token = await getToken();
    return token !== null;
  }

  // src/popup/popup.ts
  var state = "unauthenticated";
  var userInfo = null;
  var selection = null;
  var candidates = [];
  var currentTabUrl = "";
  var currentTabId = 0;
  var errorMessage = "";
  var createdMonitorName = "";
  var createdMonitorValue = "";
  var dropdownOpen = false;
  var content = document.getElementById("content");
  var accountArea = document.getElementById("account-area");
  async function init() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      currentTabUrl = tab.url || "";
      currentTabId = tab.id || 0;
    }
    const valid = await isTokenValid();
    if (!valid) {
      state = "unauthenticated";
      render();
      return;
    }
    const token = await getToken();
    if (!token) {
      state = "unauthenticated";
      render();
      return;
    }
    try {
      const res = await fetch(`${BASE_URL}/api/extension/verify`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) {
        await clearToken();
        state = "unauthenticated";
        render();
        return;
      }
      userInfo = await res.json();
      await chrome.storage.local.set({ cachedUserInfo: userInfo });
      state = "authenticated";
    } catch {
      const cached = await chrome.storage.local.get("cachedUserInfo");
      const c = cached.cachedUserInfo;
      if (c && typeof c.userId === "string" && typeof c.tier === "string" && typeof c.email === "string") {
        userInfo = c;
        state = "authenticated";
      } else {
        state = "unauthenticated";
      }
    }
    render();
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === MSG.ELEMENT_SELECTED) {
      selection = {
        selector: message.selector,
        currentValue: message.currentValue,
        url: message.url,
        pageTitle: message.pageTitle
      };
      state = "confirm";
      render();
    }
    if (message.type === MSG.CANDIDATES_RESULT) {
      candidates = message.candidates || [];
      if (state === "authenticated" || state === "picking") {
        render();
      }
    }
    if (message.type === MSG.CANCEL_PICKER) {
      if (state === "picking") {
        state = "authenticated";
        render();
      }
    }
    if (message.type === "FTC_AUTH_COMPLETE") {
      init();
    }
  });
  function render() {
    renderAccount();
    switch (state) {
      case "unauthenticated":
        renderUnauth();
        break;
      case "connecting":
        renderConnecting();
        break;
      case "authenticated":
        renderAuthenticated();
        break;
      case "picking":
        renderPicking();
        break;
      case "confirm":
        renderConfirm();
        break;
      case "creating":
        renderCreating();
        break;
      case "success":
        renderSuccess();
        break;
      case "error":
        renderError();
        break;
    }
  }
  function renderAccount() {
    if (!userInfo) {
      accountArea.innerHTML = "";
      return;
    }
    accountArea.innerHTML = `
    <button class="account-btn" id="account-toggle">
      ${escapeHtml(userInfo.email || "Connected")} &#9662;
    </button>
    <div class="account-dropdown ${dropdownOpen ? "" : "hidden"}" id="account-dropdown">
      <div class="dropdown-email">
        ${escapeHtml(userInfo.email || userInfo.userId)}
        <span class="tier-badge tier-${sanitizeTier(userInfo.tier)}">${escapeHtml(userInfo.tier)}</span>
      </div>
      <a class="dropdown-item" href="${BASE_URL}/dashboard" target="_blank">Open dashboard</a>
      <div class="dropdown-divider"></div>
      <button class="dropdown-item" id="disconnect-btn">Disconnect</button>
    </div>
  `;
    document.getElementById("account-toggle")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdownOpen = !dropdownOpen;
      renderAccount();
    });
    document.getElementById("disconnect-btn")?.addEventListener("click", async () => {
      await clearToken();
      await chrome.storage.local.remove("cachedUserInfo");
      userInfo = null;
      dropdownOpen = false;
      state = "unauthenticated";
      render();
    });
    document.addEventListener("click", () => {
      if (dropdownOpen) {
        dropdownOpen = false;
        renderAccount();
      }
    }, { once: true });
  }
  function renderUnauth() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Track what matters on any webpage.</h2>
      <button class="btn btn-primary btn-full" id="connect-btn">Connect your account</button>
      <p>Already have an account? Sign in above.</p>
    </div>
  `;
    document.getElementById("connect-btn")?.addEventListener("click", () => {
      chrome.tabs.create({ url: `${BASE_URL}/extension-auth` });
      state = "connecting";
      render();
    });
  }
  function renderConnecting() {
    content.innerHTML = `
    <div class="connecting">
      <div class="spinner"></div>
      <p>Connecting...</p>
      <p>Waiting for you to sign in at FetchTheChange.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-connect" style="margin-top: 16px;">Cancel</button>
    </div>
  `;
    document.getElementById("cancel-connect")?.addEventListener("click", () => {
      state = "unauthenticated";
      render();
    });
  }
  function renderAuthenticated() {
    const truncatedUrl = currentTabUrl.length > 45 ? currentTabUrl.slice(0, 45) + "..." : currentTabUrl;
    let candidatesHtml = "";
    if (candidates.length > 0) {
      candidatesHtml = `
      <div class="section-header">Suggested elements</div>
      ${candidates.map(
        (c, i) => `
        <div class="candidate" data-idx="${i}">
          <span class="candidate-text">${escapeHtml(c.text)}</span>
          <span class="candidate-selector">${escapeHtml(c.selector)}</span>
          <button class="btn btn-primary btn-sm candidate-track" data-idx="${i}">Track this</button>
        </div>
      `
      ).join("")}
    `;
    }
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(truncatedUrl)}</div>
    ${candidatesHtml}
    <div class="section-header">Or pick manually</div>
    <button class="btn btn-primary btn-full" id="pick-btn">Pick an element on this page</button>
    <button class="advanced-toggle" id="advanced-toggle">&#9662; Advanced (CSS selector)</button>
    <div class="advanced-content" id="advanced-content">
      <div class="form-group">
        <input type="text" class="form-input" id="manual-selector" placeholder="e.g. .product-price">
      </div>
      <button class="btn btn-secondary btn-sm" id="manual-track-btn">Use this selector</button>
    </div>
  `;
    document.getElementById("pick-btn")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.querySelectorAll(".candidate-track").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const idx = parseInt(e.target.dataset.idx || "0");
        const c = candidates[idx];
        if (c) {
          selection = {
            selector: c.selector,
            currentValue: c.text,
            url: currentTabUrl,
            pageTitle: document.title
          };
          state = "confirm";
          render();
        }
      });
    });
    document.getElementById("advanced-toggle")?.addEventListener("click", () => {
      const el = document.getElementById("advanced-content");
      el?.classList.toggle("open");
    });
    document.getElementById("manual-track-btn")?.addEventListener("click", () => {
      const input = document.getElementById("manual-selector");
      const selector = input?.value.trim();
      if (selector) {
        selection = {
          selector,
          currentValue: "",
          url: currentTabUrl,
          pageTitle: ""
        };
        state = "confirm";
        render();
      }
    });
  }
  function renderPicking() {
    content.innerHTML = `
    <div class="picker-info">
      <div class="icon">&#127919;</div>
      <p><strong>Click any element on the page to track it.</strong></p>
      <p>Press Esc to cancel.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-pick" style="margin-top: 16px;">Cancel picking</button>
    </div>
  `;
    document.getElementById("cancel-pick")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.CANCEL_PICKER, tabId: currentTabId });
      state = "authenticated";
      render();
    });
  }
  function renderConfirm() {
    if (!selection) return;
    const tier = userInfo?.tier || "free";
    const hourlyDisabled = tier === "free";
    const defaultName = (selection.pageTitle || "").slice(0, 100);
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(
      selection.url.length > 45 ? selection.url.slice(0, 45) + "..." : selection.url
    )}</div>
    <div class="confirm-card">
      <div class="label">Element selected</div>
      ${selection.currentValue ? `<div class="value">Currently: ${escapeHtml(selection.currentValue.slice(0, 100))}</div>` : ""}
      <div class="selector">${escapeHtml(selection.selector)}</div>
    </div>
    <div class="form-group">
      <label class="form-label">Monitor name</label>
      <input type="text" class="form-input" id="monitor-name" value="${escapeAttr(defaultName)}" maxlength="100">
    </div>
    <div class="form-group">
      <label class="form-label">Check frequency</label>
      <div class="radio-group">
        <label class="radio-label">
          <input type="radio" name="frequency" value="daily" checked> Daily
        </label>
        <label class="radio-label ${hourlyDisabled ? "disabled" : ""}">
          <input type="radio" name="frequency" value="hourly" ${hourlyDisabled ? "disabled" : ""}>
          Hourly
          ${hourlyDisabled ? '<span class="tooltip-text">(Pro+)</span>' : ""}
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="pick-again-btn">Pick again</button>
      <button class="btn btn-primary" id="create-btn">Create monitor</button>
    </div>
  `;
    document.getElementById("pick-again-btn")?.addEventListener("click", () => {
      selection = null;
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.getElementById("create-btn")?.addEventListener("click", createMonitor);
  }
  async function createMonitor() {
    if (!selection || state === "creating") return;
    const nameInput = document.getElementById("monitor-name");
    const name = nameInput?.value.trim() || "Untitled monitor";
    const frequency = document.querySelector('input[name="frequency"]:checked')?.value || "daily";
    state = "creating";
    createdMonitorName = name;
    createdMonitorValue = selection.currentValue;
    render();
    try {
      const token = await getToken();
      if (!token) {
        errorMessage = "Not authenticated. Please reconnect.";
        state = "error";
        render();
        return;
      }
      const res = await fetch(`${BASE_URL}/api/extension/monitors`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name,
          url: selection.url,
          selector: selection.selector,
          frequency
        })
      });
      if (res.ok) {
        state = "success";
        render();
        return;
      }
      const data = await res.json().catch(() => null);
      if (data?.code === "TIER_LIMIT_REACHED") {
        errorMessage = `${data.message || data.error || "Monitor limit reached."}`;
        state = "error";
        render();
        const errContainer = content.querySelector(".error p");
        if (errContainer) {
          errContainer.appendChild(document.createElement("br"));
          const link = document.createElement("a");
          link.href = `${BASE_URL}/pricing`;
          link.target = "_blank";
          link.style.color = "#6366f1";
          link.textContent = "Upgrade your plan";
          errContainer.appendChild(link);
        }
        return;
      }
      errorMessage = data?.message || data?.error || `Failed (${res.status})`;
      state = "error";
      render();
    } catch {
      errorMessage = "Network error. Please try again.";
      state = "error";
      render();
    }
  }
  function renderCreating() {
    content.innerHTML = `
    <div class="connecting" style="padding-top: 64px;">
      <div class="spinner"></div>
      <p>Creating monitor...</p>
    </div>
  `;
  }
  function renderSuccess() {
    content.innerHTML = `
    <div class="success">
      <div class="icon">&#10003;</div>
      <h3>Monitor created!</h3>
      <p><strong>${escapeHtml(createdMonitorName)}</strong> is now being watched.</p>
      ${createdMonitorValue ? `<p>You'll be notified when <strong>${escapeHtml(createdMonitorValue.slice(0, 60))}</strong> changes.</p>` : ""}
      <div class="btn-row" style="margin-top: 24px; justify-content: center;">
        <a class="btn btn-primary btn-sm" href="${BASE_URL}/dashboard" target="_blank">View in dashboard</a>
        <button class="btn btn-secondary btn-sm" id="track-another-btn">Track another</button>
      </div>
    </div>
  `;
    document.getElementById("track-another-btn")?.addEventListener("click", () => {
      selection = null;
      candidates = [];
      state = "authenticated";
      render();
    });
  }
  function renderError() {
    content.innerHTML = `
    <div class="error">
      <div class="icon">&#10007;</div>
      <h3>Couldn't create monitor</h3>
      <p>${escapeHtml(errorMessage)}</p>
      <button class="btn btn-secondary" id="try-again-btn">Try again</button>
    </div>
  `;
    document.getElementById("try-again-btn")?.addEventListener("click", () => {
      state = selection ? "confirm" : "authenticated";
      render();
    });
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
  function escapeAttr(str) {
    return str.replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  var KNOWN_TIERS = ["free", "pro", "power"];
  function sanitizeTier(tier) {
    return KNOWN_TIERS.includes(tier) ? tier : "free";
  }
  init();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL3NoYXJlZC9jb25zdGFudHMudHMiLCAiLi4vLi4vc3JjL2F1dGgvdG9rZW4udHMiLCAiLi4vLi4vc3JjL3BvcHVwL3BvcHVwLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIvLyBCQVNFX1VSTCBpcyBpbmplY3RlZCBhdCBidWlsZCB0aW1lIHZpYSBlc2J1aWxkIGRlZmluZS5cbi8vIFNldCBCQVNFX1VSTCBlbnYgdmFyIHRvIG92ZXJyaWRlIChkZWZhdWx0OiBodHRwczovL2Z0Yy5iZDczLmNvbSlcbmRlY2xhcmUgY29uc3QgQkFTRV9VUkxfSU5KRUNURUQ6IHN0cmluZztcbmV4cG9ydCBjb25zdCBCQVNFX1VSTCA9IEJBU0VfVVJMX0lOSkVDVEVEO1xuZXhwb3J0IGNvbnN0IFRPS0VOX1NUT1JBR0VfS0VZID0gXCJmdGNfZXh0ZW5zaW9uX3Rva2VuXCI7XG5leHBvcnQgY29uc3QgVE9LRU5fRVhQSVJZX0tFWSA9IFwiZnRjX2V4dGVuc2lvbl90b2tlbl9leHBpcnlcIjtcblxuZXhwb3J0IGNvbnN0IE1TRyA9IHtcbiAgU1RBUlRfUElDS0VSOiBcIkZUQ19TVEFSVF9QSUNLRVJcIixcbiAgQ0FOQ0VMX1BJQ0tFUjogXCJGVENfQ0FOQ0VMX1BJQ0tFUlwiLFxuICBFTEVNRU5UX1NFTEVDVEVEOiBcIkZUQ19FTEVNRU5UX1NFTEVDVEVEXCIsXG4gIEdFVF9DQU5ESURBVEVTOiBcIkZUQ19HRVRfQ0FORElEQVRFU1wiLFxuICBDQU5ESURBVEVTX1JFU1VMVDogXCJGVENfQ0FORElEQVRFU19SRVNVTFRcIixcbiAgRlRDX0VYVEVOU0lPTl9UT0tFTjogXCJGVENfRVhURU5TSU9OX1RPS0VOXCIsXG59IGFzIGNvbnN0O1xuIiwgImltcG9ydCB7IFRPS0VOX1NUT1JBR0VfS0VZLCBUT0tFTl9FWFBJUllfS0VZIH0gZnJvbSBcIi4uL3NoYXJlZC9jb25zdGFudHNcIjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRva2VuKCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoW1RPS0VOX1NUT1JBR0VfS0VZLCBUT0tFTl9FWFBJUllfS0VZXSk7XG4gIGNvbnN0IHRva2VuID0gcmVzdWx0W1RPS0VOX1NUT1JBR0VfS0VZXTtcbiAgY29uc3QgZXhwaXJ5ID0gcmVzdWx0W1RPS0VOX0VYUElSWV9LRVldO1xuXG4gIGlmICghdG9rZW4gfHwgIWV4cGlyeSkgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgZXhwaXJ5TXMgPSBuZXcgRGF0ZShleHBpcnkpLmdldFRpbWUoKTtcbiAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoZXhwaXJ5TXMpIHx8IGV4cGlyeU1zIDwgRGF0ZS5ub3coKSkge1xuICAgIGF3YWl0IGNsZWFyVG9rZW4oKTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHJldHVybiB0b2tlbjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFRva2VuKHRva2VuOiBzdHJpbmcsIGV4cGlyZXNBdDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgW1RPS0VOX1NUT1JBR0VfS0VZXTogdG9rZW4sXG4gICAgW1RPS0VOX0VYUElSWV9LRVldOiBleHBpcmVzQXQsXG4gIH0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJUb2tlbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFtUT0tFTl9TVE9SQUdFX0tFWSwgVE9LRU5fRVhQSVJZX0tFWV0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaXNUb2tlblZhbGlkKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIHJldHVybiB0b2tlbiAhPT0gbnVsbDtcbn1cbiIsICJpbXBvcnQgeyBCQVNFX1VSTCwgTVNHIH0gZnJvbSBcIi4uL3NoYXJlZC9jb25zdGFudHNcIjtcbmltcG9ydCB7IGdldFRva2VuLCBjbGVhclRva2VuLCBpc1Rva2VuVmFsaWQgfSBmcm9tIFwiLi4vYXV0aC90b2tlblwiO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIFN0YXRlXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuaW50ZXJmYWNlIFVzZXJJbmZvIHtcbiAgdXNlcklkOiBzdHJpbmc7XG4gIHRpZXI6IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIFNlbGVjdGlvbiB7XG4gIHNlbGVjdG9yOiBzdHJpbmc7XG4gIGN1cnJlbnRWYWx1ZTogc3RyaW5nO1xuICB1cmw6IHN0cmluZztcbiAgcGFnZVRpdGxlOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBDYW5kaWRhdGUge1xuICBzZWxlY3Rvcjogc3RyaW5nO1xuICB0ZXh0OiBzdHJpbmc7XG4gIHNjb3JlOiBudW1iZXI7XG59XG5cbnR5cGUgUG9wdXBTdGF0ZSA9XG4gIHwgXCJ1bmF1dGhlbnRpY2F0ZWRcIlxuICB8IFwiY29ubmVjdGluZ1wiXG4gIHwgXCJhdXRoZW50aWNhdGVkXCJcbiAgfCBcInBpY2tpbmdcIlxuICB8IFwiY29uZmlybVwiXG4gIHwgXCJjcmVhdGluZ1wiXG4gIHwgXCJzdWNjZXNzXCJcbiAgfCBcImVycm9yXCI7XG5cbmxldCBzdGF0ZTogUG9wdXBTdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG5sZXQgdXNlckluZm86IFVzZXJJbmZvIHwgbnVsbCA9IG51bGw7XG5sZXQgc2VsZWN0aW9uOiBTZWxlY3Rpb24gfCBudWxsID0gbnVsbDtcbmxldCBjYW5kaWRhdGVzOiBDYW5kaWRhdGVbXSA9IFtdO1xubGV0IGN1cnJlbnRUYWJVcmwgPSBcIlwiO1xubGV0IGN1cnJlbnRUYWJJZCA9IDA7XG5sZXQgZXJyb3JNZXNzYWdlID0gXCJcIjtcbmxldCBjcmVhdGVkTW9uaXRvck5hbWUgPSBcIlwiO1xubGV0IGNyZWF0ZWRNb25pdG9yVmFsdWUgPSBcIlwiO1xubGV0IGRyb3Bkb3duT3BlbiA9IGZhbHNlO1xuXG5jb25zdCBjb250ZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjb250ZW50XCIpITtcbmNvbnN0IGFjY291bnRBcmVhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhY2NvdW50LWFyZWFcIikhO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIEluaXRpYWxpc2Vcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5hc3luYyBmdW5jdGlvbiBpbml0KCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBHZXQgY3VycmVudCB0YWIgaW5mb1xuICBjb25zdCBbdGFiXSA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICBpZiAodGFiKSB7XG4gICAgY3VycmVudFRhYlVybCA9IHRhYi51cmwgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiSWQgPSB0YWIuaWQgfHwgMDtcbiAgfVxuXG4gIGNvbnN0IHZhbGlkID0gYXdhaXQgaXNUb2tlblZhbGlkKCk7XG4gIGlmICghdmFsaWQpIHtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gVmVyaWZ5IHRva2VuIHdpdGggYmFja2VuZFxuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIGlmICghdG9rZW4pIHtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vYXBpL2V4dGVuc2lvbi92ZXJpZnlgLCB7XG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0b2tlbn1gIH0sXG4gICAgfSk7XG5cbiAgICBpZiAoIXJlcy5vaykge1xuICAgICAgYXdhaXQgY2xlYXJUb2tlbigpO1xuICAgICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdXNlckluZm8gPSBhd2FpdCByZXMuanNvbigpO1xuICAgIC8vIENhY2hlIHVzZXJJbmZvIGZvciBvZmZsaW5lIGZhbGxiYWNrXG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgY2FjaGVkVXNlckluZm86IHVzZXJJbmZvIH0pO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gIH0gY2F0Y2gge1xuICAgIC8vIE5ldHdvcmsgZXJyb3IgXHUyMDE0IHRyeSB0byByZXN0b3JlIGNhY2hlZCB1c2VySW5mbyBzbyB0aWVyL2FjY291bnQgZGlzcGxheSBjb3JyZWN0bHlcbiAgICBjb25zdCBjYWNoZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICBjb25zdCBjID0gY2FjaGVkLmNhY2hlZFVzZXJJbmZvO1xuICAgIGlmIChjICYmIHR5cGVvZiBjLnVzZXJJZCA9PT0gXCJzdHJpbmdcIiAmJiB0eXBlb2YgYy50aWVyID09PSBcInN0cmluZ1wiICYmIHR5cGVvZiBjLmVtYWlsID09PSBcInN0cmluZ1wiKSB7XG4gICAgICB1c2VySW5mbyA9IGM7XG4gICAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuICB9XG5cbiAgcmVuZGVyKCk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gTGlzdGVuIGZvciBtZXNzYWdlcyBmcm9tIGJhY2tncm91bmQvY29udGVudFxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSkgPT4ge1xuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuRUxFTUVOVF9TRUxFQ1RFRCkge1xuICAgIHNlbGVjdGlvbiA9IHtcbiAgICAgIHNlbGVjdG9yOiBtZXNzYWdlLnNlbGVjdG9yLFxuICAgICAgY3VycmVudFZhbHVlOiBtZXNzYWdlLmN1cnJlbnRWYWx1ZSxcbiAgICAgIHVybDogbWVzc2FnZS51cmwsXG4gICAgICBwYWdlVGl0bGU6IG1lc3NhZ2UucGFnZVRpdGxlLFxuICAgIH07XG4gICAgc3RhdGUgPSBcImNvbmZpcm1cIjtcbiAgICByZW5kZXIoKTtcbiAgfVxuXG4gIGlmIChtZXNzYWdlLnR5cGUgPT09IE1TRy5DQU5ESURBVEVTX1JFU1VMVCkge1xuICAgIGNhbmRpZGF0ZXMgPSBtZXNzYWdlLmNhbmRpZGF0ZXMgfHwgW107XG4gICAgaWYgKHN0YXRlID09PSBcImF1dGhlbnRpY2F0ZWRcIiB8fCBzdGF0ZSA9PT0gXCJwaWNraW5nXCIpIHtcbiAgICAgIHJlbmRlcigpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChtZXNzYWdlLnR5cGUgPT09IE1TRy5DQU5DRUxfUElDS0VSKSB7XG4gICAgaWYgKHN0YXRlID09PSBcInBpY2tpbmdcIikge1xuICAgICAgc3RhdGUgPSBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICAgIHJlbmRlcigpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChtZXNzYWdlLnR5cGUgPT09IFwiRlRDX0FVVEhfQ09NUExFVEVcIikge1xuICAgIC8vIFJlLWluaXRpYWxpc2UgYWZ0ZXIgYXV0aFxuICAgIGluaXQoKTtcbiAgfVxufSk7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gUmVuZGVyXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZnVuY3Rpb24gcmVuZGVyKCk6IHZvaWQge1xuICByZW5kZXJBY2NvdW50KCk7XG5cbiAgc3dpdGNoIChzdGF0ZSkge1xuICAgIGNhc2UgXCJ1bmF1dGhlbnRpY2F0ZWRcIjpcbiAgICAgIHJlbmRlclVuYXV0aCgpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImNvbm5lY3RpbmdcIjpcbiAgICAgIHJlbmRlckNvbm5lY3RpbmcoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJhdXRoZW50aWNhdGVkXCI6XG4gICAgICByZW5kZXJBdXRoZW50aWNhdGVkKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwicGlja2luZ1wiOlxuICAgICAgcmVuZGVyUGlja2luZygpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImNvbmZpcm1cIjpcbiAgICAgIHJlbmRlckNvbmZpcm0oKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJjcmVhdGluZ1wiOlxuICAgICAgcmVuZGVyQ3JlYXRpbmcoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJzdWNjZXNzXCI6XG4gICAgICByZW5kZXJTdWNjZXNzKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZXJyb3JcIjpcbiAgICAgIHJlbmRlckVycm9yKCk7XG4gICAgICBicmVhaztcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50KCk6IHZvaWQge1xuICBpZiAoIXVzZXJJbmZvKSB7XG4gICAgYWNjb3VudEFyZWEuaW5uZXJIVE1MID0gXCJcIjtcbiAgICByZXR1cm47XG4gIH1cblxuICBhY2NvdW50QXJlYS5pbm5lckhUTUwgPSBgXG4gICAgPGJ1dHRvbiBjbGFzcz1cImFjY291bnQtYnRuXCIgaWQ9XCJhY2NvdW50LXRvZ2dsZVwiPlxuICAgICAgJHtlc2NhcGVIdG1sKHVzZXJJbmZvLmVtYWlsIHx8IFwiQ29ubmVjdGVkXCIpfSAmIzk2NjI7XG4gICAgPC9idXR0b24+XG4gICAgPGRpdiBjbGFzcz1cImFjY291bnQtZHJvcGRvd24gJHtkcm9wZG93bk9wZW4gPyBcIlwiIDogXCJoaWRkZW5cIn1cIiBpZD1cImFjY291bnQtZHJvcGRvd25cIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJkcm9wZG93bi1lbWFpbFwiPlxuICAgICAgICAke2VzY2FwZUh0bWwodXNlckluZm8uZW1haWwgfHwgdXNlckluZm8udXNlcklkKX1cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ0aWVyLWJhZGdlIHRpZXItJHtzYW5pdGl6ZVRpZXIodXNlckluZm8udGllcil9XCI+JHtlc2NhcGVIdG1sKHVzZXJJbmZvLnRpZXIpfTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGEgY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgaHJlZj1cIiR7QkFTRV9VUkx9L2Rhc2hib2FyZFwiIHRhcmdldD1cIl9ibGFua1wiPk9wZW4gZGFzaGJvYXJkPC9hPlxuICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLWRpdmlkZXJcIj48L2Rpdj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgaWQ9XCJkaXNjb25uZWN0LWJ0blwiPkRpc2Nvbm5lY3Q8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImFjY291bnQtdG9nZ2xlXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIGRyb3Bkb3duT3BlbiA9ICFkcm9wZG93bk9wZW47XG4gICAgcmVuZGVyQWNjb3VudCgpO1xuICB9KTtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRpc2Nvbm5lY3QtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGNsZWFyVG9rZW4oKTtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICB1c2VySW5mbyA9IG51bGw7XG4gICAgZHJvcGRvd25PcGVuID0gZmFsc2U7XG4gICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcblxuICAvLyBDbG9zZSBkcm9wZG93biBvbiBjbGljayBvdXRzaWRlXG4gIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgaWYgKGRyb3Bkb3duT3Blbikge1xuICAgICAgZHJvcGRvd25PcGVuID0gZmFsc2U7XG4gICAgICByZW5kZXJBY2NvdW50KCk7XG4gICAgfVxuICB9LCB7IG9uY2U6IHRydWUgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclVuYXV0aCgpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInVuYXV0aFwiPlxuICAgICAgPGgyPlRyYWNrIHdoYXQgbWF0dGVycyBvbiBhbnkgd2VicGFnZS48L2gyPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbFwiIGlkPVwiY29ubmVjdC1idG5cIj5Db25uZWN0IHlvdXIgYWNjb3VudDwvYnV0dG9uPlxuICAgICAgPHA+QWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/IFNpZ24gaW4gYWJvdmUuPC9wPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29ubmVjdC1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgY2hyb21lLnRhYnMuY3JlYXRlKHsgdXJsOiBgJHtCQVNFX1VSTH0vZXh0ZW5zaW9uLWF1dGhgIH0pO1xuICAgIHN0YXRlID0gXCJjb25uZWN0aW5nXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJDb25uZWN0aW5nKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY29ubmVjdGluZ1wiPlxuICAgICAgPGRpdiBjbGFzcz1cInNwaW5uZXJcIj48L2Rpdj5cbiAgICAgIDxwPkNvbm5lY3RpbmcuLi48L3A+XG4gICAgICA8cD5XYWl0aW5nIGZvciB5b3UgdG8gc2lnbiBpbiBhdCBGZXRjaFRoZUNoYW5nZS48L3A+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnkgYnRuLXNtXCIgaWQ9XCJjYW5jZWwtY29ubmVjdFwiIHN0eWxlPVwibWFyZ2luLXRvcDogMTZweDtcIj5DYW5jZWw8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNhbmNlbC1jb25uZWN0XCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckF1dGhlbnRpY2F0ZWQoKTogdm9pZCB7XG4gIGNvbnN0IHRydW5jYXRlZFVybCA9IGN1cnJlbnRUYWJVcmwubGVuZ3RoID4gNDVcbiAgICA/IGN1cnJlbnRUYWJVcmwuc2xpY2UoMCwgNDUpICsgXCIuLi5cIlxuICAgIDogY3VycmVudFRhYlVybDtcblxuICBsZXQgY2FuZGlkYXRlc0h0bWwgPSBcIlwiO1xuICBpZiAoY2FuZGlkYXRlcy5sZW5ndGggPiAwKSB7XG4gICAgY2FuZGlkYXRlc0h0bWwgPSBgXG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvbi1oZWFkZXJcIj5TdWdnZXN0ZWQgZWxlbWVudHM8L2Rpdj5cbiAgICAgICR7Y2FuZGlkYXRlc1xuICAgICAgICAubWFwKFxuICAgICAgICAgIChjLCBpKSA9PiBgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYW5kaWRhdGVcIiBkYXRhLWlkeD1cIiR7aX1cIj5cbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImNhbmRpZGF0ZS10ZXh0XCI+JHtlc2NhcGVIdG1sKGMudGV4dCl9PC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY2FuZGlkYXRlLXNlbGVjdG9yXCI+JHtlc2NhcGVIdG1sKGMuc2VsZWN0b3IpfTwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbSBjYW5kaWRhdGUtdHJhY2tcIiBkYXRhLWlkeD1cIiR7aX1cIj5UcmFjayB0aGlzPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgYFxuICAgICAgICApXG4gICAgICAgIC5qb2luKFwiXCIpfVxuICAgIGA7XG4gIH1cblxuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY3VycmVudC11cmxcIj48c3Ryb25nPlRyYWNraW5nOjwvc3Ryb25nPiAke2VzY2FwZUh0bWwodHJ1bmNhdGVkVXJsKX08L2Rpdj5cbiAgICAke2NhbmRpZGF0ZXNIdG1sfVxuICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLWhlYWRlclwiPk9yIHBpY2sgbWFudWFsbHk8L2Rpdj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1mdWxsXCIgaWQ9XCJwaWNrLWJ0blwiPlBpY2sgYW4gZWxlbWVudCBvbiB0aGlzIHBhZ2U8L2J1dHRvbj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiYWR2YW5jZWQtdG9nZ2xlXCIgaWQ9XCJhZHZhbmNlZC10b2dnbGVcIj4mIzk2NjI7IEFkdmFuY2VkIChDU1Mgc2VsZWN0b3IpPC9idXR0b24+XG4gICAgPGRpdiBjbGFzcz1cImFkdmFuY2VkLWNvbnRlbnRcIiBpZD1cImFkdmFuY2VkLWNvbnRlbnRcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzPVwiZm9ybS1pbnB1dFwiIGlkPVwibWFudWFsLXNlbGVjdG9yXCIgcGxhY2Vob2xkZXI9XCJlLmcuIC5wcm9kdWN0LXByaWNlXCI+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cIm1hbnVhbC10cmFjay1idG5cIj5Vc2UgdGhpcyBzZWxlY3RvcjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIC8vIFBpY2sgZWxlbWVudCBidXR0b25cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwaWNrLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5TVEFSVF9QSUNLRVIsIHRhYklkOiBjdXJyZW50VGFiSWQgfSk7XG4gICAgc3RhdGUgPSBcInBpY2tpbmdcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG5cbiAgLy8gQ2FuZGlkYXRlIHRyYWNrIGJ1dHRvbnNcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5jYW5kaWRhdGUtdHJhY2tcIikuZm9yRWFjaCgoYnRuKSA9PiB7XG4gICAgYnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZSkgPT4ge1xuICAgICAgY29uc3QgaWR4ID0gcGFyc2VJbnQoKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS5kYXRhc2V0LmlkeCB8fCBcIjBcIik7XG4gICAgICBjb25zdCBjID0gY2FuZGlkYXRlc1tpZHhdO1xuICAgICAgaWYgKGMpIHtcbiAgICAgICAgc2VsZWN0aW9uID0ge1xuICAgICAgICAgIHNlbGVjdG9yOiBjLnNlbGVjdG9yLFxuICAgICAgICAgIGN1cnJlbnRWYWx1ZTogYy50ZXh0LFxuICAgICAgICAgIHVybDogY3VycmVudFRhYlVybCxcbiAgICAgICAgICBwYWdlVGl0bGU6IGRvY3VtZW50LnRpdGxlLFxuICAgICAgICB9O1xuICAgICAgICBzdGF0ZSA9IFwiY29uZmlybVwiO1xuICAgICAgICByZW5kZXIoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gQWR2YW5jZWQgdG9nZ2xlXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWR2YW5jZWQtdG9nZ2xlXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhZHZhbmNlZC1jb250ZW50XCIpO1xuICAgIGVsPy5jbGFzc0xpc3QudG9nZ2xlKFwib3BlblwiKTtcbiAgfSk7XG5cbiAgLy8gTWFudWFsIHNlbGVjdG9yXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibWFudWFsLXRyYWNrLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjb25zdCBpbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwibWFudWFsLXNlbGVjdG9yXCIpIGFzIEhUTUxJbnB1dEVsZW1lbnQ7XG4gICAgY29uc3Qgc2VsZWN0b3IgPSBpbnB1dD8udmFsdWUudHJpbSgpO1xuICAgIGlmIChzZWxlY3Rvcikge1xuICAgICAgc2VsZWN0aW9uID0ge1xuICAgICAgICBzZWxlY3RvcixcbiAgICAgICAgY3VycmVudFZhbHVlOiBcIlwiLFxuICAgICAgICB1cmw6IGN1cnJlbnRUYWJVcmwsXG4gICAgICAgIHBhZ2VUaXRsZTogXCJcIixcbiAgICAgIH07XG4gICAgICBzdGF0ZSA9IFwiY29uZmlybVwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgfVxuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyUGlja2luZygpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInBpY2tlci1pbmZvXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiaWNvblwiPiYjMTI3OTE5OzwvZGl2PlxuICAgICAgPHA+PHN0cm9uZz5DbGljayBhbnkgZWxlbWVudCBvbiB0aGUgcGFnZSB0byB0cmFjayBpdC48L3N0cm9uZz48L3A+XG4gICAgICA8cD5QcmVzcyBFc2MgdG8gY2FuY2VsLjwvcD5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cImNhbmNlbC1waWNrXCIgc3R5bGU9XCJtYXJnaW4tdG9wOiAxNnB4O1wiPkNhbmNlbCBwaWNraW5nPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjYW5jZWwtcGlja1wiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5DQU5DRUxfUElDS0VSLCB0YWJJZDogY3VycmVudFRhYklkIH0pO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJDb25maXJtKCk6IHZvaWQge1xuICBpZiAoIXNlbGVjdGlvbikgcmV0dXJuO1xuXG4gIGNvbnN0IHRpZXIgPSB1c2VySW5mbz8udGllciB8fCBcImZyZWVcIjtcbiAgY29uc3QgaG91cmx5RGlzYWJsZWQgPSB0aWVyID09PSBcImZyZWVcIjtcbiAgY29uc3QgZGVmYXVsdE5hbWUgPSAoc2VsZWN0aW9uLnBhZ2VUaXRsZSB8fCBcIlwiKS5zbGljZSgwLCAxMDApO1xuXG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjdXJyZW50LXVybFwiPjxzdHJvbmc+VHJhY2tpbmc6PC9zdHJvbmc+ICR7ZXNjYXBlSHRtbChcbiAgICAgIHNlbGVjdGlvbi51cmwubGVuZ3RoID4gNDUgPyBzZWxlY3Rpb24udXJsLnNsaWNlKDAsIDQ1KSArIFwiLi4uXCIgOiBzZWxlY3Rpb24udXJsXG4gICAgKX08L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiY29uZmlybS1jYXJkXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibGFiZWxcIj5FbGVtZW50IHNlbGVjdGVkPC9kaXY+XG4gICAgICAke1xuICAgICAgICBzZWxlY3Rpb24uY3VycmVudFZhbHVlXG4gICAgICAgICAgPyBgPGRpdiBjbGFzcz1cInZhbHVlXCI+Q3VycmVudGx5OiAke2VzY2FwZUh0bWwoc2VsZWN0aW9uLmN1cnJlbnRWYWx1ZS5zbGljZSgwLCAxMDApKX08L2Rpdj5gXG4gICAgICAgICAgOiBcIlwiXG4gICAgICB9XG4gICAgICA8ZGl2IGNsYXNzPVwic2VsZWN0b3JcIj4ke2VzY2FwZUh0bWwoc2VsZWN0aW9uLnNlbGVjdG9yKX08L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1sYWJlbFwiPk1vbml0b3IgbmFtZTwvbGFiZWw+XG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBjbGFzcz1cImZvcm0taW5wdXRcIiBpZD1cIm1vbml0b3ItbmFtZVwiIHZhbHVlPVwiJHtlc2NhcGVBdHRyKGRlZmF1bHROYW1lKX1cIiBtYXhsZW5ndGg9XCIxMDBcIj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiZm9ybS1ncm91cFwiPlxuICAgICAgPGxhYmVsIGNsYXNzPVwiZm9ybS1sYWJlbFwiPkNoZWNrIGZyZXF1ZW5jeTwvbGFiZWw+XG4gICAgICA8ZGl2IGNsYXNzPVwicmFkaW8tZ3JvdXBcIj5cbiAgICAgICAgPGxhYmVsIGNsYXNzPVwicmFkaW8tbGFiZWxcIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT1cImZyZXF1ZW5jeVwiIHZhbHVlPVwiZGFpbHlcIiBjaGVja2VkPiBEYWlseVxuICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJyYWRpby1sYWJlbCAke2hvdXJseURpc2FibGVkID8gXCJkaXNhYmxlZFwiIDogXCJcIn1cIj5cbiAgICAgICAgICA8aW5wdXQgdHlwZT1cInJhZGlvXCIgbmFtZT1cImZyZXF1ZW5jeVwiIHZhbHVlPVwiaG91cmx5XCIgJHtob3VybHlEaXNhYmxlZCA/IFwiZGlzYWJsZWRcIiA6IFwiXCJ9PlxuICAgICAgICAgIEhvdXJseVxuICAgICAgICAgICR7aG91cmx5RGlzYWJsZWQgPyAnPHNwYW4gY2xhc3M9XCJ0b29sdGlwLXRleHRcIj4oUHJvKyk8L3NwYW4+JyA6IFwiXCJ9XG4gICAgICAgIDwvbGFiZWw+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiYnRuLXJvd1wiPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5XCIgaWQ9XCJwaWNrLWFnYWluLWJ0blwiPlBpY2sgYWdhaW48L2J1dHRvbj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXByaW1hcnlcIiBpZD1cImNyZWF0ZS1idG5cIj5DcmVhdGUgbW9uaXRvcjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicGljay1hZ2Fpbi1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgc2VsZWN0aW9uID0gbnVsbDtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5TVEFSVF9QSUNLRVIsIHRhYklkOiBjdXJyZW50VGFiSWQgfSk7XG4gICAgc3RhdGUgPSBcInBpY2tpbmdcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjcmVhdGUtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgY3JlYXRlTW9uaXRvcik7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZU1vbml0b3IoKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmICghc2VsZWN0aW9uIHx8IHN0YXRlID09PSBcImNyZWF0aW5nXCIpIHJldHVybjtcblxuICBjb25zdCBuYW1lSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1vbml0b3ItbmFtZVwiKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICBjb25zdCBuYW1lID0gbmFtZUlucHV0Py52YWx1ZS50cmltKCkgfHwgXCJVbnRpdGxlZCBtb25pdG9yXCI7XG4gIGNvbnN0IGZyZXF1ZW5jeSA9XG4gICAgKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2lucHV0W25hbWU9XCJmcmVxdWVuY3lcIl06Y2hlY2tlZCcpIGFzIEhUTUxJbnB1dEVsZW1lbnQpPy52YWx1ZSB8fCBcImRhaWx5XCI7XG5cbiAgc3RhdGUgPSBcImNyZWF0aW5nXCI7XG4gIGNyZWF0ZWRNb25pdG9yTmFtZSA9IG5hbWU7XG4gIGNyZWF0ZWRNb25pdG9yVmFsdWUgPSBzZWxlY3Rpb24uY3VycmVudFZhbHVlO1xuICByZW5kZXIoKTtcblxuICB0cnkge1xuICAgIGNvbnN0IHRva2VuID0gYXdhaXQgZ2V0VG9rZW4oKTtcbiAgICBpZiAoIXRva2VuKSB7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBcIk5vdCBhdXRoZW50aWNhdGVkLiBQbGVhc2UgcmVjb25uZWN0LlwiO1xuICAgICAgc3RhdGUgPSBcImVycm9yXCI7XG4gICAgICByZW5kZXIoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vYXBpL2V4dGVuc2lvbi9tb25pdG9yc2AsIHtcbiAgICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgICBoZWFkZXJzOiB7XG4gICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcbiAgICAgIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIHVybDogc2VsZWN0aW9uLnVybCxcbiAgICAgICAgc2VsZWN0b3I6IHNlbGVjdGlvbi5zZWxlY3RvcixcbiAgICAgICAgZnJlcXVlbmN5LFxuICAgICAgfSksXG4gICAgfSk7XG5cbiAgICBpZiAocmVzLm9rKSB7XG4gICAgICBzdGF0ZSA9IFwic3VjY2Vzc1wiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbCk7XG5cbiAgICBpZiAoZGF0YT8uY29kZSA9PT0gXCJUSUVSX0xJTUlUX1JFQUNIRURcIikge1xuICAgICAgZXJyb3JNZXNzYWdlID0gYCR7ZGF0YS5tZXNzYWdlIHx8IGRhdGEuZXJyb3IgfHwgXCJNb25pdG9yIGxpbWl0IHJlYWNoZWQuXCJ9YDtcbiAgICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICAvLyBBZGQgdXBncmFkZSBsaW5rIGFmdGVyIHJlbmRlciB1c2luZyBET00gQVBJXG4gICAgICBjb25zdCBlcnJDb250YWluZXIgPSBjb250ZW50LnF1ZXJ5U2VsZWN0b3IoXCIuZXJyb3IgcFwiKTtcbiAgICAgIGlmIChlcnJDb250YWluZXIpIHtcbiAgICAgICAgZXJyQ29udGFpbmVyLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJiclwiKSk7XG4gICAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYVwiKTtcbiAgICAgICAgbGluay5ocmVmID0gYCR7QkFTRV9VUkx9L3ByaWNpbmdgO1xuICAgICAgICBsaW5rLnRhcmdldCA9IFwiX2JsYW5rXCI7XG4gICAgICAgIGxpbmsuc3R5bGUuY29sb3IgPSBcIiM2MzY2ZjFcIjtcbiAgICAgICAgbGluay50ZXh0Q29udGVudCA9IFwiVXBncmFkZSB5b3VyIHBsYW5cIjtcbiAgICAgICAgZXJyQ29udGFpbmVyLmFwcGVuZENoaWxkKGxpbmspO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGVycm9yTWVzc2FnZSA9IGRhdGE/Lm1lc3NhZ2UgfHwgZGF0YT8uZXJyb3IgfHwgYEZhaWxlZCAoJHtyZXMuc3RhdHVzfSlgO1xuICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgIHJlbmRlcigpO1xuICB9IGNhdGNoIHtcbiAgICBlcnJvck1lc3NhZ2UgPSBcIk5ldHdvcmsgZXJyb3IuIFBsZWFzZSB0cnkgYWdhaW4uXCI7XG4gICAgc3RhdGUgPSBcImVycm9yXCI7XG4gICAgcmVuZGVyKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcmVuZGVyQ3JlYXRpbmcoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJjb25uZWN0aW5nXCIgc3R5bGU9XCJwYWRkaW5nLXRvcDogNjRweDtcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzcGlubmVyXCI+PC9kaXY+XG4gICAgICA8cD5DcmVhdGluZyBtb25pdG9yLi4uPC9wPlxuICAgIDwvZGl2PlxuICBgO1xufVxuXG5mdW5jdGlvbiByZW5kZXJTdWNjZXNzKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwic3VjY2Vzc1wiPlxuICAgICAgPGRpdiBjbGFzcz1cImljb25cIj4mIzEwMDAzOzwvZGl2PlxuICAgICAgPGgzPk1vbml0b3IgY3JlYXRlZCE8L2gzPlxuICAgICAgPHA+PHN0cm9uZz4ke2VzY2FwZUh0bWwoY3JlYXRlZE1vbml0b3JOYW1lKX08L3N0cm9uZz4gaXMgbm93IGJlaW5nIHdhdGNoZWQuPC9wPlxuICAgICAgJHtjcmVhdGVkTW9uaXRvclZhbHVlID8gYDxwPllvdSdsbCBiZSBub3RpZmllZCB3aGVuIDxzdHJvbmc+JHtlc2NhcGVIdG1sKGNyZWF0ZWRNb25pdG9yVmFsdWUuc2xpY2UoMCwgNjApKX08L3N0cm9uZz4gY2hhbmdlcy48L3A+YCA6IFwiXCJ9XG4gICAgICA8ZGl2IGNsYXNzPVwiYnRuLXJvd1wiIHN0eWxlPVwibWFyZ2luLXRvcDogMjRweDsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XCI+XG4gICAgICAgIDxhIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbVwiIGhyZWY9XCIke0JBU0VfVVJMfS9kYXNoYm9hcmRcIiB0YXJnZXQ9XCJfYmxhbmtcIj5WaWV3IGluIGRhc2hib2FyZDwvYT5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5IGJ0bi1zbVwiIGlkPVwidHJhY2stYW5vdGhlci1idG5cIj5UcmFjayBhbm90aGVyPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInRyYWNrLWFub3RoZXItYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHNlbGVjdGlvbiA9IG51bGw7XG4gICAgY2FuZGlkYXRlcyA9IFtdO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJFcnJvcigpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cImVycm9yXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwiaWNvblwiPiYjMTAwMDc7PC9kaXY+XG4gICAgICA8aDM+Q291bGRuJ3QgY3JlYXRlIG1vbml0b3I8L2gzPlxuICAgICAgPHA+JHtlc2NhcGVIdG1sKGVycm9yTWVzc2FnZSl9PC9wPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc2Vjb25kYXJ5XCIgaWQ9XCJ0cnktYWdhaW4tYnRuXCI+VHJ5IGFnYWluPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0cnktYWdhaW4tYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHN0YXRlID0gc2VsZWN0aW9uID8gXCJjb25maXJtXCIgOiBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gSGVscGVyc1xuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoc3RyOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICBkaXYudGV4dENvbnRlbnQgPSBzdHI7XG4gIHJldHVybiBkaXYuaW5uZXJIVE1MO1xufVxuXG5mdW5jdGlvbiBlc2NhcGVBdHRyKHN0cjogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHN0ci5yZXBsYWNlKC9cIi9nLCBcIiZxdW90O1wiKS5yZXBsYWNlKC8nL2csIFwiJiMzOTtcIikucmVwbGFjZSgvPC9nLCBcIiZsdDtcIikucmVwbGFjZSgvPi9nLCBcIiZndDtcIik7XG59XG5cbmNvbnN0IEtOT1dOX1RJRVJTID0gW1wiZnJlZVwiLCBcInByb1wiLCBcInBvd2VyXCJdO1xuZnVuY3Rpb24gc2FuaXRpemVUaWVyKHRpZXI6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBLTk9XTl9USUVSUy5pbmNsdWRlcyh0aWVyKSA/IHRpZXIgOiBcImZyZWVcIjtcbn1cblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vLyBTdGFydFxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmluaXQoKTtcbiJdLAogICJtYXBwaW5ncyI6ICI7OztBQUdPLE1BQU0sV0FBVztBQUNqQixNQUFNLG9CQUFvQjtBQUMxQixNQUFNLG1CQUFtQjtBQUV6QixNQUFNLE1BQU07QUFBQSxJQUNqQixjQUFjO0FBQUEsSUFDZCxlQUFlO0FBQUEsSUFDZixrQkFBa0I7QUFBQSxJQUNsQixnQkFBZ0I7QUFBQSxJQUNoQixtQkFBbUI7QUFBQSxJQUNuQixxQkFBcUI7QUFBQSxFQUN2Qjs7O0FDWkEsaUJBQXNCLFdBQW1DO0FBQ3ZELFVBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxtQkFBbUIsZ0JBQWdCLENBQUM7QUFDbkYsVUFBTSxRQUFRLE9BQU8saUJBQWlCO0FBQ3RDLFVBQU0sU0FBUyxPQUFPLGdCQUFnQjtBQUV0QyxRQUFJLENBQUMsU0FBUyxDQUFDLE9BQVEsUUFBTztBQUU5QixVQUFNLFdBQVcsSUFBSSxLQUFLLE1BQU0sRUFBRSxRQUFRO0FBQzFDLFFBQUksQ0FBQyxPQUFPLFNBQVMsUUFBUSxLQUFLLFdBQVcsS0FBSyxJQUFJLEdBQUc7QUFDdkQsWUFBTSxXQUFXO0FBQ2pCLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTztBQUFBLEVBQ1Q7QUFTQSxpQkFBc0IsYUFBNEI7QUFDaEQsVUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLENBQUMsbUJBQW1CLGdCQUFnQixDQUFDO0FBQUEsRUFDekU7QUFFQSxpQkFBc0IsZUFBaUM7QUFDckQsVUFBTSxRQUFRLE1BQU0sU0FBUztBQUM3QixXQUFPLFVBQVU7QUFBQSxFQUNuQjs7O0FDSUEsTUFBSSxRQUFvQjtBQUN4QixNQUFJLFdBQTRCO0FBQ2hDLE1BQUksWUFBOEI7QUFDbEMsTUFBSSxhQUEwQixDQUFDO0FBQy9CLE1BQUksZ0JBQWdCO0FBQ3BCLE1BQUksZUFBZTtBQUNuQixNQUFJLGVBQWU7QUFDbkIsTUFBSSxxQkFBcUI7QUFDekIsTUFBSSxzQkFBc0I7QUFDMUIsTUFBSSxlQUFlO0FBRW5CLE1BQU0sVUFBVSxTQUFTLGVBQWUsU0FBUztBQUNqRCxNQUFNLGNBQWMsU0FBUyxlQUFlLGNBQWM7QUFNMUQsaUJBQWUsT0FBc0I7QUFFbkMsVUFBTSxDQUFDLEdBQUcsSUFBSSxNQUFNLE9BQU8sS0FBSyxNQUFNLEVBQUUsUUFBUSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQzNFLFFBQUksS0FBSztBQUNQLHNCQUFnQixJQUFJLE9BQU87QUFDM0IscUJBQWUsSUFBSSxNQUFNO0FBQUEsSUFDM0I7QUFFQSxVQUFNLFFBQVEsTUFBTSxhQUFhO0FBQ2pDLFFBQUksQ0FBQyxPQUFPO0FBQ1YsY0FBUTtBQUNSLGFBQU87QUFDUDtBQUFBLElBQ0Y7QUFHQSxVQUFNLFFBQVEsTUFBTSxTQUFTO0FBQzdCLFFBQUksQ0FBQyxPQUFPO0FBQ1YsY0FBUTtBQUNSLGFBQU87QUFDUDtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLFFBQVEseUJBQXlCO0FBQUEsUUFDMUQsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLEdBQUc7QUFBQSxNQUM5QyxDQUFDO0FBRUQsVUFBSSxDQUFDLElBQUksSUFBSTtBQUNYLGNBQU0sV0FBVztBQUNqQixnQkFBUTtBQUNSLGVBQU87QUFDUDtBQUFBLE1BQ0Y7QUFFQSxpQkFBVyxNQUFNLElBQUksS0FBSztBQUUxQixZQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxnQkFBZ0IsU0FBUyxDQUFDO0FBQzNELGNBQVE7QUFBQSxJQUNWLFFBQVE7QUFFTixZQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLGdCQUFnQjtBQUM5RCxZQUFNLElBQUksT0FBTztBQUNqQixVQUFJLEtBQUssT0FBTyxFQUFFLFdBQVcsWUFBWSxPQUFPLEVBQUUsU0FBUyxZQUFZLE9BQU8sRUFBRSxVQUFVLFVBQVU7QUFDbEcsbUJBQVc7QUFDWCxnQkFBUTtBQUFBLE1BQ1YsT0FBTztBQUNMLGdCQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQU1BLFNBQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxZQUFZO0FBQ2hELFFBQUksUUFBUSxTQUFTLElBQUksa0JBQWtCO0FBQ3pDLGtCQUFZO0FBQUEsUUFDVixVQUFVLFFBQVE7QUFBQSxRQUNsQixjQUFjLFFBQVE7QUFBQSxRQUN0QixLQUFLLFFBQVE7QUFBQSxRQUNiLFdBQVcsUUFBUTtBQUFBLE1BQ3JCO0FBQ0EsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBSSxRQUFRLFNBQVMsSUFBSSxtQkFBbUI7QUFDMUMsbUJBQWEsUUFBUSxjQUFjLENBQUM7QUFDcEMsVUFBSSxVQUFVLG1CQUFtQixVQUFVLFdBQVc7QUFDcEQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsUUFBSSxRQUFRLFNBQVMsSUFBSSxlQUFlO0FBQ3RDLFVBQUksVUFBVSxXQUFXO0FBQ3ZCLGdCQUFRO0FBQ1IsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsUUFBSSxRQUFRLFNBQVMscUJBQXFCO0FBRXhDLFdBQUs7QUFBQSxJQUNQO0FBQUEsRUFDRixDQUFDO0FBTUQsV0FBUyxTQUFlO0FBQ3RCLGtCQUFjO0FBRWQsWUFBUSxPQUFPO0FBQUEsTUFDYixLQUFLO0FBQ0gscUJBQWE7QUFDYjtBQUFBLE1BQ0YsS0FBSztBQUNILHlCQUFpQjtBQUNqQjtBQUFBLE1BQ0YsS0FBSztBQUNILDRCQUFvQjtBQUNwQjtBQUFBLE1BQ0YsS0FBSztBQUNILHNCQUFjO0FBQ2Q7QUFBQSxNQUNGLEtBQUs7QUFDSCxzQkFBYztBQUNkO0FBQUEsTUFDRixLQUFLO0FBQ0gsdUJBQWU7QUFDZjtBQUFBLE1BQ0YsS0FBSztBQUNILHNCQUFjO0FBQ2Q7QUFBQSxNQUNGLEtBQUs7QUFDSCxvQkFBWTtBQUNaO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixRQUFJLENBQUMsVUFBVTtBQUNiLGtCQUFZLFlBQVk7QUFDeEI7QUFBQSxJQUNGO0FBRUEsZ0JBQVksWUFBWTtBQUFBO0FBQUEsUUFFbEIsV0FBVyxTQUFTLFNBQVMsV0FBVyxDQUFDO0FBQUE7QUFBQSxtQ0FFZCxlQUFlLEtBQUssUUFBUTtBQUFBO0FBQUEsVUFFckQsV0FBVyxTQUFTLFNBQVMsU0FBUyxNQUFNLENBQUM7QUFBQSx1Q0FDaEIsYUFBYSxTQUFTLElBQUksQ0FBQyxLQUFLLFdBQVcsU0FBUyxJQUFJLENBQUM7QUFBQTtBQUFBLHVDQUV6RCxRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFNN0MsYUFBUyxlQUFlLGdCQUFnQixHQUFHLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUMxRSxRQUFFLGdCQUFnQjtBQUNsQixxQkFBZSxDQUFDO0FBQ2hCLG9CQUFjO0FBQUEsSUFDaEIsQ0FBQztBQUVELGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9FLFlBQU0sV0FBVztBQUNqQixZQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8sZ0JBQWdCO0FBQ2xELGlCQUFXO0FBQ1gscUJBQWU7QUFDZixjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUdELGFBQVMsaUJBQWlCLFNBQVMsTUFBTTtBQUN2QyxVQUFJLGNBQWM7QUFDaEIsdUJBQWU7QUFDZixzQkFBYztBQUFBLE1BQ2hCO0FBQUEsSUFDRixHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFBQSxFQUNuQjtBQUVBLFdBQVMsZUFBcUI7QUFDNUIsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUXBCLGFBQVMsZUFBZSxhQUFhLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN0RSxhQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssR0FBRyxRQUFRLGtCQUFrQixDQUFDO0FBQ3hELGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsbUJBQXlCO0FBQ2hDLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBU3BCLGFBQVMsZUFBZSxnQkFBZ0IsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3pFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsc0JBQTRCO0FBQ25DLFVBQU0sZUFBZSxjQUFjLFNBQVMsS0FDeEMsY0FBYyxNQUFNLEdBQUcsRUFBRSxJQUFJLFFBQzdCO0FBRUosUUFBSSxpQkFBaUI7QUFDckIsUUFBSSxXQUFXLFNBQVMsR0FBRztBQUN6Qix1QkFBaUI7QUFBQTtBQUFBLFFBRWIsV0FDQztBQUFBLFFBQ0MsQ0FBQyxHQUFHLE1BQU07QUFBQSwyQ0FDdUIsQ0FBQztBQUFBLHlDQUNILFdBQVcsRUFBRSxJQUFJLENBQUM7QUFBQSw2Q0FDZCxXQUFXLEVBQUUsUUFBUSxDQUFDO0FBQUEsNkVBQ1UsQ0FBQztBQUFBO0FBQUE7QUFBQSxNQUd0RSxFQUNDLEtBQUssRUFBRSxDQUFDO0FBQUE7QUFBQSxJQUVmO0FBRUEsWUFBUSxZQUFZO0FBQUEsMERBQ29DLFdBQVcsWUFBWSxDQUFDO0FBQUEsTUFDNUUsY0FBYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBYWxCLGFBQVMsZUFBZSxVQUFVLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUNuRSxhQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sSUFBSSxjQUFjLE9BQU8sYUFBYSxDQUFDO0FBQzFFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBR0QsYUFBUyxpQkFBaUIsa0JBQWtCLEVBQUUsUUFBUSxDQUFDLFFBQVE7QUFDN0QsVUFBSSxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDbkMsY0FBTSxNQUFNLFNBQVUsRUFBRSxPQUF1QixRQUFRLE9BQU8sR0FBRztBQUNqRSxjQUFNLElBQUksV0FBVyxHQUFHO0FBQ3hCLFlBQUksR0FBRztBQUNMLHNCQUFZO0FBQUEsWUFDVixVQUFVLEVBQUU7QUFBQSxZQUNaLGNBQWMsRUFBRTtBQUFBLFlBQ2hCLEtBQUs7QUFBQSxZQUNMLFdBQVcsU0FBUztBQUFBLFVBQ3RCO0FBQ0Esa0JBQVE7QUFDUixpQkFBTztBQUFBLFFBQ1Q7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxhQUFTLGVBQWUsaUJBQWlCLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUMxRSxZQUFNLEtBQUssU0FBUyxlQUFlLGtCQUFrQjtBQUNyRCxVQUFJLFVBQVUsT0FBTyxNQUFNO0FBQUEsSUFDN0IsQ0FBQztBQUdELGFBQVMsZUFBZSxrQkFBa0IsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQzNFLFlBQU0sUUFBUSxTQUFTLGVBQWUsaUJBQWlCO0FBQ3ZELFlBQU0sV0FBVyxPQUFPLE1BQU0sS0FBSztBQUNuQyxVQUFJLFVBQVU7QUFDWixvQkFBWTtBQUFBLFVBQ1Y7QUFBQSxVQUNBLGNBQWM7QUFBQSxVQUNkLEtBQUs7QUFBQSxVQUNMLFdBQVc7QUFBQSxRQUNiO0FBQ0EsZ0JBQVE7QUFDUixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVNwQixhQUFTLGVBQWUsYUFBYSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDdEUsYUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLElBQUksZUFBZSxPQUFPLGFBQWEsQ0FBQztBQUMzRSxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTLGdCQUFzQjtBQUM3QixRQUFJLENBQUMsVUFBVztBQUVoQixVQUFNLE9BQU8sVUFBVSxRQUFRO0FBQy9CLFVBQU0saUJBQWlCLFNBQVM7QUFDaEMsVUFBTSxlQUFlLFVBQVUsYUFBYSxJQUFJLE1BQU0sR0FBRyxHQUFHO0FBRTVELFlBQVEsWUFBWTtBQUFBLDBEQUNvQztBQUFBLE1BQ3BELFVBQVUsSUFBSSxTQUFTLEtBQUssVUFBVSxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUksUUFBUSxVQUFVO0FBQUEsSUFDN0UsQ0FBQztBQUFBO0FBQUE7QUFBQSxRQUlHLFVBQVUsZUFDTixpQ0FBaUMsV0FBVyxVQUFVLGFBQWEsTUFBTSxHQUFHLEdBQUcsQ0FBQyxDQUFDLFdBQ2pGLEVBQ047QUFBQSw4QkFDd0IsV0FBVyxVQUFVLFFBQVEsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVFQUlXLFdBQVcsV0FBVyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FRMUQsaUJBQWlCLGFBQWEsRUFBRTtBQUFBLGdFQUNKLGlCQUFpQixhQUFhLEVBQUU7QUFBQTtBQUFBLFlBRXBGLGlCQUFpQiw2Q0FBNkMsRUFBRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFVMUUsYUFBUyxlQUFlLGdCQUFnQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDekUsa0JBQVk7QUFDWixhQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sSUFBSSxjQUFjLE9BQU8sYUFBYSxDQUFDO0FBQzFFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBRUQsYUFBUyxlQUFlLFlBQVksR0FBRyxpQkFBaUIsU0FBUyxhQUFhO0FBQUEsRUFDaEY7QUFFQSxpQkFBZSxnQkFBK0I7QUFDNUMsUUFBSSxDQUFDLGFBQWEsVUFBVSxXQUFZO0FBRXhDLFVBQU0sWUFBWSxTQUFTLGVBQWUsY0FBYztBQUN4RCxVQUFNLE9BQU8sV0FBVyxNQUFNLEtBQUssS0FBSztBQUN4QyxVQUFNLFlBQ0gsU0FBUyxjQUFjLGlDQUFpQyxHQUF3QixTQUFTO0FBRTVGLFlBQVE7QUFDUix5QkFBcUI7QUFDckIsMEJBQXNCLFVBQVU7QUFDaEMsV0FBTztBQUVQLFFBQUk7QUFDRixZQUFNLFFBQVEsTUFBTSxTQUFTO0FBQzdCLFVBQUksQ0FBQyxPQUFPO0FBQ1YsdUJBQWU7QUFDZixnQkFBUTtBQUNSLGVBQU87QUFDUDtBQUFBLE1BQ0Y7QUFFQSxZQUFNLE1BQU0sTUFBTSxNQUFNLEdBQUcsUUFBUSwyQkFBMkI7QUFBQSxRQUM1RCxRQUFRO0FBQUEsUUFDUixTQUFTO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxVQUNoQixlQUFlLFVBQVUsS0FBSztBQUFBLFFBQ2hDO0FBQUEsUUFDQSxNQUFNLEtBQUssVUFBVTtBQUFBLFVBQ25CO0FBQUEsVUFDQSxLQUFLLFVBQVU7QUFBQSxVQUNmLFVBQVUsVUFBVTtBQUFBLFVBQ3BCO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBRUQsVUFBSSxJQUFJLElBQUk7QUFDVixnQkFBUTtBQUNSLGVBQU87QUFDUDtBQUFBLE1BQ0Y7QUFFQSxZQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUssRUFBRSxNQUFNLE1BQU0sSUFBSTtBQUU5QyxVQUFJLE1BQU0sU0FBUyxzQkFBc0I7QUFDdkMsdUJBQWUsR0FBRyxLQUFLLFdBQVcsS0FBSyxTQUFTLHdCQUF3QjtBQUN4RSxnQkFBUTtBQUNSLGVBQU87QUFFUCxjQUFNLGVBQWUsUUFBUSxjQUFjLFVBQVU7QUFDckQsWUFBSSxjQUFjO0FBQ2hCLHVCQUFhLFlBQVksU0FBUyxjQUFjLElBQUksQ0FBQztBQUNyRCxnQkFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0FBQ3ZDLGVBQUssT0FBTyxHQUFHLFFBQVE7QUFDdkIsZUFBSyxTQUFTO0FBQ2QsZUFBSyxNQUFNLFFBQVE7QUFDbkIsZUFBSyxjQUFjO0FBQ25CLHVCQUFhLFlBQVksSUFBSTtBQUFBLFFBQy9CO0FBQ0E7QUFBQSxNQUNGO0FBRUEscUJBQWUsTUFBTSxXQUFXLE1BQU0sU0FBUyxXQUFXLElBQUksTUFBTTtBQUNwRSxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsUUFBUTtBQUNOLHFCQUFlO0FBQ2YsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFdBQVMsaUJBQXVCO0FBQzlCLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU10QjtBQUVBLFdBQVMsZ0JBQXNCO0FBQzdCLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUlILFdBQVcsa0JBQWtCLENBQUM7QUFBQSxRQUN6QyxzQkFBc0Isc0NBQXNDLFdBQVcsb0JBQW9CLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQywyQkFBMkIsRUFBRTtBQUFBO0FBQUEsa0RBRTNGLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU14RCxhQUFTLGVBQWUsbUJBQW1CLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUM1RSxrQkFBWTtBQUNaLG1CQUFhLENBQUM7QUFDZCxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxXQUFTLGNBQW9CO0FBQzNCLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSVgsV0FBVyxZQUFZLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFLakMsYUFBUyxlQUFlLGVBQWUsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3hFLGNBQVEsWUFBWSxZQUFZO0FBQ2hDLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBTUEsV0FBUyxXQUFXLEtBQXFCO0FBQ3ZDLFVBQU0sTUFBTSxTQUFTLGNBQWMsS0FBSztBQUN4QyxRQUFJLGNBQWM7QUFDbEIsV0FBTyxJQUFJO0FBQUEsRUFDYjtBQUVBLFdBQVMsV0FBVyxLQUFxQjtBQUN2QyxXQUFPLElBQUksUUFBUSxNQUFNLFFBQVEsRUFBRSxRQUFRLE1BQU0sT0FBTyxFQUFFLFFBQVEsTUFBTSxNQUFNLEVBQUUsUUFBUSxNQUFNLE1BQU07QUFBQSxFQUN0RztBQUVBLE1BQU0sY0FBYyxDQUFDLFFBQVEsT0FBTyxPQUFPO0FBQzNDLFdBQVMsYUFBYSxNQUFzQjtBQUMxQyxXQUFPLFlBQVksU0FBUyxJQUFJLElBQUksT0FBTztBQUFBLEVBQzdDO0FBTUEsT0FBSzsiLAogICJuYW1lcyI6IFtdCn0K
