"use strict";
(() => {
  // src/shared/constants.ts
  var BASE_URL = "https://ftc.bd73.com";
  var TOKEN_STORAGE_KEY = "ftc_extension_token";
  var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
  var MSG = {
    START_PICKER: "FTC_START_PICKER",
    CANCEL_PICKER: "FTC_CANCEL_PICKER",
    ELEMENT_SELECTED: "FTC_ELEMENT_SELECTED",
    GET_CANDIDATES: "FTC_GET_CANDIDATES",
    CANDIDATES_RESULT: "FTC_CANDIDATES_RESULT",
    FTC_EXTENSION_TOKEN: "FTC_EXTENSION_TOKEN"
  };

  // src/auth/token.ts
  async function getToken() {
    const result = await chrome.storage.local.get([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
    const token = result[TOKEN_STORAGE_KEY];
    const expiry = result[TOKEN_EXPIRY_KEY];
    if (!token || !expiry) return null;
    const expiryMs = new Date(expiry).getTime();
    if (!Number.isFinite(expiryMs) || expiryMs < Date.now()) {
      await clearToken();
      return null;
    }
    return token;
  }
  async function clearToken() {
    await chrome.storage.local.remove([TOKEN_STORAGE_KEY, TOKEN_EXPIRY_KEY]);
  }
  async function isTokenValid() {
    const token = await getToken();
    return token !== null;
  }

  // src/popup/utils.ts
  function escapeAttr(str) {
    return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  var KNOWN_TIERS = ["free", "pro", "power"];
  function sanitizeTier(tier) {
    return KNOWN_TIERS.includes(tier) ? tier : "free";
  }

  // src/popup/popup.ts
  var state = "unauthenticated";
  var userInfo = null;
  var selection = null;
  var candidates = [];
  var currentTabUrl = "";
  var currentTabTitle = "";
  var currentTabId = 0;
  var errorMessage = "";
  var createdMonitorName = "";
  var createdMonitorValue = "";
  var dropdownOpen = false;
  var content = document.getElementById("content");
  var accountArea = document.getElementById("account-area");
  async function init() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      currentTabUrl = tab.url || "";
      currentTabTitle = tab.title || "";
      currentTabId = tab.id || 0;
    }
    const valid = await isTokenValid();
    if (!valid) {
      state = "unauthenticated";
      render();
      return;
    }
    const token = await getToken();
    if (!token) {
      state = "unauthenticated";
      render();
      return;
    }
    try {
      const res = await fetch(`${BASE_URL}/api/extension/verify`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) {
        await clearToken();
        state = "unauthenticated";
        render();
        return;
      }
      userInfo = await res.json().catch(() => null);
      if (!userInfo || typeof userInfo.userId !== "string") {
        await clearToken();
        state = "unauthenticated";
        render();
        return;
      }
      await chrome.storage.local.set({ cachedUserInfo: userInfo });
      state = "authenticated";
    } catch {
      const cached = await chrome.storage.local.get("cachedUserInfo");
      const c = cached.cachedUserInfo;
      if (c && typeof c.userId === "string" && typeof c.tier === "string" && typeof c.email === "string") {
        userInfo = c;
        state = "authenticated";
      } else {
        state = "unauthenticated";
      }
    }
    render();
  }
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === MSG.ELEMENT_SELECTED) {
      selection = {
        selector: message.selector,
        currentValue: message.currentValue,
        url: message.url,
        pageTitle: message.pageTitle
      };
      state = "confirm";
      render();
    }
    if (message.type === MSG.CANDIDATES_RESULT) {
      candidates = message.candidates || [];
      if (state === "authenticated" || state === "picking") {
        render();
      }
    }
    if (message.type === MSG.CANCEL_PICKER) {
      if (state === "picking") {
        state = "authenticated";
        render();
      }
    }
    if (message.type === "FTC_AUTH_COMPLETE") {
      init();
    }
  });
  function render() {
    renderAccount();
    switch (state) {
      case "unauthenticated":
        renderUnauth();
        break;
      case "connecting":
        renderConnecting();
        break;
      case "authenticated":
        renderAuthenticated();
        break;
      case "picking":
        renderPicking();
        break;
      case "confirm":
        renderConfirm();
        break;
      case "creating":
        renderCreating();
        break;
      case "success":
        renderSuccess();
        break;
      case "error":
        renderError();
        break;
    }
  }
  function renderAccount() {
    if (!userInfo) {
      accountArea.innerHTML = "";
      return;
    }
    accountArea.innerHTML = `
    <button class="account-btn" id="account-toggle">
      ${escapeHtml(userInfo.email || "Connected")} &#9662;
    </button>
    <div class="account-dropdown ${dropdownOpen ? "" : "hidden"}" id="account-dropdown">
      <div class="dropdown-email">
        ${escapeHtml(userInfo.email || userInfo.userId)}
        <span class="tier-badge tier-${sanitizeTier(userInfo.tier)}">${escapeHtml(userInfo.tier)}</span>
      </div>
      <a class="dropdown-item" href="${BASE_URL}/dashboard" target="_blank">Open dashboard</a>
      <div class="dropdown-divider"></div>
      <button class="dropdown-item" id="disconnect-btn">Disconnect</button>
    </div>
  `;
    document.getElementById("account-toggle")?.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdownOpen = !dropdownOpen;
      renderAccount();
    });
    document.getElementById("disconnect-btn")?.addEventListener("click", async () => {
      await clearToken();
      await chrome.storage.local.remove("cachedUserInfo");
      userInfo = null;
      dropdownOpen = false;
      state = "unauthenticated";
      render();
    });
    document.addEventListener("click", () => {
      if (dropdownOpen) {
        dropdownOpen = false;
        renderAccount();
      }
    }, { once: true });
  }
  function renderUnauth() {
    content.innerHTML = `
    <div class="unauth">
      <h2>Track what matters on any webpage.</h2>
      <button class="btn btn-primary btn-full" id="connect-btn">Connect your account</button>
      <p>Already have an account? Sign in above.</p>
    </div>
  `;
    document.getElementById("connect-btn")?.addEventListener("click", () => {
      chrome.tabs.create({ url: `${BASE_URL}/extension-auth` });
      state = "connecting";
      render();
    });
  }
  function renderConnecting() {
    content.innerHTML = `
    <div class="connecting">
      <div class="spinner"></div>
      <p>Connecting...</p>
      <p>Waiting for you to sign in at FetchTheChange.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-connect" style="margin-top: 16px;">Cancel</button>
    </div>
  `;
    document.getElementById("cancel-connect")?.addEventListener("click", () => {
      state = "unauthenticated";
      render();
    });
  }
  function renderAuthenticated() {
    const truncatedUrl = currentTabUrl.length > 45 ? currentTabUrl.slice(0, 45) + "..." : currentTabUrl;
    let candidatesHtml = "";
    if (candidates.length > 0) {
      candidatesHtml = `
      <div class="section-header">Suggested elements</div>
      ${candidates.map(
        (c, i) => `
        <div class="candidate" data-idx="${i}">
          <span class="candidate-text">${escapeHtml(c.text)}</span>
          <span class="candidate-selector">${escapeHtml(c.selector)}</span>
          <button class="btn btn-primary btn-sm candidate-track" data-idx="${i}">Track this</button>
        </div>
      `
      ).join("")}
    `;
    }
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(truncatedUrl)}</div>
    ${candidatesHtml}
    <div class="section-header">Or pick manually</div>
    <button class="btn btn-primary btn-full" id="pick-btn">Pick an element on this page</button>
    <button class="advanced-toggle" id="advanced-toggle">&#9662; Advanced (CSS selector)</button>
    <div class="advanced-content" id="advanced-content">
      <div class="form-group">
        <input type="text" class="form-input" id="manual-selector" placeholder="e.g. .product-price">
      </div>
      <button class="btn btn-secondary btn-sm" id="manual-track-btn">Use this selector</button>
    </div>
  `;
    document.getElementById("pick-btn")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.querySelectorAll(".candidate-track").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const idx = parseInt(e.target.dataset.idx || "0");
        const c = candidates[idx];
        if (c) {
          selection = {
            selector: c.selector,
            currentValue: c.text,
            url: currentTabUrl,
            pageTitle: currentTabTitle
          };
          state = "confirm";
          render();
        }
      });
    });
    document.getElementById("advanced-toggle")?.addEventListener("click", () => {
      const el = document.getElementById("advanced-content");
      el?.classList.toggle("open");
    });
    document.getElementById("manual-track-btn")?.addEventListener("click", () => {
      const input = document.getElementById("manual-selector");
      const selector = input?.value.trim();
      if (selector) {
        selection = {
          selector,
          currentValue: "",
          url: currentTabUrl,
          pageTitle: ""
        };
        state = "confirm";
        render();
      }
    });
  }
  function renderPicking() {
    content.innerHTML = `
    <div class="picker-info">
      <div class="icon">&#127919;</div>
      <p><strong>Click any element on the page to track it.</strong></p>
      <p>Press Esc to cancel.</p>
      <button class="btn btn-secondary btn-sm" id="cancel-pick" style="margin-top: 16px;">Cancel picking</button>
    </div>
  `;
    document.getElementById("cancel-pick")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: MSG.CANCEL_PICKER, tabId: currentTabId });
      state = "authenticated";
      render();
    });
  }
  function renderConfirm() {
    if (!selection) return;
    const tier = userInfo?.tier || "free";
    const hourlyDisabled = tier === "free";
    const defaultName = (selection.pageTitle || "").slice(0, 100);
    content.innerHTML = `
    <div class="current-url"><strong>Tracking:</strong> ${escapeHtml(
      selection.url.length > 45 ? selection.url.slice(0, 45) + "..." : selection.url
    )}</div>
    <div class="confirm-card">
      <div class="label">Element selected</div>
      ${selection.currentValue ? `<div class="value">Currently: ${escapeHtml(selection.currentValue.slice(0, 100))}</div>` : ""}
      <div class="selector">${escapeHtml(selection.selector)}</div>
    </div>
    <div class="form-group">
      <label class="form-label">Monitor name</label>
      <input type="text" class="form-input" id="monitor-name" value="${escapeAttr(defaultName)}" maxlength="100">
    </div>
    <div class="form-group">
      <label class="form-label">Check frequency</label>
      <div class="radio-group">
        <label class="radio-label">
          <input type="radio" name="frequency" value="daily" checked> Daily
        </label>
        <label class="radio-label ${hourlyDisabled ? "disabled" : ""}">
          <input type="radio" name="frequency" value="hourly" ${hourlyDisabled ? "disabled" : ""}>
          Hourly
          ${hourlyDisabled ? '<span class="tooltip-text">(Pro+)</span>' : ""}
        </label>
      </div>
    </div>
    <div class="btn-row">
      <button class="btn btn-secondary" id="pick-again-btn">Pick again</button>
      <button class="btn btn-primary" id="create-btn">Create monitor</button>
    </div>
  `;
    document.getElementById("pick-again-btn")?.addEventListener("click", () => {
      selection = null;
      chrome.runtime.sendMessage({ type: MSG.START_PICKER, tabId: currentTabId });
      state = "picking";
      render();
    });
    document.getElementById("create-btn")?.addEventListener("click", createMonitor);
  }
  async function createMonitor() {
    if (!selection || state === "creating") return;
    const nameInput = document.getElementById("monitor-name");
    const name = nameInput?.value.trim() || "Untitled monitor";
    const frequency = document.querySelector('input[name="frequency"]:checked')?.value || "daily";
    state = "creating";
    createdMonitorName = name;
    createdMonitorValue = selection.currentValue;
    render();
    try {
      const token = await getToken();
      if (!token) {
        errorMessage = "Not authenticated. Please reconnect.";
        state = "error";
        render();
        return;
      }
      const res = await fetch(`${BASE_URL}/api/extension/monitors`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name,
          url: selection.url,
          selector: selection.selector,
          frequency
        })
      });
      if (res.ok) {
        state = "success";
        render();
        return;
      }
      const data = await res.json().catch(() => null);
      if (data?.code === "TIER_LIMIT_REACHED") {
        errorMessage = `${data.message || data.error || "Monitor limit reached."}`;
        state = "error";
        render();
        const errContainer = content.querySelector(".error p");
        if (errContainer) {
          errContainer.appendChild(document.createElement("br"));
          const link = document.createElement("a");
          link.href = `${BASE_URL}/pricing`;
          link.target = "_blank";
          link.style.color = "#6366f1";
          link.textContent = "Upgrade your plan";
          errContainer.appendChild(link);
        }
        return;
      }
      errorMessage = data?.message || data?.error || `Failed (${res.status})`;
      state = "error";
      render();
    } catch {
      errorMessage = "Network error. Please try again.";
      state = "error";
      render();
    }
  }
  function renderCreating() {
    content.innerHTML = `
    <div class="connecting" style="padding-top: 64px;">
      <div class="spinner"></div>
      <p>Creating monitor...</p>
    </div>
  `;
  }
  function renderSuccess() {
    content.innerHTML = `
    <div class="success">
      <div class="icon">&#10003;</div>
      <h3>Monitor created!</h3>
      <p><strong>${escapeHtml(createdMonitorName)}</strong> is now being watched.</p>
      ${createdMonitorValue ? `<p>You'll be notified when <strong>${escapeHtml(createdMonitorValue.slice(0, 60))}</strong> changes.</p>` : ""}
      <div class="btn-row" style="margin-top: 24px; justify-content: center;">
        <a class="btn btn-primary btn-sm" href="${BASE_URL}/dashboard" target="_blank">View in dashboard</a>
        <button class="btn btn-secondary btn-sm" id="track-another-btn">Track another</button>
      </div>
    </div>
  `;
    document.getElementById("track-another-btn")?.addEventListener("click", () => {
      selection = null;
      candidates = [];
      state = "authenticated";
      render();
    });
  }
  function renderError() {
    content.innerHTML = `
    <div class="error">
      <div class="icon">&#10007;</div>
      <h3>Couldn't create monitor</h3>
      <p>${escapeHtml(errorMessage)}</p>
      <button class="btn btn-secondary" id="try-again-btn">Try again</button>
    </div>
  `;
    document.getElementById("try-again-btn")?.addEventListener("click", () => {
      state = selection ? "confirm" : "authenticated";
      render();
    });
  }
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }
  init();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL3NoYXJlZC9jb25zdGFudHMudHMiLCAiLi4vLi4vc3JjL2F1dGgvdG9rZW4udHMiLCAiLi4vLi4vc3JjL3BvcHVwL3V0aWxzLnRzIiwgIi4uLy4uL3NyYy9wb3B1cC9wb3B1cC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLy8gQkFTRV9VUkwgaXMgaW5qZWN0ZWQgYXQgYnVpbGQgdGltZSB2aWEgZXNidWlsZCBkZWZpbmUuXG4vLyBTZXQgQkFTRV9VUkwgZW52IHZhciB0byBvdmVycmlkZSAoZGVmYXVsdDogaHR0cHM6Ly9mdGMuYmQ3My5jb20pXG5kZWNsYXJlIGNvbnN0IEJBU0VfVVJMX0lOSkVDVEVEOiBzdHJpbmc7XG5leHBvcnQgY29uc3QgQkFTRV9VUkwgPSBCQVNFX1VSTF9JTkpFQ1RFRDtcbmV4cG9ydCBjb25zdCBUT0tFTl9TVE9SQUdFX0tFWSA9IFwiZnRjX2V4dGVuc2lvbl90b2tlblwiO1xuZXhwb3J0IGNvbnN0IFRPS0VOX0VYUElSWV9LRVkgPSBcImZ0Y19leHRlbnNpb25fdG9rZW5fZXhwaXJ5XCI7XG5cbmV4cG9ydCBjb25zdCBNU0cgPSB7XG4gIFNUQVJUX1BJQ0tFUjogXCJGVENfU1RBUlRfUElDS0VSXCIsXG4gIENBTkNFTF9QSUNLRVI6IFwiRlRDX0NBTkNFTF9QSUNLRVJcIixcbiAgRUxFTUVOVF9TRUxFQ1RFRDogXCJGVENfRUxFTUVOVF9TRUxFQ1RFRFwiLFxuICBHRVRfQ0FORElEQVRFUzogXCJGVENfR0VUX0NBTkRJREFURVNcIixcbiAgQ0FORElEQVRFU19SRVNVTFQ6IFwiRlRDX0NBTkRJREFURVNfUkVTVUxUXCIsXG4gIEZUQ19FWFRFTlNJT05fVE9LRU46IFwiRlRDX0VYVEVOU0lPTl9UT0tFTlwiLFxufSBhcyBjb25zdDtcbiIsICJpbXBvcnQgeyBUT0tFTl9TVE9SQUdFX0tFWSwgVE9LRU5fRVhQSVJZX0tFWSB9IGZyb20gXCIuLi9zaGFyZWQvY29uc3RhbnRzXCI7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUb2tlbigpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFtUT0tFTl9TVE9SQUdFX0tFWSwgVE9LRU5fRVhQSVJZX0tFWV0pO1xuICBjb25zdCB0b2tlbiA9IHJlc3VsdFtUT0tFTl9TVE9SQUdFX0tFWV07XG4gIGNvbnN0IGV4cGlyeSA9IHJlc3VsdFtUT0tFTl9FWFBJUllfS0VZXTtcblxuICBpZiAoIXRva2VuIHx8ICFleHBpcnkpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGV4cGlyeU1zID0gbmV3IERhdGUoZXhwaXJ5KS5nZXRUaW1lKCk7XG4gIGlmICghTnVtYmVyLmlzRmluaXRlKGV4cGlyeU1zKSB8fCBleHBpcnlNcyA8IERhdGUubm93KCkpIHtcbiAgICBhd2FpdCBjbGVhclRva2VuKCk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICByZXR1cm4gdG9rZW47XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRUb2tlbih0b2tlbjogc3RyaW5nLCBleHBpcmVzQXQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1xuICAgIFtUT0tFTl9TVE9SQUdFX0tFWV06IHRva2VuLFxuICAgIFtUT0tFTl9FWFBJUllfS0VZXTogZXhwaXJlc0F0LFxuICB9KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyVG9rZW4oKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnJlbW92ZShbVE9LRU5fU1RPUkFHRV9LRVksIFRPS0VOX0VYUElSWV9LRVldKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGlzVG9rZW5WYWxpZCgpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgY29uc3QgdG9rZW4gPSBhd2FpdCBnZXRUb2tlbigpO1xuICByZXR1cm4gdG9rZW4gIT09IG51bGw7XG59XG4iLCAiZXhwb3J0IGZ1bmN0aW9uIGVzY2FwZUF0dHIoc3RyOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gc3RyLnJlcGxhY2UoLyYvZywgXCImYW1wO1wiKS5yZXBsYWNlKC9cIi9nLCBcIiZxdW90O1wiKS5yZXBsYWNlKC8nL2csIFwiJiMzOTtcIikucmVwbGFjZSgvPC9nLCBcIiZsdDtcIikucmVwbGFjZSgvPi9nLCBcIiZndDtcIik7XG59XG5cbi8vIEtlZXAgaW4gc3luYyB3aXRoIHNoYXJlZC9tb2RlbHMvYXV0aC50cyBUSUVSX0xJTUlUU1xuY29uc3QgS05PV05fVElFUlMgPSBbXCJmcmVlXCIsIFwicHJvXCIsIFwicG93ZXJcIl07XG5leHBvcnQgZnVuY3Rpb24gc2FuaXRpemVUaWVyKHRpZXI6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBLTk9XTl9USUVSUy5pbmNsdWRlcyh0aWVyKSA/IHRpZXIgOiBcImZyZWVcIjtcbn1cbiIsICJpbXBvcnQgeyBCQVNFX1VSTCwgTVNHIH0gZnJvbSBcIi4uL3NoYXJlZC9jb25zdGFudHNcIjtcbmltcG9ydCB7IGdldFRva2VuLCBjbGVhclRva2VuLCBpc1Rva2VuVmFsaWQgfSBmcm9tIFwiLi4vYXV0aC90b2tlblwiO1xuaW1wb3J0IHsgZXNjYXBlQXR0ciwgc2FuaXRpemVUaWVyIH0gZnJvbSBcIi4vdXRpbHNcIjtcblxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vLyBTdGF0ZVxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmludGVyZmFjZSBVc2VySW5mbyB7XG4gIHVzZXJJZDogc3RyaW5nO1xuICB0aWVyOiBzdHJpbmc7XG4gIGVtYWlsOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBTZWxlY3Rpb24ge1xuICBzZWxlY3Rvcjogc3RyaW5nO1xuICBjdXJyZW50VmFsdWU6IHN0cmluZztcbiAgdXJsOiBzdHJpbmc7XG4gIHBhZ2VUaXRsZTogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgQ2FuZGlkYXRlIHtcbiAgc2VsZWN0b3I6IHN0cmluZztcbiAgdGV4dDogc3RyaW5nO1xuICBzY29yZTogbnVtYmVyO1xufVxuXG50eXBlIFBvcHVwU3RhdGUgPVxuICB8IFwidW5hdXRoZW50aWNhdGVkXCJcbiAgfCBcImNvbm5lY3RpbmdcIlxuICB8IFwiYXV0aGVudGljYXRlZFwiXG4gIHwgXCJwaWNraW5nXCJcbiAgfCBcImNvbmZpcm1cIlxuICB8IFwiY3JlYXRpbmdcIlxuICB8IFwic3VjY2Vzc1wiXG4gIHwgXCJlcnJvclwiO1xuXG5sZXQgc3RhdGU6IFBvcHVwU3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xubGV0IHVzZXJJbmZvOiBVc2VySW5mbyB8IG51bGwgPSBudWxsO1xubGV0IHNlbGVjdGlvbjogU2VsZWN0aW9uIHwgbnVsbCA9IG51bGw7XG5sZXQgY2FuZGlkYXRlczogQ2FuZGlkYXRlW10gPSBbXTtcbmxldCBjdXJyZW50VGFiVXJsID0gXCJcIjtcbmxldCBjdXJyZW50VGFiVGl0bGUgPSBcIlwiO1xubGV0IGN1cnJlbnRUYWJJZCA9IDA7XG5sZXQgZXJyb3JNZXNzYWdlID0gXCJcIjtcbmxldCBjcmVhdGVkTW9uaXRvck5hbWUgPSBcIlwiO1xubGV0IGNyZWF0ZWRNb25pdG9yVmFsdWUgPSBcIlwiO1xubGV0IGRyb3Bkb3duT3BlbiA9IGZhbHNlO1xuXG5jb25zdCBjb250ZW50ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjb250ZW50XCIpITtcbmNvbnN0IGFjY291bnRBcmVhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJhY2NvdW50LWFyZWFcIikhO1xuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIEluaXRpYWxpc2Vcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5hc3luYyBmdW5jdGlvbiBpbml0KCk6IFByb21pc2U8dm9pZD4ge1xuICAvLyBHZXQgY3VycmVudCB0YWIgaW5mb1xuICBjb25zdCBbdGFiXSA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICBpZiAodGFiKSB7XG4gICAgY3VycmVudFRhYlVybCA9IHRhYi51cmwgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiVGl0bGUgPSB0YWIudGl0bGUgfHwgXCJcIjtcbiAgICBjdXJyZW50VGFiSWQgPSB0YWIuaWQgfHwgMDtcbiAgfVxuXG4gIGNvbnN0IHZhbGlkID0gYXdhaXQgaXNUb2tlblZhbGlkKCk7XG4gIGlmICghdmFsaWQpIHtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gVmVyaWZ5IHRva2VuIHdpdGggYmFja2VuZFxuICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gIGlmICghdG9rZW4pIHtcbiAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtCQVNFX1VSTH0vYXBpL2V4dGVuc2lvbi92ZXJpZnlgLCB7XG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0b2tlbn1gIH0sXG4gICAgfSk7XG5cbiAgICBpZiAoIXJlcy5vaykge1xuICAgICAgYXdhaXQgY2xlYXJUb2tlbigpO1xuICAgICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdXNlckluZm8gPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgIGlmICghdXNlckluZm8gfHwgdHlwZW9mIHVzZXJJbmZvLnVzZXJJZCAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgYXdhaXQgY2xlYXJUb2tlbigpO1xuICAgICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIENhY2hlIHVzZXJJbmZvIGZvciBvZmZsaW5lIGZhbGxiYWNrXG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgY2FjaGVkVXNlckluZm86IHVzZXJJbmZvIH0pO1xuICAgIHN0YXRlID0gXCJhdXRoZW50aWNhdGVkXCI7XG4gIH0gY2F0Y2gge1xuICAgIC8vIE5ldHdvcmsgZXJyb3IgXHUyMDE0IHRyeSB0byByZXN0b3JlIGNhY2hlZCB1c2VySW5mbyBzbyB0aWVyL2FjY291bnQgZGlzcGxheSBjb3JyZWN0bHlcbiAgICBjb25zdCBjYWNoZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICBjb25zdCBjID0gY2FjaGVkLmNhY2hlZFVzZXJJbmZvO1xuICAgIGlmIChjICYmIHR5cGVvZiBjLnVzZXJJZCA9PT0gXCJzdHJpbmdcIiAmJiB0eXBlb2YgYy50aWVyID09PSBcInN0cmluZ1wiICYmIHR5cGVvZiBjLmVtYWlsID09PSBcInN0cmluZ1wiKSB7XG4gICAgICB1c2VySW5mbyA9IGM7XG4gICAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZSA9IFwidW5hdXRoZW50aWNhdGVkXCI7XG4gICAgfVxuICB9XG5cbiAgcmVuZGVyKCk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gTGlzdGVuIGZvciBtZXNzYWdlcyBmcm9tIGJhY2tncm91bmQvY29udGVudFxuLy8gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSkgPT4ge1xuICBpZiAobWVzc2FnZS50eXBlID09PSBNU0cuRUxFTUVOVF9TRUxFQ1RFRCkge1xuICAgIHNlbGVjdGlvbiA9IHtcbiAgICAgIHNlbGVjdG9yOiBtZXNzYWdlLnNlbGVjdG9yLFxuICAgICAgY3VycmVudFZhbHVlOiBtZXNzYWdlLmN1cnJlbnRWYWx1ZSxcbiAgICAgIHVybDogbWVzc2FnZS51cmwsXG4gICAgICBwYWdlVGl0bGU6IG1lc3NhZ2UucGFnZVRpdGxlLFxuICAgIH07XG4gICAgc3RhdGUgPSBcImNvbmZpcm1cIjtcbiAgICByZW5kZXIoKTtcbiAgfVxuXG4gIGlmIChtZXNzYWdlLnR5cGUgPT09IE1TRy5DQU5ESURBVEVTX1JFU1VMVCkge1xuICAgIGNhbmRpZGF0ZXMgPSBtZXNzYWdlLmNhbmRpZGF0ZXMgfHwgW107XG4gICAgaWYgKHN0YXRlID09PSBcImF1dGhlbnRpY2F0ZWRcIiB8fCBzdGF0ZSA9PT0gXCJwaWNraW5nXCIpIHtcbiAgICAgIHJlbmRlcigpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChtZXNzYWdlLnR5cGUgPT09IE1TRy5DQU5DRUxfUElDS0VSKSB7XG4gICAgaWYgKHN0YXRlID09PSBcInBpY2tpbmdcIikge1xuICAgICAgc3RhdGUgPSBcImF1dGhlbnRpY2F0ZWRcIjtcbiAgICAgIHJlbmRlcigpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChtZXNzYWdlLnR5cGUgPT09IFwiRlRDX0FVVEhfQ09NUExFVEVcIikge1xuICAgIC8vIFJlLWluaXRpYWxpc2UgYWZ0ZXIgYXV0aFxuICAgIGluaXQoKTtcbiAgfVxufSk7XG5cbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuLy8gUmVuZGVyXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZnVuY3Rpb24gcmVuZGVyKCk6IHZvaWQge1xuICByZW5kZXJBY2NvdW50KCk7XG5cbiAgc3dpdGNoIChzdGF0ZSkge1xuICAgIGNhc2UgXCJ1bmF1dGhlbnRpY2F0ZWRcIjpcbiAgICAgIHJlbmRlclVuYXV0aCgpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImNvbm5lY3RpbmdcIjpcbiAgICAgIHJlbmRlckNvbm5lY3RpbmcoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJhdXRoZW50aWNhdGVkXCI6XG4gICAgICByZW5kZXJBdXRoZW50aWNhdGVkKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwicGlja2luZ1wiOlxuICAgICAgcmVuZGVyUGlja2luZygpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBcImNvbmZpcm1cIjpcbiAgICAgIHJlbmRlckNvbmZpcm0oKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJjcmVhdGluZ1wiOlxuICAgICAgcmVuZGVyQ3JlYXRpbmcoKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgXCJzdWNjZXNzXCI6XG4gICAgICByZW5kZXJTdWNjZXNzKCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIFwiZXJyb3JcIjpcbiAgICAgIHJlbmRlckVycm9yKCk7XG4gICAgICBicmVhaztcbiAgfVxufVxuXG5mdW5jdGlvbiByZW5kZXJBY2NvdW50KCk6IHZvaWQge1xuICBpZiAoIXVzZXJJbmZvKSB7XG4gICAgYWNjb3VudEFyZWEuaW5uZXJIVE1MID0gXCJcIjtcbiAgICByZXR1cm47XG4gIH1cblxuICBhY2NvdW50QXJlYS5pbm5lckhUTUwgPSBgXG4gICAgPGJ1dHRvbiBjbGFzcz1cImFjY291bnQtYnRuXCIgaWQ9XCJhY2NvdW50LXRvZ2dsZVwiPlxuICAgICAgJHtlc2NhcGVIdG1sKHVzZXJJbmZvLmVtYWlsIHx8IFwiQ29ubmVjdGVkXCIpfSAmIzk2NjI7XG4gICAgPC9idXR0b24+XG4gICAgPGRpdiBjbGFzcz1cImFjY291bnQtZHJvcGRvd24gJHtkcm9wZG93bk9wZW4gPyBcIlwiIDogXCJoaWRkZW5cIn1cIiBpZD1cImFjY291bnQtZHJvcGRvd25cIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJkcm9wZG93bi1lbWFpbFwiPlxuICAgICAgICAke2VzY2FwZUh0bWwodXNlckluZm8uZW1haWwgfHwgdXNlckluZm8udXNlcklkKX1cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ0aWVyLWJhZGdlIHRpZXItJHtzYW5pdGl6ZVRpZXIodXNlckluZm8udGllcil9XCI+JHtlc2NhcGVIdG1sKHVzZXJJbmZvLnRpZXIpfTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGEgY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgaHJlZj1cIiR7QkFTRV9VUkx9L2Rhc2hib2FyZFwiIHRhcmdldD1cIl9ibGFua1wiPk9wZW4gZGFzaGJvYXJkPC9hPlxuICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLWRpdmlkZXJcIj48L2Rpdj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJkcm9wZG93bi1pdGVtXCIgaWQ9XCJkaXNjb25uZWN0LWJ0blwiPkRpc2Nvbm5lY3Q8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImFjY291bnQtdG9nZ2xlXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIGRyb3Bkb3duT3BlbiA9ICFkcm9wZG93bk9wZW47XG4gICAgcmVuZGVyQWNjb3VudCgpO1xuICB9KTtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImRpc2Nvbm5lY3QtYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IGNsZWFyVG9rZW4oKTtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoXCJjYWNoZWRVc2VySW5mb1wiKTtcbiAgICB1c2VySW5mbyA9IG51bGw7XG4gICAgZHJvcGRvd25PcGVuID0gZmFsc2U7XG4gICAgc3RhdGUgPSBcInVuYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcblxuICAvLyBDbG9zZSBkcm9wZG93biBvbiBjbGljayBvdXRzaWRlXG4gIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgaWYgKGRyb3Bkb3duT3Blbikge1xuICAgICAgZHJvcGRvd25PcGVuID0gZmFsc2U7XG4gICAgICByZW5kZXJBY2NvdW50KCk7XG4gICAgfVxuICB9LCB7IG9uY2U6IHRydWUgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclVuYXV0aCgpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInVuYXV0aFwiPlxuICAgICAgPGgyPlRyYWNrIHdoYXQgbWF0dGVycyBvbiBhbnkgd2VicGFnZS48L2gyPlxuICAgICAgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tZnVsbFwiIGlkPVwiY29ubmVjdC1idG5cIj5Db25uZWN0IHlvdXIgYWNjb3VudDwvYnV0dG9uPlxuICAgICAgPHA+QWxyZWFkeSBoYXZlIGFuIGFjY291bnQ/IFNpZ24gaW4gYWJvdmUuPC9wPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29ubmVjdC1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgY2hyb21lLnRhYnMuY3JlYXRlKHsgdXJsOiBgJHtCQVNFX1VSTH0vZXh0ZW5zaW9uLWF1dGhgIH0pO1xuICAgIHN0YXRlID0gXCJjb25uZWN0aW5nXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJDb25uZWN0aW5nKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY29ubmVjdGluZ1wiPlxuICAgICAgPGRpdiBjbGFzcz1cInNwaW5uZXJcIj48L2Rpdj5cbiAgICAgIDxwPkNvbm5lY3RpbmcuLi48L3A+XG4gICAgICA8cD5XYWl0aW5nIGZvciB5b3UgdG8gc2lnbiBpbiBhdCBGZXRjaFRoZUNoYW5nZS48L3A+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnkgYnRuLXNtXCIgaWQ9XCJjYW5jZWwtY29ubmVjdFwiIHN0eWxlPVwibWFyZ2luLXRvcDogMTZweDtcIj5DYW5jZWw8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImNhbmNlbC1jb25uZWN0XCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHN0YXRlID0gXCJ1bmF1dGhlbnRpY2F0ZWRcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlckF1dGhlbnRpY2F0ZWQoKTogdm9pZCB7XG4gIGNvbnN0IHRydW5jYXRlZFVybCA9IGN1cnJlbnRUYWJVcmwubGVuZ3RoID4gNDVcbiAgICA/IGN1cnJlbnRUYWJVcmwuc2xpY2UoMCwgNDUpICsgXCIuLi5cIlxuICAgIDogY3VycmVudFRhYlVybDtcblxuICBsZXQgY2FuZGlkYXRlc0h0bWwgPSBcIlwiO1xuICBpZiAoY2FuZGlkYXRlcy5sZW5ndGggPiAwKSB7XG4gICAgY2FuZGlkYXRlc0h0bWwgPSBgXG4gICAgICA8ZGl2IGNsYXNzPVwic2VjdGlvbi1oZWFkZXJcIj5TdWdnZXN0ZWQgZWxlbWVudHM8L2Rpdj5cbiAgICAgICR7Y2FuZGlkYXRlc1xuICAgICAgICAubWFwKFxuICAgICAgICAgIChjLCBpKSA9PiBgXG4gICAgICAgIDxkaXYgY2xhc3M9XCJjYW5kaWRhdGVcIiBkYXRhLWlkeD1cIiR7aX1cIj5cbiAgICAgICAgICA8c3BhbiBjbGFzcz1cImNhbmRpZGF0ZS10ZXh0XCI+JHtlc2NhcGVIdG1sKGMudGV4dCl9PC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzPVwiY2FuZGlkYXRlLXNlbGVjdG9yXCI+JHtlc2NhcGVIdG1sKGMuc2VsZWN0b3IpfTwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1zbSBjYW5kaWRhdGUtdHJhY2tcIiBkYXRhLWlkeD1cIiR7aX1cIj5UcmFjayB0aGlzPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgYFxuICAgICAgICApXG4gICAgICAgIC5qb2luKFwiXCIpfVxuICAgIGA7XG4gIH1cblxuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY3VycmVudC11cmxcIj48c3Ryb25nPlRyYWNraW5nOjwvc3Ryb25nPiAke2VzY2FwZUh0bWwodHJ1bmNhdGVkVXJsKX08L2Rpdj5cbiAgICAke2NhbmRpZGF0ZXNIdG1sfVxuICAgIDxkaXYgY2xhc3M9XCJzZWN0aW9uLWhlYWRlclwiPk9yIHBpY2sgbWFudWFsbHk8L2Rpdj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5IGJ0bi1mdWxsXCIgaWQ9XCJwaWNrLWJ0blwiPlBpY2sgYW4gZWxlbWVudCBvbiB0aGlzIHBhZ2U8L2J1dHRvbj5cbiAgICA8YnV0dG9uIGNsYXNzPVwiYWR2YW5jZWQtdG9nZ2xlXCIgaWQ9XCJhZHZhbmNlZC10b2dnbGVcIj4mIzk2NjI7IEFkdmFuY2VkIChDU1Mgc2VsZWN0b3IpPC9idXR0b24+XG4gICAgPGRpdiBjbGFzcz1cImFkdmFuY2VkLWNvbnRlbnRcIiBpZD1cImFkdmFuY2VkLWNvbnRlbnRcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmb3JtLWdyb3VwXCI+XG4gICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGNsYXNzPVwiZm9ybS1pbnB1dFwiIGlkPVwibWFudWFsLXNlbGVjdG9yXCIgcGxhY2Vob2xkZXI9XCJlLmcuIC5wcm9kdWN0LXByaWNlXCI+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cIm1hbnVhbC10cmFjay1idG5cIj5Vc2UgdGhpcyBzZWxlY3RvcjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIC8vIFBpY2sgZWxlbWVudCBidXR0b25cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJwaWNrLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6IE1TRy5TVEFSVF9QSUNLRVIsIHRhYklkOiBjdXJyZW50VGFiSWQgfSk7XG4gICAgc3RhdGUgPSBcInBpY2tpbmdcIjtcbiAgICByZW5kZXIoKTtcbiAgfSk7XG5cbiAgLy8gQ2FuZGlkYXRlIHRyYWNrIGJ1dHRvbnNcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIi5jYW5kaWRhdGUtdHJhY2tcIikuZm9yRWFjaCgoYnRuKSA9PiB7XG4gICAgYnRuLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZSkgPT4ge1xuICAgICAgY29uc3QgaWR4ID0gcGFyc2VJbnQoKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS5kYXRhc2V0LmlkeCB8fCBcIjBcIik7XG4gICAgICBjb25zdCBjID0gY2FuZGlkYXRlc1tpZHhdO1xuICAgICAgaWYgKGMpIHtcbiAgICAgICAgc2VsZWN0aW9uID0ge1xuICAgICAgICAgIHNlbGVjdG9yOiBjLnNlbGVjdG9yLFxuICAgICAgICAgIGN1cnJlbnRWYWx1ZTogYy50ZXh0LFxuICAgICAgICAgIHVybDogY3VycmVudFRhYlVybCxcbiAgICAgICAgICBwYWdlVGl0bGU6IGN1cnJlbnRUYWJUaXRsZSxcbiAgICAgICAgfTtcbiAgICAgICAgc3RhdGUgPSBcImNvbmZpcm1cIjtcbiAgICAgICAgcmVuZGVyKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH0pO1xuXG4gIC8vIEFkdmFuY2VkIHRvZ2dsZVxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcImFkdmFuY2VkLXRvZ2dsZVwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYWR2YW5jZWQtY29udGVudFwiKTtcbiAgICBlbD8uY2xhc3NMaXN0LnRvZ2dsZShcIm9wZW5cIik7XG4gIH0pO1xuXG4gIC8vIE1hbnVhbCBzZWxlY3RvclxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1hbnVhbC10cmFjay1idG5cIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgY29uc3QgaW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcIm1hbnVhbC1zZWxlY3RvclwiKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgIGNvbnN0IHNlbGVjdG9yID0gaW5wdXQ/LnZhbHVlLnRyaW0oKTtcbiAgICBpZiAoc2VsZWN0b3IpIHtcbiAgICAgIHNlbGVjdGlvbiA9IHtcbiAgICAgICAgc2VsZWN0b3IsXG4gICAgICAgIGN1cnJlbnRWYWx1ZTogXCJcIixcbiAgICAgICAgdXJsOiBjdXJyZW50VGFiVXJsLFxuICAgICAgICBwYWdlVGl0bGU6IFwiXCIsXG4gICAgICB9O1xuICAgICAgc3RhdGUgPSBcImNvbmZpcm1cIjtcbiAgICAgIHJlbmRlcigpO1xuICAgIH1cbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHJlbmRlclBpY2tpbmcoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJwaWNrZXItaW5mb1wiPlxuICAgICAgPGRpdiBjbGFzcz1cImljb25cIj4mIzEyNzkxOTs8L2Rpdj5cbiAgICAgIDxwPjxzdHJvbmc+Q2xpY2sgYW55IGVsZW1lbnQgb24gdGhlIHBhZ2UgdG8gdHJhY2sgaXQuPC9zdHJvbmc+PC9wPlxuICAgICAgPHA+UHJlc3MgRXNjIHRvIGNhbmNlbC48L3A+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zZWNvbmRhcnkgYnRuLXNtXCIgaWQ9XCJjYW5jZWwtcGlja1wiIHN0eWxlPVwibWFyZ2luLXRvcDogMTZweDtcIj5DYW5jZWwgcGlja2luZzwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY2FuY2VsLXBpY2tcIik/LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoKSA9PiB7XG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiBNU0cuQ0FOQ0VMX1BJQ0tFUiwgdGFiSWQ6IGN1cnJlbnRUYWJJZCB9KTtcbiAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyQ29uZmlybSgpOiB2b2lkIHtcbiAgaWYgKCFzZWxlY3Rpb24pIHJldHVybjtcblxuICBjb25zdCB0aWVyID0gdXNlckluZm8/LnRpZXIgfHwgXCJmcmVlXCI7XG4gIGNvbnN0IGhvdXJseURpc2FibGVkID0gdGllciA9PT0gXCJmcmVlXCI7XG4gIGNvbnN0IGRlZmF1bHROYW1lID0gKHNlbGVjdGlvbi5wYWdlVGl0bGUgfHwgXCJcIikuc2xpY2UoMCwgMTAwKTtcblxuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY3VycmVudC11cmxcIj48c3Ryb25nPlRyYWNraW5nOjwvc3Ryb25nPiAke2VzY2FwZUh0bWwoXG4gICAgICBzZWxlY3Rpb24udXJsLmxlbmd0aCA+IDQ1ID8gc2VsZWN0aW9uLnVybC5zbGljZSgwLCA0NSkgKyBcIi4uLlwiIDogc2VsZWN0aW9uLnVybFxuICAgICl9PC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImNvbmZpcm0tY2FyZFwiPlxuICAgICAgPGRpdiBjbGFzcz1cImxhYmVsXCI+RWxlbWVudCBzZWxlY3RlZDwvZGl2PlxuICAgICAgJHtcbiAgICAgICAgc2VsZWN0aW9uLmN1cnJlbnRWYWx1ZVxuICAgICAgICAgID8gYDxkaXYgY2xhc3M9XCJ2YWx1ZVwiPkN1cnJlbnRseTogJHtlc2NhcGVIdG1sKHNlbGVjdGlvbi5jdXJyZW50VmFsdWUuc2xpY2UoMCwgMTAwKSl9PC9kaXY+YFxuICAgICAgICAgIDogXCJcIlxuICAgICAgfVxuICAgICAgPGRpdiBjbGFzcz1cInNlbGVjdG9yXCI+JHtlc2NhcGVIdG1sKHNlbGVjdGlvbi5zZWxlY3Rvcil9PC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tbGFiZWxcIj5Nb25pdG9yIG5hbWU8L2xhYmVsPlxuICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgY2xhc3M9XCJmb3JtLWlucHV0XCIgaWQ9XCJtb25pdG9yLW5hbWVcIiB2YWx1ZT1cIiR7ZXNjYXBlQXR0cihkZWZhdWx0TmFtZSl9XCIgbWF4bGVuZ3RoPVwiMTAwXCI+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImZvcm0tZ3JvdXBcIj5cbiAgICAgIDxsYWJlbCBjbGFzcz1cImZvcm0tbGFiZWxcIj5DaGVjayBmcmVxdWVuY3k8L2xhYmVsPlxuICAgICAgPGRpdiBjbGFzcz1cInJhZGlvLWdyb3VwXCI+XG4gICAgICAgIDxsYWJlbCBjbGFzcz1cInJhZGlvLWxhYmVsXCI+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJyYWRpb1wiIG5hbWU9XCJmcmVxdWVuY3lcIiB2YWx1ZT1cImRhaWx5XCIgY2hlY2tlZD4gRGFpbHlcbiAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPGxhYmVsIGNsYXNzPVwicmFkaW8tbGFiZWwgJHtob3VybHlEaXNhYmxlZCA/IFwiZGlzYWJsZWRcIiA6IFwiXCJ9XCI+XG4gICAgICAgICAgPGlucHV0IHR5cGU9XCJyYWRpb1wiIG5hbWU9XCJmcmVxdWVuY3lcIiB2YWx1ZT1cImhvdXJseVwiICR7aG91cmx5RGlzYWJsZWQgPyBcImRpc2FibGVkXCIgOiBcIlwifT5cbiAgICAgICAgICBIb3VybHlcbiAgICAgICAgICAke2hvdXJseURpc2FibGVkID8gJzxzcGFuIGNsYXNzPVwidG9vbHRpcC10ZXh0XCI+KFBybyspPC9zcGFuPicgOiBcIlwifVxuICAgICAgICA8L2xhYmVsPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImJ0bi1yb3dcIj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeVwiIGlkPVwicGljay1hZ2Fpbi1idG5cIj5QaWNrIGFnYWluPC9idXR0b24+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1wcmltYXJ5XCIgaWQ9XCJjcmVhdGUtYnRuXCI+Q3JlYXRlIG1vbml0b3I8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInBpY2stYWdhaW4tYnRuXCIpPy5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKCkgPT4ge1xuICAgIHNlbGVjdGlvbiA9IG51bGw7XG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiBNU0cuU1RBUlRfUElDS0VSLCB0YWJJZDogY3VycmVudFRhYklkIH0pO1xuICAgIHN0YXRlID0gXCJwaWNraW5nXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY3JlYXRlLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGNyZWF0ZU1vbml0b3IpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBjcmVhdGVNb25pdG9yKCk6IFByb21pc2U8dm9pZD4ge1xuICBpZiAoIXNlbGVjdGlvbiB8fCBzdGF0ZSA9PT0gXCJjcmVhdGluZ1wiKSByZXR1cm47XG5cbiAgY29uc3QgbmFtZUlucHV0ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJtb25pdG9yLW5hbWVcIikgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgY29uc3QgbmFtZSA9IG5hbWVJbnB1dD8udmFsdWUudHJpbSgpIHx8IFwiVW50aXRsZWQgbW9uaXRvclwiO1xuICBjb25zdCBmcmVxdWVuY3kgPVxuICAgIChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdpbnB1dFtuYW1lPVwiZnJlcXVlbmN5XCJdOmNoZWNrZWQnKSBhcyBIVE1MSW5wdXRFbGVtZW50KT8udmFsdWUgfHwgXCJkYWlseVwiO1xuXG4gIHN0YXRlID0gXCJjcmVhdGluZ1wiO1xuICBjcmVhdGVkTW9uaXRvck5hbWUgPSBuYW1lO1xuICBjcmVhdGVkTW9uaXRvclZhbHVlID0gc2VsZWN0aW9uLmN1cnJlbnRWYWx1ZTtcbiAgcmVuZGVyKCk7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCB0b2tlbiA9IGF3YWl0IGdldFRva2VuKCk7XG4gICAgaWYgKCF0b2tlbikge1xuICAgICAgZXJyb3JNZXNzYWdlID0gXCJOb3QgYXV0aGVudGljYXRlZC4gUGxlYXNlIHJlY29ubmVjdC5cIjtcbiAgICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7QkFTRV9VUkx9L2FwaS9leHRlbnNpb24vbW9uaXRvcnNgLCB7XG4gICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXG4gICAgICB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBuYW1lLFxuICAgICAgICB1cmw6IHNlbGVjdGlvbi51cmwsXG4gICAgICAgIHNlbGVjdG9yOiBzZWxlY3Rpb24uc2VsZWN0b3IsXG4gICAgICAgIGZyZXF1ZW5jeSxcbiAgICAgIH0pLFxuICAgIH0pO1xuXG4gICAgaWYgKHJlcy5vaykge1xuICAgICAgc3RhdGUgPSBcInN1Y2Nlc3NcIjtcbiAgICAgIHJlbmRlcigpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpLmNhdGNoKCgpID0+IG51bGwpO1xuXG4gICAgaWYgKGRhdGE/LmNvZGUgPT09IFwiVElFUl9MSU1JVF9SRUFDSEVEXCIpIHtcbiAgICAgIGVycm9yTWVzc2FnZSA9IGAke2RhdGEubWVzc2FnZSB8fCBkYXRhLmVycm9yIHx8IFwiTW9uaXRvciBsaW1pdCByZWFjaGVkLlwifWA7XG4gICAgICBzdGF0ZSA9IFwiZXJyb3JcIjtcbiAgICAgIHJlbmRlcigpO1xuICAgICAgLy8gQWRkIHVwZ3JhZGUgbGluayBhZnRlciByZW5kZXIgdXNpbmcgRE9NIEFQSVxuICAgICAgY29uc3QgZXJyQ29udGFpbmVyID0gY29udGVudC5xdWVyeVNlbGVjdG9yKFwiLmVycm9yIHBcIik7XG4gICAgICBpZiAoZXJyQ29udGFpbmVyKSB7XG4gICAgICAgIGVyckNvbnRhaW5lci5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnJcIikpO1xuICAgICAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImFcIik7XG4gICAgICAgIGxpbmsuaHJlZiA9IGAke0JBU0VfVVJMfS9wcmljaW5nYDtcbiAgICAgICAgbGluay50YXJnZXQgPSBcIl9ibGFua1wiO1xuICAgICAgICBsaW5rLnN0eWxlLmNvbG9yID0gXCIjNjM2NmYxXCI7XG4gICAgICAgIGxpbmsudGV4dENvbnRlbnQgPSBcIlVwZ3JhZGUgeW91ciBwbGFuXCI7XG4gICAgICAgIGVyckNvbnRhaW5lci5hcHBlbmRDaGlsZChsaW5rKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBlcnJvck1lc3NhZ2UgPSBkYXRhPy5tZXNzYWdlIHx8IGRhdGE/LmVycm9yIHx8IGBGYWlsZWQgKCR7cmVzLnN0YXR1c30pYDtcbiAgICBzdGF0ZSA9IFwiZXJyb3JcIjtcbiAgICByZW5kZXIoKTtcbiAgfSBjYXRjaCB7XG4gICAgZXJyb3JNZXNzYWdlID0gXCJOZXR3b3JrIGVycm9yLiBQbGVhc2UgdHJ5IGFnYWluLlwiO1xuICAgIHN0YXRlID0gXCJlcnJvclwiO1xuICAgIHJlbmRlcigpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHJlbmRlckNyZWF0aW5nKCk6IHZvaWQge1xuICBjb250ZW50LmlubmVySFRNTCA9IGBcbiAgICA8ZGl2IGNsYXNzPVwiY29ubmVjdGluZ1wiIHN0eWxlPVwicGFkZGluZy10b3A6IDY0cHg7XCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic3Bpbm5lclwiPjwvZGl2PlxuICAgICAgPHA+Q3JlYXRpbmcgbW9uaXRvci4uLjwvcD5cbiAgICA8L2Rpdj5cbiAgYDtcbn1cblxuZnVuY3Rpb24gcmVuZGVyU3VjY2VzcygpOiB2b2lkIHtcbiAgY29udGVudC5pbm5lckhUTUwgPSBgXG4gICAgPGRpdiBjbGFzcz1cInN1Y2Nlc3NcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJpY29uXCI+JiMxMDAwMzs8L2Rpdj5cbiAgICAgIDxoMz5Nb25pdG9yIGNyZWF0ZWQhPC9oMz5cbiAgICAgIDxwPjxzdHJvbmc+JHtlc2NhcGVIdG1sKGNyZWF0ZWRNb25pdG9yTmFtZSl9PC9zdHJvbmc+IGlzIG5vdyBiZWluZyB3YXRjaGVkLjwvcD5cbiAgICAgICR7Y3JlYXRlZE1vbml0b3JWYWx1ZSA/IGA8cD5Zb3UnbGwgYmUgbm90aWZpZWQgd2hlbiA8c3Ryb25nPiR7ZXNjYXBlSHRtbChjcmVhdGVkTW9uaXRvclZhbHVlLnNsaWNlKDAsIDYwKSl9PC9zdHJvbmc+IGNoYW5nZXMuPC9wPmAgOiBcIlwifVxuICAgICAgPGRpdiBjbGFzcz1cImJ0bi1yb3dcIiBzdHlsZT1cIm1hcmdpbi10b3A6IDI0cHg7IGp1c3RpZnktY29udGVudDogY2VudGVyO1wiPlxuICAgICAgICA8YSBjbGFzcz1cImJ0biBidG4tcHJpbWFyeSBidG4tc21cIiBocmVmPVwiJHtCQVNFX1VSTH0vZGFzaGJvYXJkXCIgdGFyZ2V0PVwiX2JsYW5rXCI+VmlldyBpbiBkYXNoYm9hcmQ8L2E+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeSBidG4tc21cIiBpZD1cInRyYWNrLWFub3RoZXItYnRuXCI+VHJhY2sgYW5vdGhlcjwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0cmFjay1hbm90aGVyLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBzZWxlY3Rpb24gPSBudWxsO1xuICAgIGNhbmRpZGF0ZXMgPSBbXTtcbiAgICBzdGF0ZSA9IFwiYXV0aGVudGljYXRlZFwiO1xuICAgIHJlbmRlcigpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyRXJyb3IoKTogdm9pZCB7XG4gIGNvbnRlbnQuaW5uZXJIVE1MID0gYFxuICAgIDxkaXYgY2xhc3M9XCJlcnJvclwiPlxuICAgICAgPGRpdiBjbGFzcz1cImljb25cIj4mIzEwMDA3OzwvZGl2PlxuICAgICAgPGgzPkNvdWxkbid0IGNyZWF0ZSBtb25pdG9yPC9oMz5cbiAgICAgIDxwPiR7ZXNjYXBlSHRtbChlcnJvck1lc3NhZ2UpfTwvcD5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXNlY29uZGFyeVwiIGlkPVwidHJ5LWFnYWluLWJ0blwiPlRyeSBhZ2FpbjwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidHJ5LWFnYWluLWJ0blwiKT8uYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsICgpID0+IHtcbiAgICBzdGF0ZSA9IHNlbGVjdGlvbiA/IFwiY29uZmlybVwiIDogXCJhdXRoZW50aWNhdGVkXCI7XG4gICAgcmVuZGVyKCk7XG4gIH0pO1xufVxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIEhlbHBlcnNcbi8vIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBlc2NhcGVIdG1sKHN0cjogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgZGl2LnRleHRDb250ZW50ID0gc3RyO1xuICByZXR1cm4gZGl2LmlubmVySFRNTDtcbn1cblxuXG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vIFN0YXJ0XG4vLyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuaW5pdCgpO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBR08sTUFBTSxXQUFXO0FBQ2pCLE1BQU0sb0JBQW9CO0FBQzFCLE1BQU0sbUJBQW1CO0FBRXpCLE1BQU0sTUFBTTtBQUFBLElBQ2pCLGNBQWM7QUFBQSxJQUNkLGVBQWU7QUFBQSxJQUNmLGtCQUFrQjtBQUFBLElBQ2xCLGdCQUFnQjtBQUFBLElBQ2hCLG1CQUFtQjtBQUFBLElBQ25CLHFCQUFxQjtBQUFBLEVBQ3ZCOzs7QUNaQSxpQkFBc0IsV0FBbUM7QUFDdkQsVUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixnQkFBZ0IsQ0FBQztBQUNuRixVQUFNLFFBQVEsT0FBTyxpQkFBaUI7QUFDdEMsVUFBTSxTQUFTLE9BQU8sZ0JBQWdCO0FBRXRDLFFBQUksQ0FBQyxTQUFTLENBQUMsT0FBUSxRQUFPO0FBRTlCLFVBQU0sV0FBVyxJQUFJLEtBQUssTUFBTSxFQUFFLFFBQVE7QUFDMUMsUUFBSSxDQUFDLE9BQU8sU0FBUyxRQUFRLEtBQUssV0FBVyxLQUFLLElBQUksR0FBRztBQUN2RCxZQUFNLFdBQVc7QUFDakIsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQVNBLGlCQUFzQixhQUE0QjtBQUNoRCxVQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8sQ0FBQyxtQkFBbUIsZ0JBQWdCLENBQUM7QUFBQSxFQUN6RTtBQUVBLGlCQUFzQixlQUFpQztBQUNyRCxVQUFNLFFBQVEsTUFBTSxTQUFTO0FBQzdCLFdBQU8sVUFBVTtBQUFBLEVBQ25COzs7QUNoQ08sV0FBUyxXQUFXLEtBQXFCO0FBQzlDLFdBQU8sSUFBSSxRQUFRLE1BQU0sT0FBTyxFQUFFLFFBQVEsTUFBTSxRQUFRLEVBQUUsUUFBUSxNQUFNLE9BQU8sRUFBRSxRQUFRLE1BQU0sTUFBTSxFQUFFLFFBQVEsTUFBTSxNQUFNO0FBQUEsRUFDN0g7QUFHQSxNQUFNLGNBQWMsQ0FBQyxRQUFRLE9BQU8sT0FBTztBQUNwQyxXQUFTLGFBQWEsTUFBc0I7QUFDakQsV0FBTyxZQUFZLFNBQVMsSUFBSSxJQUFJLE9BQU87QUFBQSxFQUM3Qzs7O0FDNkJBLE1BQUksUUFBb0I7QUFDeEIsTUFBSSxXQUE0QjtBQUNoQyxNQUFJLFlBQThCO0FBQ2xDLE1BQUksYUFBMEIsQ0FBQztBQUMvQixNQUFJLGdCQUFnQjtBQUNwQixNQUFJLGtCQUFrQjtBQUN0QixNQUFJLGVBQWU7QUFDbkIsTUFBSSxlQUFlO0FBQ25CLE1BQUkscUJBQXFCO0FBQ3pCLE1BQUksc0JBQXNCO0FBQzFCLE1BQUksZUFBZTtBQUVuQixNQUFNLFVBQVUsU0FBUyxlQUFlLFNBQVM7QUFDakQsTUFBTSxjQUFjLFNBQVMsZUFBZSxjQUFjO0FBTTFELGlCQUFlLE9BQXNCO0FBRW5DLFVBQU0sQ0FBQyxHQUFHLElBQUksTUFBTSxPQUFPLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUMzRSxRQUFJLEtBQUs7QUFDUCxzQkFBZ0IsSUFBSSxPQUFPO0FBQzNCLHdCQUFrQixJQUFJLFNBQVM7QUFDL0IscUJBQWUsSUFBSSxNQUFNO0FBQUEsSUFDM0I7QUFFQSxVQUFNLFFBQVEsTUFBTSxhQUFhO0FBQ2pDLFFBQUksQ0FBQyxPQUFPO0FBQ1YsY0FBUTtBQUNSLGFBQU87QUFDUDtBQUFBLElBQ0Y7QUFHQSxVQUFNLFFBQVEsTUFBTSxTQUFTO0FBQzdCLFFBQUksQ0FBQyxPQUFPO0FBQ1YsY0FBUTtBQUNSLGFBQU87QUFDUDtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sTUFBTSxHQUFHLFFBQVEseUJBQXlCO0FBQUEsUUFDMUQsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLEdBQUc7QUFBQSxNQUM5QyxDQUFDO0FBRUQsVUFBSSxDQUFDLElBQUksSUFBSTtBQUNYLGNBQU0sV0FBVztBQUNqQixnQkFBUTtBQUNSLGVBQU87QUFDUDtBQUFBLE1BQ0Y7QUFFQSxpQkFBVyxNQUFNLElBQUksS0FBSyxFQUFFLE1BQU0sTUFBTSxJQUFJO0FBQzVDLFVBQUksQ0FBQyxZQUFZLE9BQU8sU0FBUyxXQUFXLFVBQVU7QUFDcEQsY0FBTSxXQUFXO0FBQ2pCLGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLFlBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLGdCQUFnQixTQUFTLENBQUM7QUFDM0QsY0FBUTtBQUFBLElBQ1YsUUFBUTtBQUVOLFlBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksZ0JBQWdCO0FBQzlELFlBQU0sSUFBSSxPQUFPO0FBQ2pCLFVBQUksS0FBSyxPQUFPLEVBQUUsV0FBVyxZQUFZLE9BQU8sRUFBRSxTQUFTLFlBQVksT0FBTyxFQUFFLFVBQVUsVUFBVTtBQUNsRyxtQkFBVztBQUNYLGdCQUFRO0FBQUEsTUFDVixPQUFPO0FBQ0wsZ0JBQVE7QUFBQSxNQUNWO0FBQUEsSUFDRjtBQUVBLFdBQU87QUFBQSxFQUNUO0FBTUEsU0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLFlBQVk7QUFDaEQsUUFBSSxRQUFRLFNBQVMsSUFBSSxrQkFBa0I7QUFDekMsa0JBQVk7QUFBQSxRQUNWLFVBQVUsUUFBUTtBQUFBLFFBQ2xCLGNBQWMsUUFBUTtBQUFBLFFBQ3RCLEtBQUssUUFBUTtBQUFBLFFBQ2IsV0FBVyxRQUFRO0FBQUEsTUFDckI7QUFDQSxjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJLFFBQVEsU0FBUyxJQUFJLG1CQUFtQjtBQUMxQyxtQkFBYSxRQUFRLGNBQWMsQ0FBQztBQUNwQyxVQUFJLFVBQVUsbUJBQW1CLFVBQVUsV0FBVztBQUNwRCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxRQUFJLFFBQVEsU0FBUyxJQUFJLGVBQWU7QUFDdEMsVUFBSSxVQUFVLFdBQVc7QUFDdkIsZ0JBQVE7QUFDUixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxRQUFJLFFBQVEsU0FBUyxxQkFBcUI7QUFFeEMsV0FBSztBQUFBLElBQ1A7QUFBQSxFQUNGLENBQUM7QUFNRCxXQUFTLFNBQWU7QUFDdEIsa0JBQWM7QUFFZCxZQUFRLE9BQU87QUFBQSxNQUNiLEtBQUs7QUFDSCxxQkFBYTtBQUNiO0FBQUEsTUFDRixLQUFLO0FBQ0gseUJBQWlCO0FBQ2pCO0FBQUEsTUFDRixLQUFLO0FBQ0gsNEJBQW9CO0FBQ3BCO0FBQUEsTUFDRixLQUFLO0FBQ0gsc0JBQWM7QUFDZDtBQUFBLE1BQ0YsS0FBSztBQUNILHNCQUFjO0FBQ2Q7QUFBQSxNQUNGLEtBQUs7QUFDSCx1QkFBZTtBQUNmO0FBQUEsTUFDRixLQUFLO0FBQ0gsc0JBQWM7QUFDZDtBQUFBLE1BQ0YsS0FBSztBQUNILG9CQUFZO0FBQ1o7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUVBLFdBQVMsZ0JBQXNCO0FBQzdCLFFBQUksQ0FBQyxVQUFVO0FBQ2Isa0JBQVksWUFBWTtBQUN4QjtBQUFBLElBQ0Y7QUFFQSxnQkFBWSxZQUFZO0FBQUE7QUFBQSxRQUVsQixXQUFXLFNBQVMsU0FBUyxXQUFXLENBQUM7QUFBQTtBQUFBLG1DQUVkLGVBQWUsS0FBSyxRQUFRO0FBQUE7QUFBQSxVQUVyRCxXQUFXLFNBQVMsU0FBUyxTQUFTLE1BQU0sQ0FBQztBQUFBLHVDQUNoQixhQUFhLFNBQVMsSUFBSSxDQUFDLEtBQUssV0FBVyxTQUFTLElBQUksQ0FBQztBQUFBO0FBQUEsdUNBRXpELFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU03QyxhQUFTLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLFNBQVMsQ0FBQyxNQUFNO0FBQzFFLFFBQUUsZ0JBQWdCO0FBQ2xCLHFCQUFlLENBQUM7QUFDaEIsb0JBQWM7QUFBQSxJQUNoQixDQUFDO0FBRUQsYUFBUyxlQUFlLGdCQUFnQixHQUFHLGlCQUFpQixTQUFTLFlBQVk7QUFDL0UsWUFBTSxXQUFXO0FBQ2pCLFlBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxnQkFBZ0I7QUFDbEQsaUJBQVc7QUFDWCxxQkFBZTtBQUNmLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBR0QsYUFBUyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3ZDLFVBQUksY0FBYztBQUNoQix1QkFBZTtBQUNmLHNCQUFjO0FBQUEsTUFDaEI7QUFBQSxJQUNGLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztBQUFBLEVBQ25CO0FBRUEsV0FBUyxlQUFxQjtBQUM1QixZQUFRLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFRcEIsYUFBUyxlQUFlLGFBQWEsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3RFLGFBQU8sS0FBSyxPQUFPLEVBQUUsS0FBSyxHQUFHLFFBQVEsa0JBQWtCLENBQUM7QUFDeEQsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBUyxtQkFBeUI7QUFDaEMsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFTcEIsYUFBUyxlQUFlLGdCQUFnQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDekUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFBQSxFQUNIO0FBRUEsV0FBUyxzQkFBNEI7QUFDbkMsVUFBTSxlQUFlLGNBQWMsU0FBUyxLQUN4QyxjQUFjLE1BQU0sR0FBRyxFQUFFLElBQUksUUFDN0I7QUFFSixRQUFJLGlCQUFpQjtBQUNyQixRQUFJLFdBQVcsU0FBUyxHQUFHO0FBQ3pCLHVCQUFpQjtBQUFBO0FBQUEsUUFFYixXQUNDO0FBQUEsUUFDQyxDQUFDLEdBQUcsTUFBTTtBQUFBLDJDQUN1QixDQUFDO0FBQUEseUNBQ0gsV0FBVyxFQUFFLElBQUksQ0FBQztBQUFBLDZDQUNkLFdBQVcsRUFBRSxRQUFRLENBQUM7QUFBQSw2RUFDVSxDQUFDO0FBQUE7QUFBQTtBQUFBLE1BR3RFLEVBQ0MsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBLElBRWY7QUFFQSxZQUFRLFlBQVk7QUFBQSwwREFDb0MsV0FBVyxZQUFZLENBQUM7QUFBQSxNQUM1RSxjQUFjO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFhbEIsYUFBUyxlQUFlLFVBQVUsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ25FLGFBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxJQUFJLGNBQWMsT0FBTyxhQUFhLENBQUM7QUFDMUUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFHRCxhQUFTLGlCQUFpQixrQkFBa0IsRUFBRSxRQUFRLENBQUMsUUFBUTtBQUM3RCxVQUFJLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUNuQyxjQUFNLE1BQU0sU0FBVSxFQUFFLE9BQXVCLFFBQVEsT0FBTyxHQUFHO0FBQ2pFLGNBQU0sSUFBSSxXQUFXLEdBQUc7QUFDeEIsWUFBSSxHQUFHO0FBQ0wsc0JBQVk7QUFBQSxZQUNWLFVBQVUsRUFBRTtBQUFBLFlBQ1osY0FBYyxFQUFFO0FBQUEsWUFDaEIsS0FBSztBQUFBLFlBQ0wsV0FBVztBQUFBLFVBQ2I7QUFDQSxrQkFBUTtBQUNSLGlCQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdELGFBQVMsZUFBZSxpQkFBaUIsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQzFFLFlBQU0sS0FBSyxTQUFTLGVBQWUsa0JBQWtCO0FBQ3JELFVBQUksVUFBVSxPQUFPLE1BQU07QUFBQSxJQUM3QixDQUFDO0FBR0QsYUFBUyxlQUFlLGtCQUFrQixHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDM0UsWUFBTSxRQUFRLFNBQVMsZUFBZSxpQkFBaUI7QUFDdkQsWUFBTSxXQUFXLE9BQU8sTUFBTSxLQUFLO0FBQ25DLFVBQUksVUFBVTtBQUNaLG9CQUFZO0FBQUEsVUFDVjtBQUFBLFVBQ0EsY0FBYztBQUFBLFVBQ2QsS0FBSztBQUFBLFVBQ0wsV0FBVztBQUFBLFFBQ2I7QUFDQSxnQkFBUTtBQUNSLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsZ0JBQXNCO0FBQzdCLFlBQVEsWUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBU3BCLGFBQVMsZUFBZSxhQUFhLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN0RSxhQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sSUFBSSxlQUFlLE9BQU8sYUFBYSxDQUFDO0FBQzNFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsZ0JBQXNCO0FBQzdCLFFBQUksQ0FBQyxVQUFXO0FBRWhCLFVBQU0sT0FBTyxVQUFVLFFBQVE7QUFDL0IsVUFBTSxpQkFBaUIsU0FBUztBQUNoQyxVQUFNLGVBQWUsVUFBVSxhQUFhLElBQUksTUFBTSxHQUFHLEdBQUc7QUFFNUQsWUFBUSxZQUFZO0FBQUEsMERBQ29DO0FBQUEsTUFDcEQsVUFBVSxJQUFJLFNBQVMsS0FBSyxVQUFVLElBQUksTUFBTSxHQUFHLEVBQUUsSUFBSSxRQUFRLFVBQVU7QUFBQSxJQUM3RSxDQUFDO0FBQUE7QUFBQTtBQUFBLFFBSUcsVUFBVSxlQUNOLGlDQUFpQyxXQUFXLFVBQVUsYUFBYSxNQUFNLEdBQUcsR0FBRyxDQUFDLENBQUMsV0FDakYsRUFDTjtBQUFBLDhCQUN3QixXQUFXLFVBQVUsUUFBUSxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUVBSVcsV0FBVyxXQUFXLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9DQVExRCxpQkFBaUIsYUFBYSxFQUFFO0FBQUEsZ0VBQ0osaUJBQWlCLGFBQWEsRUFBRTtBQUFBO0FBQUEsWUFFcEYsaUJBQWlCLDZDQUE2QyxFQUFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVUxRSxhQUFTLGVBQWUsZ0JBQWdCLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUN6RSxrQkFBWTtBQUNaLGFBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxJQUFJLGNBQWMsT0FBTyxhQUFhLENBQUM7QUFDMUUsY0FBUTtBQUNSLGFBQU87QUFBQSxJQUNULENBQUM7QUFFRCxhQUFTLGVBQWUsWUFBWSxHQUFHLGlCQUFpQixTQUFTLGFBQWE7QUFBQSxFQUNoRjtBQUVBLGlCQUFlLGdCQUErQjtBQUM1QyxRQUFJLENBQUMsYUFBYSxVQUFVLFdBQVk7QUFFeEMsVUFBTSxZQUFZLFNBQVMsZUFBZSxjQUFjO0FBQ3hELFVBQU0sT0FBTyxXQUFXLE1BQU0sS0FBSyxLQUFLO0FBQ3hDLFVBQU0sWUFDSCxTQUFTLGNBQWMsaUNBQWlDLEdBQXdCLFNBQVM7QUFFNUYsWUFBUTtBQUNSLHlCQUFxQjtBQUNyQiwwQkFBc0IsVUFBVTtBQUNoQyxXQUFPO0FBRVAsUUFBSTtBQUNGLFlBQU0sUUFBUSxNQUFNLFNBQVM7QUFDN0IsVUFBSSxDQUFDLE9BQU87QUFDVix1QkFBZTtBQUNmLGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLFlBQU0sTUFBTSxNQUFNLE1BQU0sR0FBRyxRQUFRLDJCQUEyQjtBQUFBLFFBQzVELFFBQVE7QUFBQSxRQUNSLFNBQVM7QUFBQSxVQUNQLGdCQUFnQjtBQUFBLFVBQ2hCLGVBQWUsVUFBVSxLQUFLO0FBQUEsUUFDaEM7QUFBQSxRQUNBLE1BQU0sS0FBSyxVQUFVO0FBQUEsVUFDbkI7QUFBQSxVQUNBLEtBQUssVUFBVTtBQUFBLFVBQ2YsVUFBVSxVQUFVO0FBQUEsVUFDcEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILENBQUM7QUFFRCxVQUFJLElBQUksSUFBSTtBQUNWLGdCQUFRO0FBQ1IsZUFBTztBQUNQO0FBQUEsTUFDRjtBQUVBLFlBQU0sT0FBTyxNQUFNLElBQUksS0FBSyxFQUFFLE1BQU0sTUFBTSxJQUFJO0FBRTlDLFVBQUksTUFBTSxTQUFTLHNCQUFzQjtBQUN2Qyx1QkFBZSxHQUFHLEtBQUssV0FBVyxLQUFLLFNBQVMsd0JBQXdCO0FBQ3hFLGdCQUFRO0FBQ1IsZUFBTztBQUVQLGNBQU0sZUFBZSxRQUFRLGNBQWMsVUFBVTtBQUNyRCxZQUFJLGNBQWM7QUFDaEIsdUJBQWEsWUFBWSxTQUFTLGNBQWMsSUFBSSxDQUFDO0FBQ3JELGdCQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7QUFDdkMsZUFBSyxPQUFPLEdBQUcsUUFBUTtBQUN2QixlQUFLLFNBQVM7QUFDZCxlQUFLLE1BQU0sUUFBUTtBQUNuQixlQUFLLGNBQWM7QUFDbkIsdUJBQWEsWUFBWSxJQUFJO0FBQUEsUUFDL0I7QUFDQTtBQUFBLE1BQ0Y7QUFFQSxxQkFBZSxNQUFNLFdBQVcsTUFBTSxTQUFTLFdBQVcsSUFBSSxNQUFNO0FBQ3BFLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxRQUFRO0FBQ04scUJBQWU7QUFDZixjQUFRO0FBQ1IsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsV0FBUyxpQkFBdUI7QUFDOUIsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTXRCO0FBRUEsV0FBUyxnQkFBc0I7QUFDN0IsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUgsV0FBVyxrQkFBa0IsQ0FBQztBQUFBLFFBQ3pDLHNCQUFzQixzQ0FBc0MsV0FBVyxvQkFBb0IsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLDJCQUEyQixFQUFFO0FBQUE7QUFBQSxrREFFM0YsUUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTXhELGFBQVMsZUFBZSxtQkFBbUIsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQzVFLGtCQUFZO0FBQ1osbUJBQWEsQ0FBQztBQUNkLGNBQVE7QUFDUixhQUFPO0FBQUEsSUFDVCxDQUFDO0FBQUEsRUFDSDtBQUVBLFdBQVMsY0FBb0I7QUFDM0IsWUFBUSxZQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJWCxXQUFXLFlBQVksQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUtqQyxhQUFTLGVBQWUsZUFBZSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDeEUsY0FBUSxZQUFZLFlBQVk7QUFDaEMsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFNQSxXQUFTLFdBQVcsS0FBcUI7QUFDdkMsVUFBTSxNQUFNLFNBQVMsY0FBYyxLQUFLO0FBQ3hDLFFBQUksY0FBYztBQUNsQixXQUFPLElBQUk7QUFBQSxFQUNiO0FBT0EsT0FBSzsiLAogICJuYW1lcyI6IFtdCn0K
