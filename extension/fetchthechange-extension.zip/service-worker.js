// src/shared/constants.ts
var BASE_URL = "https://ftc.bd73.com";
var TOKEN_STORAGE_KEY = "ftc_extension_token";
var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
var MSG = {
  START_PICKER: "FTC_START_PICKER",
  CANCEL_PICKER: "FTC_CANCEL_PICKER",
  ELEMENT_SELECTED: "FTC_ELEMENT_SELECTED",
  GET_CANDIDATES: "FTC_GET_CANDIDATES",
  CANDIDATES_RESULT: "FTC_CANDIDATES_RESULT",
  FTC_EXTENSION_TOKEN: "FTC_EXTENSION_TOKEN"
};

// src/auth/token.ts
async function setToken(token, expiresAt) {
  await chrome.storage.local.set({
    [TOKEN_STORAGE_KEY]: token,
    [TOKEN_EXPIRY_KEY]: expiresAt
  });
}

// src/background/service-worker.ts
function isValidAuthSender(senderUrl, baseUrl) {
  try {
    const parsed = new URL(senderUrl);
    const expectedOrigin = new URL(baseUrl).origin;
    return parsed.origin === expectedOrigin && parsed.pathname === "/extension-auth";
  } catch {
    return false;
  }
}
var EXPECTED_AUTH_ORIGIN = new URL(BASE_URL).origin;
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!changeInfo.url) return;
  try {
    const fullUrl = tab.url || changeInfo.url;
    const url = new URL(fullUrl);
    if (url.origin !== EXPECTED_AUTH_ORIGIN) return;
    if (url.pathname !== "/extension-auth" || url.searchParams.get("done") !== "1") return;
    if (!url.hash || url.hash.length < 2) return;
    const hashParams = new URLSearchParams(url.hash.slice(1));
    const token = hashParams.get("token");
    const expiresAt = hashParams.get("expiresAt");
    if (!token || !expiresAt) return;
    handleTokenReceived(token, expiresAt, tabId).catch(console.error);
  } catch {
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === MSG.START_PICKER) {
    injectPicker(message.tabId);
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === MSG.CANCEL_PICKER) {
    removePicker(message.tabId);
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === MSG.FTC_EXTENSION_TOKEN) {
    const senderUrl = sender.tab?.url;
    if (!senderUrl) {
      sendResponse({ ok: false, error: "no sender tab" });
      return false;
    }
    if (!isValidAuthSender(senderUrl, BASE_URL)) {
      sendResponse({ ok: false, error: "unexpected origin" });
      return false;
    }
    handleTokenReceived(message.token, message.expiresAt, sender.tab?.id).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false, error: "storage failed" }));
    return true;
  }
  if (message.type === MSG.ELEMENT_SELECTED || message.type === MSG.CANDIDATES_RESULT) {
    chrome.runtime.sendMessage(message).catch(() => {
    });
    return false;
  }
  return false;
});
async function injectPicker(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url || !tab.url.startsWith("http://") && !tab.url.startsWith("https://")) {
      return;
    }
    await chrome.scripting.insertCSS({
      target: { tabId },
      files: ["picker.css"]
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["picker.js"]
    });
  } catch (err) {
    console.error("[FTC] Failed to inject picker:", err);
  }
}
async function removePicker(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const event = new CustomEvent("ftc-cancel-picker");
        document.dispatchEvent(event);
      }
    });
  } catch (err) {
    console.error("[FTC] Failed to remove picker:", err);
  }
}
async function handleTokenReceived(token, expiresAt, tabId) {
  await setToken(token, expiresAt);
  if (tabId) {
    try {
      await chrome.tabs.remove(tabId);
    } catch {
    }
  }
  chrome.runtime.sendMessage({ type: "FTC_AUTH_COMPLETE" }).catch(() => {
  });
}
export {
  isValidAuthSender
};
