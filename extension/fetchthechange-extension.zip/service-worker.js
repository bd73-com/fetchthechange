// src/shared/constants.ts
var BASE_URL = "https://ftc.bd73.com";
var TOKEN_STORAGE_KEY = "ftc_extension_token";
var TOKEN_EXPIRY_KEY = "ftc_extension_token_expiry";
var AUTH_STARTED_KEY = "ftc_auth_started_at";
var MSG = {
  START_PICKER: "FTC_START_PICKER",
  CANCEL_PICKER: "FTC_CANCEL_PICKER",
  ELEMENT_SELECTED: "FTC_ELEMENT_SELECTED",
  GET_CANDIDATES: "FTC_GET_CANDIDATES",
  CANDIDATES_RESULT: "FTC_CANDIDATES_RESULT",
  FTC_EXTENSION_TOKEN: "FTC_EXTENSION_TOKEN",
  AUTH_TAB_OPENED: "FTC_AUTH_TAB_OPENED"
};

// src/auth/token.ts
async function setToken(token, expiresAt) {
  await chrome.storage.local.set({
    [TOKEN_STORAGE_KEY]: token,
    [TOKEN_EXPIRY_KEY]: expiresAt
  });
}

// src/background/service-worker.ts
var TAG = "[FTC:SW]";
function isValidAuthSender(senderUrl, baseUrl) {
  try {
    const parsed = new URL(senderUrl);
    const expectedOrigin = new URL(baseUrl).origin;
    return parsed.origin === expectedOrigin && parsed.pathname === "/extension-auth";
  } catch {
    return false;
  }
}
function extractTokenFromUrl(url) {
  try {
    const parsed = new URL(url);
    if (parsed.origin !== EXPECTED_AUTH_ORIGIN) return null;
    if (parsed.pathname !== "/extension-auth") return null;
    if (parsed.searchParams.get("done") !== "1") return null;
    if (!parsed.hash || parsed.hash.length < 2) return null;
    const hashParams = new URLSearchParams(parsed.hash.slice(1));
    const token = hashParams.get("token");
    const expiresAt = hashParams.get("expiresAt");
    if (!token || !expiresAt) return null;
    return { token, expiresAt };
  } catch {
    return null;
  }
}
var EXPECTED_AUTH_ORIGIN = new URL(BASE_URL).origin;
var authTabs = /* @__PURE__ */ new Set();
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  const urlChanged = !!changeInfo.url;
  const pageComplete = changeInfo.status === "complete";
  if (!urlChanged && !pageComplete) return;
  if (!authTabs.has(tabId)) {
    const tabUrl = tab.url || changeInfo.url || "";
    if (!urlChanged && !tabUrl.includes("/extension-auth")) return;
    const stored = await chrome.storage.local.get(AUTH_STARTED_KEY);
    const startedAt = Number(stored[AUTH_STARTED_KEY]);
    if (!Number.isFinite(startedAt) || Date.now() - startedAt > 12e4) return;
    console.log(TAG, "onUpdated: tab not in authTabs (SW restarted?), but recent auth attempt found");
  }
  const fullUrl = tab.url || changeInfo.url || "";
  let result = extractTokenFromUrl(fullUrl);
  if (!result && fullUrl.includes("/extension-auth") && fullUrl.includes("done=1")) {
    try {
      const freshTab = await chrome.tabs.get(tabId);
      if (freshTab.url) {
        console.log(TAG, "onUpdated: re-read tab URL:", freshTab.url.split("#")[0]);
        result = extractTokenFromUrl(freshTab.url);
      }
    } catch {
    }
    if (!result) {
      try {
        const frames = await chrome.scripting.executeScript({
          target: { tabId },
          func: () => window.location.href
        });
        const pageUrl = frames?.[0]?.result;
        if (typeof pageUrl === "string") {
          console.log(TAG, "onUpdated: scripting fallback URL:", pageUrl.split("#")[0]);
          result = extractTokenFromUrl(pageUrl);
        }
      } catch {
      }
    }
  }
  if (!result) return;
  console.log(TAG, "onUpdated: token found in tab URL, storing...");
  authTabs.delete(tabId);
  handleTokenReceived(result.token, result.expiresAt, tabId).catch((err) => {
    console.error(TAG, "onUpdated: handleTokenReceived failed:", err);
    chrome.storage.local.remove(AUTH_STARTED_KEY).catch(() => {
    });
  });
});
var closedTabs = /* @__PURE__ */ new Set();
chrome.tabs.onRemoved.addListener((tabId) => {
  if (authTabs.has(tabId)) {
    console.log(TAG, `onRemoved: auth tab ${tabId} closed`);
    authTabs.delete(tabId);
    closedTabs.add(tabId);
    setTimeout(() => closedTabs.delete(tabId), 6e4);
  }
});
async function pollAuthTab(tabId) {
  console.log(TAG, `poll: starting for tab ${tabId}`);
  let consecutiveErrors = 0;
  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 2e3));
    if (!authTabs.has(tabId)) {
      console.log(TAG, `poll: tab ${tabId} already resolved, stopping`);
      return;
    }
    if (closedTabs.has(tabId)) {
      console.log(TAG, `poll: tab ${tabId} confirmed closed, stopping`);
      return;
    }
    try {
      const tab = await chrome.tabs.get(tabId);
      consecutiveErrors = 0;
      if (!tab.url) continue;
      const result = extractTokenFromUrl(tab.url);
      if (result) {
        console.log(TAG, `poll: token found in tab ${tabId} URL on attempt ${i + 1}`);
        authTabs.delete(tabId);
        await handleTokenReceived(result.token, result.expiresAt, tabId);
        return;
      }
    } catch (err) {
      consecutiveErrors++;
      const msg = err instanceof Error ? err.message : String(err);
      console.warn(TAG, `poll: tabs.get(${tabId}) error #${consecutiveErrors}: ${msg}`);
      if (consecutiveErrors >= 3) {
        console.log(TAG, `poll: tab ${tabId} unreachable after ${consecutiveErrors} errors, stopping`);
        authTabs.delete(tabId);
        return;
      }
    }
  }
  console.warn(TAG, `poll: timed out for tab ${tabId} after 2 min`);
  authTabs.delete(tabId);
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === MSG.START_PICKER) {
    injectPicker(message.tabId);
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === MSG.CANCEL_PICKER) {
    removePicker(message.tabId);
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === MSG.AUTH_TAB_OPENED) {
    const tabId = message.tabId;
    console.log(TAG, `auth tab opened: ${tabId}`);
    authTabs.add(tabId);
    pollAuthTab(tabId).catch(
      (err) => console.error(TAG, "pollAuthTab error:", err)
    );
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === MSG.FTC_EXTENSION_TOKEN) {
    const senderUrl = sender.tab?.url;
    console.log(TAG, "token received via content script relay, sender:", senderUrl?.slice(0, 80));
    if (!senderUrl) {
      console.warn(TAG, "rejected: no sender tab URL");
      sendResponse({ ok: false, error: "no sender tab" });
      return false;
    }
    if (!isValidAuthSender(senderUrl, BASE_URL)) {
      console.warn(TAG, "rejected: unexpected origin/path");
      sendResponse({ ok: false, error: "unexpected origin" });
      return false;
    }
    if (sender.tab?.id) authTabs.delete(sender.tab.id);
    handleTokenReceived(message.token, message.expiresAt, sender.tab?.id).then(() => {
      console.log(TAG, "token stored successfully (content script path)");
      sendResponse({ ok: true });
    }).catch((err) => {
      console.error(TAG, "handleTokenReceived failed:", err);
      chrome.storage.local.remove(AUTH_STARTED_KEY).catch(() => {
      });
      sendResponse({ ok: false, error: "storage failed" });
    });
    return true;
  }
  if (message.type === MSG.ELEMENT_SELECTED || message.type === MSG.CANDIDATES_RESULT) {
    chrome.runtime.sendMessage(message).catch(() => {
    });
    return false;
  }
  return false;
});
async function injectPicker(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url || !tab.url.startsWith("http://") && !tab.url.startsWith("https://")) {
      return;
    }
    await chrome.scripting.insertCSS({
      target: { tabId },
      files: ["picker.css"]
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["picker.js"]
    });
  } catch (err) {
    console.error(TAG, "Failed to inject picker:", err);
  }
}
async function removePicker(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const event = new CustomEvent("ftc-cancel-picker");
        document.dispatchEvent(event);
      }
    });
  } catch (err) {
    console.error(TAG, "Failed to remove picker:", err);
  }
}
var lastStoredToken = "";
async function handleTokenReceived(token, expiresAt, tabId) {
  if (token === lastStoredToken) {
    console.log(TAG, "duplicate token, skipping storage");
    if (tabId) chrome.tabs.remove(tabId).catch(() => {
    });
    return;
  }
  if (token.split(".").length !== 3) {
    console.warn(TAG, "rejected: token doesn't look like a JWT");
    await chrome.storage.local.remove(AUTH_STARTED_KEY);
    return;
  }
  console.log(TAG, "storing token, expiresAt:", expiresAt);
  lastStoredToken = token;
  await setToken(token, expiresAt);
  await chrome.storage.local.remove(AUTH_STARTED_KEY);
  console.log(TAG, "token stored OK");
  if (tabId) {
    try {
      await chrome.tabs.remove(tabId);
      console.log(TAG, `auth tab ${tabId} closed`);
    } catch {
    }
  }
  chrome.runtime.sendMessage({ type: "FTC_AUTH_COMPLETE" }).catch(() => {
  });
}
export {
  extractTokenFromUrl,
  isValidAuthSender
};
